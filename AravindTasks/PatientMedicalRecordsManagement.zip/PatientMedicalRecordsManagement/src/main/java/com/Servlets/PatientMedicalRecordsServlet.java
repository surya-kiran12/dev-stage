package com.Servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

// Servlet for handling Patient Medical Records: Adding, Retrieving, and Updating records
public class PatientMedicalRecordsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database connection variables
    private static final String jdbcURL = "jdbc:mysql://localhost:3306/nani";
    private static final String jdbcUsername = "root";
    private static final String jdbcPassword = "nani123@@";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        if ("retrieve".equalsIgnoreCase(action)) {
            retrieveRecords(request, response); // Handle retrieving records
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action parameter.");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        String role = request.getParameter("role");

        // Ensure only doctors or staff can add or update records
        if (!"doctor".equalsIgnoreCase(role) && !"staff".equalsIgnoreCase(role)) {
            response.setContentType("text/html");
            PrintWriter out = response.getWriter();
            out.println("<html><body>");
            out.println("<h3>Unauthorized access. Only doctors and staff can add or update records.</h3>");
            out.println("</body></html>");
            return;
        }

        if ("add".equalsIgnoreCase(action)) {
            addRecords(request, response); // Handle adding records
        } else if ("update".equalsIgnoreCase(action)) {
            updateRecords(request, response); // Handle updating records
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action parameter.");
        }
    }

    // Method for adding patient medical records
    private void addRecords(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String patientName = request.getParameter("patientName");
        String doctorName = request.getParameter("doctorName");
        String disease = request.getParameter("disease");
        String treatment = request.getParameter("treatment");
        String prescription = request.getParameter("prescription");
        String tests = request.getParameter("tests");
        String status = request.getParameter("status");
        String admitDate = request.getParameter("admitDate");
        String dischargeDate = request.getParameter("dischargeDate");

        String sql = "INSERT INTO patient_records (patientName, doctorName, disease, treatment, prescription, tests, status, admitDate, dischargeDate) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try (Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, patientName);
            stmt.setString(2, doctorName);
            stmt.setString(3, disease);
            stmt.setString(4, treatment);
            stmt.setString(5, prescription);
            stmt.setString(6, tests);
            stmt.setString(7, status);
            stmt.setString(8, admitDate);
            stmt.setString(9, dischargeDate);

            int rowsInserted = stmt.executeUpdate();
            sendResponse(response, rowsInserted > 0 ? "Record inserted successfully!" : "Failed to insert record.");
        } catch (SQLException e) {
            handleError(response, e);
        }
    }

    // Method for retrieving patient medical records
    private void retrieveRecords(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String patientName = request.getParameter("patientName");
        String patientId = request.getParameter("patientId");
        String doctorName = request.getParameter("doctorName");
        String startDate = request.getParameter("startDate");
        String endDate = request.getParameter("endDate");

        StringBuilder sql = new StringBuilder("SELECT * FROM patient_records WHERE 1=1");
        if (patientName != null && !patientName.isEmpty()) sql.append(" AND patientName = ?");
        if (patientId != null && !patientId.isEmpty()) sql.append(" AND patientId = ?");
        if (doctorName != null && !doctorName.isEmpty()) sql.append(" AND doctorName = ?");
        if (startDate != null && endDate != null && !startDate.isEmpty() && !endDate.isEmpty()) sql.append(" AND admitDate BETWEEN ? AND ?");

        try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try (Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement stmt = conn.prepareStatement(sql.toString())) {

            int paramIndex = 1;
            if (patientName != null && !patientName.isEmpty()) stmt.setString(paramIndex++, patientName);
            if (patientId != null && !patientId.isEmpty()) stmt.setInt(paramIndex++, Integer.parseInt(patientId));
            if (doctorName != null && !doctorName.isEmpty()) stmt.setString(paramIndex++, doctorName);
            if (startDate != null && !startDate.isEmpty() && endDate != null && !endDate.isEmpty()) {
                stmt.setString(paramIndex++, startDate);
                stmt.setString(paramIndex++, endDate);
            }

            ResultSet rs = stmt.executeQuery();
            generateTableFromResultSet(response, rs);

        } catch (SQLException e) {
            handleError(response, e);
        }
    }

    // Method for updating patient medical records
    private void updateRecords(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String patientName = request.getParameter("patientName");
        String doctorName = request.getParameter("doctorName");
        String disease = request.getParameter("disease");
        String treatment = request.getParameter("treatment");
        String prescription = request.getParameter("prescription");
        String tests = request.getParameter("tests");
        String status = request.getParameter("status");
        String admitDate = request.getParameter("admitDate");
        String dischargeDate = request.getParameter("dischargeDate");

        String sql = "UPDATE patient_records SET doctorName = ?, disease = ?, treatment = ?, prescription = ?, tests = ?, status = ?, admitDate = ?, dischargeDate = ? WHERE patientName = ?";

        try {
			Class.forName("com.mysql.cj.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try (Connection conn = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, doctorName);
            stmt.setString(2, disease);
            stmt.setString(3, treatment);
            stmt.setString(4, prescription);
            stmt.setString(5, tests);
            stmt.setString(6, status);
            stmt.setString(7, admitDate);
            stmt.setString(8, dischargeDate);
            stmt.setString(9, patientName);

            int rowsUpdated = stmt.executeUpdate();
            sendResponse(response, rowsUpdated > 0 ? "Record updated successfully!" : "Failed to update record. Patient not found.");
        } catch (SQLException e) {
            handleError(response, e);
        }
    }

    // Utility method to handle error responses
    private void handleError(HttpServletResponse response, SQLException e) throws IOException {
        e.printStackTrace();
        sendResponse(response, "Database error: " + e.getMessage());
    }

    // Utility method to send success or error message as response
    private void sendResponse(HttpServletResponse response, String message) throws IOException {
        response.setContentType("text/html");
        try (PrintWriter out = response.getWriter()) {
            out.println("<html><body>");
            out.println("<h3>" + message + "</h3>");
            out.println("</body></html>");
        }
    }

    // Utility method to generate HTML table from ResultSet
    private void generateTableFromResultSet(HttpServletResponse response, ResultSet rs) throws SQLException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h3>Patient Medical Records:</h3>");

        if (rs.next()) {
            out.println("<table border='1'><tr><th>Patient ID</th><th>Patient Name</th><th>Doctor Name</th><th>Disease</th><th>Treatment</th><th>Prescription</th><th>Tests</th><th>Status</th><th>Admit Date</th><th>Discharge Date</th></tr>");

            do {
                out.println("<tr>");
                out.println("<td>" + rs.getInt("patientId") + "</td>");
                out.println("<td>" + rs.getString("patientName") + "</td>");
                out.println("<td>" + rs.getString("doctorName") + "</td>");
                out.println("<td>" + rs.getString("disease") + "</td>");
                out.println("<td>" + rs.getString("treatment") + "</td>");
                out.println("<td>" + rs.getString("prescription") + "</td>");
                out.println("<td>" + rs.getString("tests") + "</td>");
                out.println("<td>" + rs.getString("status") + "</td>");
                out.println("<td>" + rs.getString("admitDate") + "</td>");
                out.println("<td>" + rs.getString("dischargeDate") + "</td>");
                out.println("</tr>");
            } while (rs.next());

            out.println("</table>");
        } else {
            out.println("<p>No records found.</p>");
        }

        out.println("</body></html>");
    }
}
