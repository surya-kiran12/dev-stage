package com.Utility;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import com.Model.PatientReport;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ReportGenerator {

    public static void generatePdfReport(HttpServletResponse response, List<PatientReport> patientReports) throws IOException {
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=patient_reports.pdf");

        Document document = new Document();
        try {
            PdfWriter.getInstance(document, response.getOutputStream());
            document.open();

            Paragraph title = new Paragraph("Patient Report");
            document.add(title);

            PdfPTable table = new PdfPTable(11); 
            table.addCell("Patient ID");
            table.addCell("Patient Name");
            table.addCell("Doctor Name");
            table.addCell("Treatment");
            table.addCell("Disease");
            table.addCell("Prescription");
            table.addCell("Tests");
            table.addCell("Status");
            table.addCell("Admit Date");
            table.addCell("Discharge Date");
            table.addCell("Report Date");

            for (PatientReport report : patientReports) {
                table.addCell(String.valueOf(report.getPatient_id()));
                table.addCell(report.getPatient_name());
                table.addCell(report.getDoctor_name());
                table.addCell(report.getTreatment());
                table.addCell(report.getDisease());
                table.addCell(report.getPrescription());
                table.addCell(report.getTests());
                table.addCell(report.getStatus());
                table.addCell(report.getAdmit_date().toString());
                table.addCell(report.getDischarge_date().toString());
                table.addCell(report.getReport_date().toString());
            }

            document.add(table);
        } catch (DocumentException e) {
            e.printStackTrace();
            throw new IOException("Error generating PDF report", e);
        } finally {
            document.close();
        }
    }

    public static void generateExcelReport(HttpServletResponse response, List<PatientReport> patientReports) throws IOException {
        response.setContentType("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        response.setHeader("Content-Disposition", "attachment; filename=patient_reports.xlsx");

        try (Workbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Patient Reports");

            // Create header row
            Row headerRow = sheet.createRow(0);
            String[] headers = {"Patient ID", "Patient Name", "Doctor Name", "Treatment", "Disease", "Prescription", "Tests", "Status", "Admit Date", "Discharge Date", "Report Date"};
            for (int i = 0; i < headers.length; i++) {
                headerRow.createCell(i).setCellValue(headers[i]);
            }

            // Populate rows
            int rowNum = 1;
            for (PatientReport report : patientReports) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(report.getPatient_id());
                row.createCell(1).setCellValue(report.getPatient_name());
                row.createCell(2).setCellValue(report.getDoctor_name());
                row.createCell(3).setCellValue(report.getTreatment());
                row.createCell(4).setCellValue(report.getDisease());
                row.createCell(5).setCellValue(report.getPrescription());
                row.createCell(6).setCellValue(report.getTests());
                row.createCell(7).setCellValue(report.getStatus());
                row.createCell(8).setCellValue(report.getAdmit_date().toString());
                row.createCell(9).setCellValue(report.getDischarge_date().toString());
                row.createCell(10).setCellValue(report.getReport_date().toString());
            }

            // Write the output to response
            try (ServletOutputStream out = response.getOutputStream()) {
                workbook.write(out);
                out.flush();
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw new IOException("Error generating Excel report", e);
        }
    }

    public static void generateDocumentReport(HttpServletResponse response, List<PatientReport> patientReports) throws IOException {
        response.setContentType("application/msword");
        response.setHeader("Content-Disposition", "attachment; filename=patient_reports.doc");

        try (PrintWriter writer = response.getWriter()) {
            writer.println("Patient Report");
            writer.println("==============");

            for (PatientReport report : patientReports) {
                writer.println("Patient ID: " + report.getPatient_id());
                writer.println("Patient Name: " + report.getPatient_name());
                writer.println("Doctor Name: " + report.getDoctor_name());
                writer.println("Treatment: " + report.getTreatment());
                writer.println("Disease: " + report.getDisease());
                writer.println("Prescription: " + report.getPrescription());
                writer.println("Tests: " + report.getTests());
                writer.println("Status: " + report.getStatus());
                writer.println("Admit Date: " + report.getAdmit_date());
                writer.println("Discharge Date: " + report.getDischarge_date());
                writer.println("Report Date: " + report.getReport_date());
                writer.println("--------------------------------------------------");
            }

            writer.flush();
        } catch (IOException e) {
            e.printStackTrace();
            throw new IOException("Error generating Word document report", e);
        }
    }
}
