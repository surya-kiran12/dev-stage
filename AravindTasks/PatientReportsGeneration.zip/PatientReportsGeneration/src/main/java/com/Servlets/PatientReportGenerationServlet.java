package com.Servlets;

import com.DAO.PatientReportDAO;
import com.Model.PatientReport;
import com.Utility.ReportGenerator;

import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

public class PatientReportGenerationServlet extends HttpServlet {
    
    private static final long serialVersionUID = 1L;
    private PatientReportDAO reportDAO = new PatientReportDAO();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String reportType = request.getParameter("reportType");
        String startDate = request.getParameter("startDate");
        String endDate = request.getParameter("endDate");

        try {
            List<PatientReport> patientReports = reportDAO.getPatientReports(startDate, endDate);

            if ("pdf".equalsIgnoreCase(reportType)) {
                ReportGenerator.generatePdfReport(response, patientReports);
            } else if ("excel".equalsIgnoreCase(reportType)) {
                ReportGenerator.generateExcelReport(response, patientReports);
            } else if ("doc".equalsIgnoreCase(reportType)) {
                ReportGenerator.generateDocumentReport(response, patientReports);
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid report type.");
            }
        } catch (SQLException | ClassNotFoundException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "An error occurred while generating the report.");
        }
    }
}
