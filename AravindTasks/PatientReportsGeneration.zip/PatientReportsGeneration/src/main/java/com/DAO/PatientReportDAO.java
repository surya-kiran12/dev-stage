package com.DAO;

import com.Model.PatientReport;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PatientReportDAO {

    // Database configuration
	 private static final String JDBC_URL = "jdbc:mysql://localhost:3306/nani";
	    private static final String JDBC_USERNAME = "root";
	    private static final String JDBC_PASSWORD = "nani123@@";


    // Method to get a connection to the database
    private Connection getConnection() throws SQLException, ClassNotFoundException {
        // Load the JDBC driver
        Class.forName("com.mysql.cj.jdbc.Driver");
        // Establish and return the connection
        return DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
    }

    // Method to get patient reports based on date range
    public List<PatientReport> getPatientReports(String startDate, String endDate) throws SQLException, ClassNotFoundException {
        List<PatientReport> reports = new ArrayList<>();
        String query = "SELECT * FROM patient_reports WHERE patient_id = ? AND report_date BETWEEN ? AND ?";


        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(query)) {
            ps.setDate(1, Date.valueOf(startDate));
            ps.setDate(2, Date.valueOf(endDate));

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    PatientReport report = new PatientReport();
                    report.setPatient_id(rs.getInt("patient_id"));
                    report.setPatient_name(rs.getString("patient_name"));
                    report.setDoctor_name(rs.getString("doctor_name"));
                    report.setTreatment(rs.getString("treatment"));
                    report.setDisease(rs.getString("disease"));
                    report.setPrescription(rs.getString("prescription"));
                    report.setTests(rs.getString("tests"));
                    report.setStatus(rs.getString("status"));
                    report.setAdmit_date(rs.getDate("admit_date"));
                    report.setDischarge_date(rs.getDate("discharge_date"));
                    report.setReport_date(rs.getDate("report_date"));
                    reports.add(report);
                }
            }
        }
        return reports;
    }
}
