package com.Servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class RoleServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database connection details
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/nani";
    private static final String JDBC_USERNAME = "root";
    private static final String JDBC_PASSWORD = "nani123@@" ;

    // Load MySQL JDBC Driver
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String username = request.getParameter("username");
        String password = request.getParameter("password");

        // Validate user credentials and retrieve role from the database
        String role = validateUser(username, password);

        if (role != null) {
            HttpSession session = request.getSession();
            session.setAttribute("username", username);
            session.setAttribute("role", role);

            // Redirect based on the role
            switch (role.toLowerCase()) {
                case "admin":
                    response.sendRedirect("admin.jsp");
                    break;
                case "doctor":
                    response.sendRedirect("doctor.jsp");
                    break;
                case "nurse":
                    response.sendRedirect("nurse.jsp");
                    break;
                case "patient":
                    response.sendRedirect("patient.jsp");
                    break;
                default:
                    response.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Invalid role.");
                    break;
            }
        } else {
            // If login fails, redirect to login page with error message
            response.sendRedirect("login.jsp?error=Invalid username or password");
        }
    }

    // Validate the user's credentials and return their role
    private String validateUser(String username, String password) {
        String query = "SELECT role FROM users WHERE username = ? AND password = ?";

        // Use try-with-resources to automatically close resources
        try (Connection con = DriverManager.getConnection(JDBC_URL, JDBC_USERNAME, JDBC_PASSWORD);
             PreparedStatement ps = con.prepareStatement(query)) {

            ps.setString(1, username);
            ps.setString(2, password);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("role"); // Return the user's role (Admin, Doctor, Nurse, Patient)
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; 
    }
}
