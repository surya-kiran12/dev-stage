package com.DAO;

import com.Model.Order;
import com.Model.OrderItem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class OrderDAO {
    private Connection connection;

    public OrderDAO(Connection connection) {
        this.connection = connection;
    }

    // Fetch orders by user ID with filtering options
    public List<Order> getOrdersByUserId(int userId, String status, String startDate, String endDate) {
        List<Order> orders = new ArrayList<>();
        
        StringBuilder query = new StringBuilder("SELECT * FROM orders WHERE user_id = ?");
        List<Object> params = new ArrayList<>();
        params.add(userId);

        // Add filters
        if (status != null && !status.equals("all")) {
            query.append(" AND status = ?");
            params.add(status);
        }

        if (startDate != null && !startDate.isEmpty()) {
            query.append(" AND orderDate >= ?");
            params.add(startDate);
        }

        if (endDate != null && !endDate.isEmpty()) {
            query.append(" AND orderDate <= ?");
            params.add(endDate);
        }

        try (PreparedStatement stmt = connection.prepareStatement(query.toString())) {
            for (int i = 0; i < params.size(); i++) {
                stmt.setObject(i + 1, params.get(i));
            }
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Order order = new Order();
                    order.setOrder_id(rs.getInt("order_id"));
                    order.setOrderDate(rs.getDate("orderDate"));
                    order.setStatus(rs.getString("status"));
                    order.setAddress(rs.getString("address"));

                    // Fetch order items for this order
                    List<OrderItem> orderItems = getOrderItemsByOrderId(order.getOrder_id());
                    order.setOrderItems(orderItems);

                    // Calculate total order price
                    double totalOrderPrice = orderItems.stream()
                            .mapToDouble(OrderItem::getTotalPrice)
                            .sum();
                    order.setTotalPrice(totalOrderPrice);

                    orders.add(order);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orders;
    }

    // Fetch order items by order ID
    private List<OrderItem> getOrderItemsByOrderId(int orderId) {
        List<OrderItem> orderItems = new ArrayList<>();
        String itemQuery = "SELECT * FROM orderitems WHERE order_id = ?";
        try (PreparedStatement itemStmt = connection.prepareStatement(itemQuery)) {
            itemStmt.setInt(1, orderId);
            try (ResultSet itemRs = itemStmt.executeQuery()) {
                while (itemRs.next()) {
                    OrderItem item = new OrderItem();
                    item.setOrderItem_id(itemRs.getInt("orderItem_id"));
                    item.setProductName(itemRs.getString("productName"));
                    item.setQuantity(itemRs.getInt("quantity"));
                    item.setPrice(itemRs.getDouble("price"));
                    item.setTotalPrice(item.getPrice() * item.getQuantity());  // Calculate total price
                    orderItems.add(item);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return orderItems;
    }

    public List<Order> getOrderHistory() {
        return new ArrayList<>(); // This can be implemented if needed
    }
}
