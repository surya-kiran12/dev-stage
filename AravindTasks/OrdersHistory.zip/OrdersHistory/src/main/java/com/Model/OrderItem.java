package com.Model;

public class OrderItem {
    private int orderItem_id;
    private int order_id;
    private String productName;
    private int quantity;
    private double price;
    private double totalPrice;
    private String imageUrl;

    // Getters and Setters
    public int getOrderItem_id() {
        return orderItem_id;
    }

    public void setOrderItem_id(int orderItem_id) {
        this.orderItem_id = orderItem_id;
    }

    public int getOrder_id() {
        return order_id;
    }

    public void setOrder_id(int order_id) {
        this.order_id = order_id;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    

    public String getImageUrl() {
        return imageUrl;
    }

    public double getTotalPrice() {
		return totalPrice;
	}

	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}

	public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }
}
  
