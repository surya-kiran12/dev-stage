package com.Servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import com.Model.Order;
import com.Model.OrderItem;
import com.DAO.OrderDAO;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

public class OrderHistoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        // Retrieve user ID and filter parameters from the request
        String userIdParam = request.getParameter("user_id");
        String statusFilter = request.getParameter("statusFilter");
        String startDate = request.getParameter("startDate");
        String endDate = request.getParameter("endDate");

        // Database connection details
        String jdbcURL = "jdbc:mysql://localhost:3306/nani";
        String jdbcUsername = "root";
        String jdbcPassword = "nani123@@";
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        
        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword)) {
            OrderDAO orderDAO = new OrderDAO(connection);
            List<Order> orderHistory;

            if (userIdParam != null && !userIdParam.isEmpty()) {
                try {
                    int userId = Integer.parseInt(userIdParam);
                    orderHistory = orderDAO.getOrdersByUserId(userId, statusFilter, startDate, endDate);
                } catch (NumberFormatException e) {
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    PrintWriter out = response.getWriter();
                    out.println("<h3>Invalid User ID format.</h3>");
                    return;
                }
            } else {
                orderHistory = orderDAO.getOrderHistory(); // Implement this method if needed
            }

            response.setContentType("text/html");
            response.setCharacterEncoding("UTF-8");

            PrintWriter out = response.getWriter();

            if (orderHistory.isEmpty()) {
                out.println("<h3>No orders found for this user ID.</h3>");
            } else {
                out.println("<h3>Order History:</h3>");
                out.println("<table border='1'>");
                out.println("<tr><th>Order Date</th><th>Order ID</th><th>Product Name</th><th>Quantity</th><th>Status</th><th>Price</th><th>Total Price</th><th>Address</th></tr>");

                for (Order order : orderHistory) {
                    for (OrderItem item : order.getOrderItems()) {
                        out.println("<tr>");
                        out.println("<td>" + order.getOrderDate() + "</td>");
                        out.println("<td>" + order.getOrder_id() + "</td>");
                        out.println("<td><img src='" + item.getImageUrl() + "' alt='Product Image' width='100' height='100'></td>");
                        out.println("<td>" + item.getProductName() + "</td>");
                        out.println("<td>" + item.getQuantity() + "</td>");
                        out.println("<td>" + order.getStatus() + "</td>");
                        out.println("<td>" + item.getPrice() + "</td>");
                        out.println("<td>" + item.getTotalPrice() + "</td>");
                        out.println("<td>" + order.getAddress() + "</td>");
                        out.println("</tr>");
                    }
                }

                out.println("</table>");
            }
        } catch (SQLException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            PrintWriter out = response.getWriter();
            out.println("<h3>An error occurred while accessing the database.</h3>");
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}
