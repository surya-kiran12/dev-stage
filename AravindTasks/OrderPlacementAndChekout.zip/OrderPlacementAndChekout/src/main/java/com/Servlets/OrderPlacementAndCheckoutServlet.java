package com.Servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.*;
import java.sql.Date;
import com.Model.Order;
import com.Model.OrderItem;
import com.Utility.OrderService;

public class OrderPlacementAndCheckoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private final OrderService orderService = new OrderService();

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Extract order and user details from the request
        String fullName = request.getParameter("fullname");
        String address = request.getParameter("address");
        String city = request.getParameter("city");
        String zipcode = request.getParameter("zipcode");

        // Extract product details from the request
        int productId = Integer.parseInt(request.getParameter("product_id"));
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        double price = Double.parseDouble(request.getParameter("price"));
        String imageURL = request.getParameter("image_url");

        // Create OrderItem and Order objects
        OrderItem orderItem = new OrderItem();
        orderItem.setProduct_id(productId);
        orderItem.setQuantity(quantity);
        orderItem.setPrice(price);
        orderItem.setImageUrl(imageURL);

        List<OrderItem> orderItems = new ArrayList<>();
        orderItems.add(orderItem);

        Order order = new Order();
        order.setFullName(fullName);
        order.setAddress(address);
        order.setCity(city);
        order.setZipcode(zipcode);
        order.setOrderDate(new Date(System.currentTimeMillis()));
        order.setOrderItems(orderItems);

        // Perform checkout operation
        boolean checkoutSuccess = orderService.checkout(order);

        // Set the response content type and return a response
        response.setContentType("text/html");
        if (checkoutSuccess) {
            response.getWriter().write("Checkout completed successfully!<br>");
            response.getWriter().write("Order ID: " + order.getOrderId() + "<br>");
            response.getWriter().write("Shipping Address: " + order.getAddress() + ", " + order.getCity() + ", " + order.getZipcode() + "<br>");
            response.getWriter().write(order.getDeliveryDateTime() + "<br>");
            for (OrderItem item : order.getOrderItems()) {
                response.getWriter().write("Product ID: " + item.getProduct_id() + "<br>");
                response.getWriter().write("Quantity: " + item.getQuantity() + "<br>");
                response.getWriter().write("Price: $" + item.getPrice() + "<br>");
                response.getWriter().write("<img src='" + item.getImageUrl() + "' alt='Product Image' width='100'><br>");
            }
        } else {
            response.getWriter().write("Checkout failed: Payment failed or insufficient stock.");
        }
    }
}
