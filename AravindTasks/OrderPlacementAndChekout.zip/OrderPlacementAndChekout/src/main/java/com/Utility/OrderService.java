package com.Utility;

import java.sql.Date;
import java.text.SimpleDateFormat;
import java.util.*;
import com.Model.Order;
import com.Model.OrderItem;

public class OrderService {
    private static final List<Order> orderList = new ArrayList<>();
    private static final Map<Integer, Integer> inventory = new HashMap<>(); // productId -> quantity

    public boolean checkout(Order order) {
        // Stock validation (but not deduction yet)
        for (OrderItem item : order.getOrderItems()) {
            int productId = item.getProduct_id();
            int quantity = item.getQuantity();
            Integer currentStock = inventory.get(productId);

            if (currentStock == null || currentStock < quantity) {
                return false; // Insufficient stock or product does not exist
            }
        }

        try {
            // Calculate total price of the order
            double totalPrice = order.getOrderItems().stream()
                .mapToDouble(item -> item.getPrice() * item.getQuantity())
                .sum();

            // Simulate payment processing
            boolean paymentSuccess = processPayment(totalPrice);
            if (!paymentSuccess) {
                throw new RuntimeException("Payment failed");
            }

            // Deduct stock for each item only after payment success
            for (OrderItem item : order.getOrderItems()) {
                int productId = item.getProduct_id();
                int quantity = item.getQuantity();
                int currentStock = inventory.get(productId);
                inventory.put(productId, currentStock - quantity);
            }

            // Estimate the delivery date and format it
            String deliveryDateTime = getFormattedDeliveryDateTime(order.getOrderDate());
            order.setDeliveryDateTime(deliveryDateTime);

            // Add the order to the order list
            orderList.add(order);
            return true;
        } catch (Exception e) {
            // Log exception for debugging
            e.printStackTrace();
            return false;
        }
    }

    private String getFormattedDeliveryDateTime(Date orderDate) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(orderDate);

        // Assuming a delivery time of 5 days
        int deliveryTimeInDays = 5;
        calendar.add(Calendar.DAY_OF_YEAR, deliveryTimeInDays);

        // Format to display "Arrives by [day of the week] by 10pm"
        SimpleDateFormat dateFormat = new SimpleDateFormat("EEEE 'by' hhaa");
        return "Arrives by " + dateFormat.format(calendar.getTime());
    }

    public void addStock(int productId, int quantity) {
        inventory.put(productId, inventory.getOrDefault(productId, 0) + quantity);
    }

    private boolean processPayment(double totalAmount) {
        // Returning true to simulate a successful payment
        return true;
    }
}
