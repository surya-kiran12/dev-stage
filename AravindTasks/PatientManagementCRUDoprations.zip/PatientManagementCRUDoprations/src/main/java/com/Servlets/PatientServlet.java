package com.Servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 2, // 2MB
        maxFileSize = 1024 * 1024 * 10, // 10MB
        maxRequestSize = 1024 * 1024 * 50) // 50MB
public class PatientServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private String jdbcURL = "jdbc:mysql://localhost:3306/nani";
    private String jdbcUsername = "root";
    private String jdbcPassword = "nani123@@";

    private static final String UPLOAD_DIRECTORY = "uploads";
    private static final String[] ALLOWED_FILE_EXTENSIONS = { "pdf", "doc", "docx" };

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String role = (String) session.getAttribute("role"); // Assuming role is set in the session during login
        String action = request.getParameter("action");

        if (!"patient".equals(role)) {
            response.sendError(HttpServletResponse.SC_FORBIDDEN, "Access Denied: Only patients can perform this action.");
            return;
        }

        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword)) {
            switch (action) {
                case "insert":
                    addRecords(request, response, connection);
                    break;
                case "update":
                    updateRecords(request, response, connection);
                    break;
                case "retrieve":
                    retrieveRecord(request, response, connection);
                    break;
                case "delete":
                    deleteRecord(request, response, connection);
                    break;
                default:
                    response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid action");
            }
        } catch (SQLException e) {
            handleError(response, e);
        }
    }

    private void addRecords(HttpServletRequest request, HttpServletResponse response, Connection connection) throws IOException, ServletException, SQLException {
        String first_name = request.getParameter("first_name");
        String last_name = request.getParameter("last_name");
        String ageStr = request.getParameter("age");
        String mobile_number = request.getParameter("mobile_number");
        String address = request.getParameter("address");
        String gender = request.getParameter("gender");
        String marital_status = request.getParameter("marital_status");
        String medicalHistory = request.getParameter("medical_history");

        Part filePart = request.getPart("file");

        if (!validateInput(response, first_name, last_name, ageStr, mobile_number, filePart)) {
            return;
        }

        if (ismobile_numberInUse(mobile_number, connection)) {
            sendResponse(response, "Phone number is already in use by another patient.");
            return;
        }

        int age = Integer.parseInt(ageStr);
        String uploadedFilePath = saveUploadedFile(request, filePart);

        String sql = "INSERT INTO patient_details (first_name, last_name, age, mobile_number, address, gender, marital_status, medicalHistory, uploadedFilePath) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, first_name);
            stmt.setString(2, last_name);
            stmt.setInt(3, age);
            stmt.setString(4, mobile_number);
            stmt.setString(5, address);
            stmt.setString(6, gender);
            stmt.setString(7, marital_status);
            stmt.setString(8, medicalHistory);
            stmt.setString(9, uploadedFilePath);

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                sendResponse(response, "Record inserted successfully!");
            } else {
                sendResponse(response, "Failed to insert record.");
            }
        } catch (SQLException e) {
            handleError(response, e);
        }
    }

    private void updateRecords(HttpServletRequest request, HttpServletResponse response, Connection connection) throws IOException, ServletException, SQLException {
        String patientIdStr = request.getParameter("patientId");
        String first_name = request.getParameter("first_name");
        String last_name = request.getParameter("last_name");
        String ageStr = request.getParameter("age");
        String mobile_number = request.getParameter("mobile_number");
        String address = request.getParameter("address");
        String gender = request.getParameter("gender");
        String marital_status = request.getParameter("marital_status");
        String medicalHistory = request.getParameter("medicalhistory");

        Part filePart = request.getPart("file");

        if (!validateInput(response, first_name, last_name, ageStr, mobile_number, filePart)) {
            return;
        }

        int patientId = Integer.parseInt(patientIdStr);
        int age = Integer.parseInt(ageStr);

        if (ismobile_numberInUse(mobile_number, connection, patientId)) {
            sendResponse(response, "Phone number is already in use by another patient.");
            return;
        }

        String uploadedFilePath = saveUploadedFile(request, filePart);

        String sql = "UPDATE patient_details SET first_name = ?, last_name = ?, age = ?, mobile_number = ?, address = ?, gender = ?, " +
                "marital_status = ?, medicalHistory = ?, uploadedFilePath = ? WHERE patientId = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, first_name);
            stmt.setString(2, last_name);
            stmt.setInt(3, age);
            stmt.setString(4, mobile_number);
            stmt.setString(5, address);
            stmt.setString(6, gender);
            stmt.setString(7, marital_status);
            stmt.setString(8, medicalHistory);
            stmt.setString(9, uploadedFilePath);
            stmt.setInt(10, patientId);

            int rowsUpdated = stmt.executeUpdate();
            if (rowsUpdated > 0) {
                sendResponse(response, "Record updated successfully!");
            } else {
                sendResponse(response, "No record found with the provided ID.");
            }
        } catch (SQLException e) {
            handleError(response, e);
        }
    }

    private void retrieveRecord(HttpServletRequest request, HttpServletResponse response, Connection connection) throws IOException {
        String patientIdStr = request.getParameter("patientId");

        if (patientIdStr == null || !patientIdStr.matches("\\d+")) {
            sendResponse(response, "Invalid patient ID.");
            return;
        }

        int patientId = Integer.parseInt(patientIdStr);
        String sql = "SELECT * FROM patient_details WHERE patientId = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, patientId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                PrintWriter out = response.getWriter();
                out.println("Patient ID: " + rs.getInt("patientId"));
                out.println("First Name: " + rs.getString("first_name"));
                out.println("Last Name: " + rs.getString("last_name"));
                out.println("Age: " + rs.getInt("age"));
                out.println("Phone Number: " + rs.getString("mobile_number"));
                out.println("Address: " + rs.getString("address"));
                out.println("Gender: " + rs.getString("gender"));
                out.println("Marital Status: " + rs.getString("marital_status"));
                out.println("Medical History: " + rs.getString("medicalHistory"));
                out.println("File Uploaded: " + rs.getString("uploadedFilePath"));
            } else {
                sendResponse(response, "No record found.");
            }
        } catch (SQLException e) {
            handleError(response, e);
        }
    }

    private void deleteRecord(HttpServletRequest request, HttpServletResponse response, Connection connection) throws IOException {
        String patientIdStr = request.getParameter("patientId");

        if (patientIdStr == null || !patientIdStr.matches("\\d+")) {
            sendResponse(response, "Invalid patient ID.");
            return;
        }

        int patientId = Integer.parseInt(patientIdStr);
        String sql = "DELETE FROM patient_details WHERE patientId = ?";

        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, patientId);
            int rowsDeleted = stmt.executeUpdate();
            if (rowsDeleted > 0) {
                sendResponse(response, "Record deleted successfully.");
            } else {
                sendResponse(response, "No record found with the provided ID.");
            }
        } catch (SQLException e) {
            handleError(response, e);
        }
    }

    private boolean ismobile_numberInUse(String mobile_number, Connection connection) throws SQLException {
        String sql = "SELECT COUNT(*) FROM patient_details WHERE mobile_number = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, mobile_number);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }

    private boolean ismobile_numberInUse(String mobile_number, Connection connection, int patientId) throws SQLException {
        String sql = "SELECT COUNT(*) FROM patient_details WHERE mobile_number = ? AND patientId != ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setString(1, mobile_number);
            stmt.setInt(2, patientId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }

    private boolean validateInput(HttpServletResponse response, String first_name, String last_name, String age, String mobile_number, Part filePart) throws IOException {
       
        String fileName = filePart.getSubmittedFileName();
        String fileExtension = fileName.substring(fileName.lastIndexOf('.') + 1).toLowerCase();
        boolean validExtension = false;
        for (String ext : ALLOWED_FILE_EXTENSIONS) {
            if (fileExtension.equals(ext)) {
                validExtension = true;
                break;
            }
        }

        if (!validExtension) {
            sendResponse(response, "Invalid file type. Only PDF, DOC, and DOCX are allowed.");
            return false;
        }

        return true;
    }

    private String saveUploadedFile(HttpServletRequest request, Part filePart) throws IOException {
        String uploadPath = getServletContext().getRealPath("") + File.separator + UPLOAD_DIRECTORY;
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) {
            uploadDir.mkdir();
        }

        String fileName = filePart.getSubmittedFileName();
        String filePath = uploadPath + File.separator + fileName;
        filePart.write(filePath);
        return filePath;
    }

    private void sendResponse(HttpServletResponse response, String message) throws IOException {
        PrintWriter out = response.getWriter();
        out.println(message);
    }

    private void handleError(HttpServletResponse response, SQLException e) throws IOException {
        PrintWriter out = response.getWriter();
        out.println("Database error: " + e.getMessage());
    }
}
