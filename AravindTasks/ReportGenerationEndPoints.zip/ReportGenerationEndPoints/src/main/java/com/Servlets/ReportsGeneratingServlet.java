package com.Servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ReportsGeneratingServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String URL = "jdbc:mysql://localhost:3306/nani"; 
    private static final String USER = "root";
    private static final String PASSWORD = "nani123@@"; 

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        String reportType = request.getParameter("reportType");
        String startDate = request.getParameter("startDate");
        String endDate = request.getParameter("endDate");
        String patientId = request.getParameter("patient_id");

        if (reportType == null || startDate == null || endDate == null || patientId == null) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.print("{\"error\": \"Missing required parameters\"}");
            return;
        }

        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = getConnection();
            String query = getQueryForReportType(reportType);
            statement = connection.prepareStatement(query);
            statement.setString(1, patientId);
            statement.setString(2, startDate);
            statement.setString(3, endDate);

            resultSet = statement.executeQuery();
            String reportData = generateReport(resultSet, reportType);

            if (reportData.isEmpty()) {
                response.setStatus(HttpServletResponse.SC_NO_CONTENT);
                out.print("{\"message\": \"No data found for the specified criteria\"}");
                return;
            }

            switch (reportType) {
                case "test":
                    request.setAttribute("reportData", reportData);
                    request.getRequestDispatcher("PatientTestReports.jsp").forward(request, response);
                    break;
                case "medical":
                    request.setAttribute("reportData", reportData);
                    request.getRequestDispatcher("PatientMedicalReport.jsp").forward(request, response);
                    break;
                default:
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    out.print("{\"error\": \"Invalid report type selected\"}");
                    return;
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.print("{\"error\": \"Failed to generate report\"}");
        } finally {
            // Close resources in reverse order of their creation
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (statement != null) {
                try {
                    statement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private String getQueryForReportType(String reportType) {
        switch (reportType) {
            case "test":
                return "SELECT * FROM tests WHERE patient_id = ? AND test_date BETWEEN ? AND ?";
            case "medical":
                return "SELECT * FROM medical_reports WHERE patient_id = ? AND report_date BETWEEN ? AND ?";
            default:
                throw new IllegalArgumentException("Invalid report type");
        }
    }

    private String generateReport(ResultSet resultSet, String reportType) throws SQLException {
        StringBuilder report = new StringBuilder();
        report.append("[");

        boolean hasData = false; 
        while (resultSet.next()) {
            hasData = true;
            if (reportType.equals("medical")) {
                report.append("{")
                        .append("\"patient_id\": ").append(resultSet.getInt("patient_id")).append(",")
                        .append("\"patient_name\": \"").append(resultSet.getString("patient_name")).append("\",")
                        .append("\"doctor_name\": \"").append(resultSet.getString("doctor_name")).append("\",")
                        .append("\"disease\": \"").append(resultSet.getString("disease")).append("\",")
                        .append("\"treatment\": \"").append(resultSet.getString("treatment")).append("\",")
                        .append("\"prescription\": \"").append(resultSet.getString("prescription")).append("\",")
                        .append("\"tests\": \"").append(resultSet.getString("tests")).append("\",")
                        .append("\"status\": \"").append(resultSet.getString("status")).append("\",")
                        .append("\"admit_date\": \"").append(resultSet.getDate("admit_date")).append("\",")
                        .append("\"discharge_date\": \"").append(resultSet.getDate("discharge_date")).append("\"")
                        .append("},");
            } else if (reportType.equals("test")) {
                report.append("{")
                        .append("\"patient_id\": ").append(resultSet.getInt("patient_id")).append(",")
                        .append("\"patient_name\": \"").append(resultSet.getString("patient_name")).append("\",")
                        .append("\"doctor_name\": \"").append(resultSet.getString("doctor_name")).append("\",")
                        .append("\"lab_technician_name\": \"").append(resultSet.getString("lab_technician_name")).append("\",")
                        .append("\"test_name\": \"").append(resultSet.getString("test_name")).append("\",")
                        .append("\"test_date\": \"").append(resultSet.getDate("test_date")).append("\",")
                        .append("\"results\": \"").append(resultSet.getString("results")).append("\",")
                        .append("\"units\": \"").append(resultSet.getString("units")).append("\",")
                        .append("\"range\": \"").append(resultSet.getString("range")).append("\",")
                        .append("\"generated_on\": \"").append(resultSet.getDate("generated_on")).append("\"")
                        .append("},");
            }
        }

        if (hasData) {
            report.setLength(report.length() - 1); // Remove the last comma
        }
        report.append("]");
        return report.toString();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }
}
