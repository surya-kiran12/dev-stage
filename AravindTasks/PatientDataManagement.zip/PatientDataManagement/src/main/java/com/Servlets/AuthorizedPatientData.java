package com.Servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AuthorizedPatientData extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String role = request.getParameter("role");  
        String action = request.getParameter("action");  

        if ("staff".equalsIgnoreCase(role)) {
            // If the role is 'staff', determine which page to redirect to based on the action
            if (action != null) {
                switch (action.toLowerCase()) {
                    case "viewpatientdata":
                        response.sendRedirect("viewPatientData.jsp");
                        break;
                    case "manageappointments":
                        response.sendRedirect("manageAppointments.jsp");
                        break;
                    case "viewreports":
                        response.sendRedirect("viewReports.jsp");
                        break;
                    case "dashboard":
                        response.sendRedirect("sdashboard.jsp");
                        break;
                    default:
                        
                        response.sendRedirect("staff/dashboard.jsp");
                        break;
                }
            } else {
                // If no action is specified, redirect to a default page
                response.sendRedirect("staff/dashboard.jsp");
            }
        } else {
            // Role is not 'staff', deny access
            response.getWriter().println("Access Denied: You do not have the required permissions to view this page.");
            response.setStatus(HttpServletResponse.SC_FORBIDDEN); 
        }
    }
}
