package com.Servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Properties;

public class ContactFormServlet extends HttpServlet {
	 private static final long serialVersionUID = 1L;

    private static final String ADMIN_EMAIL = "saikamaravind123@gmail.com"; // Replace with admin's email
    private String jdbcURL = "jdbc:mysql://localhost:3306/nani"; 
    private String jdbcUsername = "root"; 
    private String jdbcPassword = "nani123@@";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String message = request.getParameter("message");

        boolean dataInserted = insertIntoDatabase(name, email, message);
        boolean emailSent = false;

        if (dataInserted) {
            emailSent = sendEmail(name, email, message);
        }

        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        if (dataInserted && emailSent) {
            out.println("<h3>Form submitted and email sent successfully!</h3>");
        } else if (!dataInserted) {
            out.println("<h3>Failed to submit form into database. Please try again later.</h3>");
        } else {
            out.println("<h3>Failed to send email. Please check your email settings.</h3>");
        }
    }

    private boolean sendEmail(String name, String userEmail, String userMessage) {
        final String fromEmail = "saikamaravind123@gmail.com"; 
        final String password = "ycgp mhxi elcs esou";      

        Properties properties = new Properties();
        properties.put("mail.smtp.host", "smtp.gmail.com");
        properties.put("mail.smtp.port", "587");
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");

        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(fromEmail, password);
            }
        });

        try {
            Message mimeMessage = new MimeMessage(session);
            mimeMessage.setFrom(new InternetAddress(fromEmail));
            mimeMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(ADMIN_EMAIL));
            mimeMessage.setSubject("New Contact Form Submission");

            String emailBody = "You have a new contact form submission: \n\n"
                    + "Name: " + name + "\n"
                    + "Email: " + userEmail + "\n"
                    + "Message: \n" + userMessage + "\n";

            mimeMessage.setText(emailBody);

            Transport.send(mimeMessage);
            return true;
          
        } catch (MessagingException e) {
            e.printStackTrace();
            return false;
            
        }
    }

    private boolean insertIntoDatabase(String name, String email, String message) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);

            String sql = "INSERT INTO contact_form (name, email, message) VALUES (?, ?, ?)";
            preparedStatement = connection.prepareStatement(sql);

            preparedStatement.setString(1, name);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, message);

            int rowsInserted = preparedStatement.executeUpdate();
            return rowsInserted > 0;

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            try {
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
