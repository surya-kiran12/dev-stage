package org.hospitalData;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.HUtil.DatabaseConnection;
import org.hospitalModel.User;


public class UserDAO {

    public User getUserByEmail(String email) throws SQLException {
        String query = "SELECT * FROM user_register WHERE email = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    User user = new User();
                    user.setUsername(rs.getString("user_name"));
                    user.setEmail(rs.getString("email"));
                    return user;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error retrieving user by email.", e);
        }
        return null;
    }

    public boolean updateUserPassword(String email, String newPassword) throws SQLException {
        String sql = "UPDATE users SET password = ? WHERE email = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, newPassword);
            stmt.setString(2, email);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error updating user password.", e);
        }
    }

    public boolean saveOtp(String email, String otp) throws SQLException {
        String query = "  ";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, otp);
            stmt.setString(2, email);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error saving OTP.", e);
        }
    }

    public boolean verifyOtpAndResetPassword(String email, String otp, String newPassword) throws SQLException {
        String query = "SELECT * FROM user_register WHERE email = ? AND otp = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, email);
            stmt.setString(2, otp);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String updatePasswordQuery = "UPDATE user_register SET password = ?, otp = NULL WHERE email = ?";
                    try (PreparedStatement updateStmt = conn.prepareStatement(updatePasswordQuery)) {
                        updateStmt.setString(1, newPassword);
                        updateStmt.setString(2, email);
                        return updateStmt.executeUpdate() > 0;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error verifying OTP and resetting password.", e);
        }
        return false;
    }

    public String getOtpByEmail(String email) throws SQLException {
        String query = "SELECT otp FROM user_register WHERE email = ?";
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
            stmt.setString(1, email);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getString("otp");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new SQLException("Error retrieving OTP by email.", e);
        }
        return null; 
    }
	
}
