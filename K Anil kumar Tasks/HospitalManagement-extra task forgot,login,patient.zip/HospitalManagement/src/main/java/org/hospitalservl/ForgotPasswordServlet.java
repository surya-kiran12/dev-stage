package org.hospitalservl;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.logging.Logger;

import org.HUtil.DatabaseConnection;
import org.hospitalserve.UserService;

import java.sql.Connection;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/send-otp")
public class ForgotPasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 18021997L;
    private static final Logger logger = Logger.getLogger(ForgotPasswordServlet.class.getName());
    private UserService userService = new UserService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");
        logger.info("Received email: " + email);

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        Connection conn = null;

        try {
            conn = DatabaseConnection.getConnection();

            if (!userService.isEmailExists(conn, email)) {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                displayMessage(out, "Email does not exist....", "login.jsp");
                return;
            }

            String otp = userService.generateOTP();

            if (userService.saveOtp(conn, email, otp)) {
                if (userService.sendOTP(email, otp)) {
                    displayMessage(out, "OTP sent to your Email Successfully.....", "login.jsp");
                    response.sendRedirect("forgot-password.jsp");
                } else {
                    response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                    displayMessage(out, "Error Sending OTP. Please Try Again....", "login.jsp");
                    logger.severe("Failed to send OTP to " + email);
                }
            } else {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                logger.severe("Failed to save OTP for " + email);
            }
        } catch (Exception e) {
            logger.severe("An error occurred: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            displayMessage(out, "An Error Occurred While Processing Your Request...", "login.jsp");
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    logger.severe("Failed to close database connection: " + e.getMessage());
                }
            }
        }
    }

    private void displayMessage(PrintWriter out, String message, String redirectUrl) {
        out.println("<html><head>");
        out.println("<script type='text/javascript'>");
        out.println("alert('" + message + "');");
        out.println("window.location.href='" + redirectUrl + "';");
        out.println("</script>");
        out.println("</head><body>");
        out.println("</body></html>");
    }
}
