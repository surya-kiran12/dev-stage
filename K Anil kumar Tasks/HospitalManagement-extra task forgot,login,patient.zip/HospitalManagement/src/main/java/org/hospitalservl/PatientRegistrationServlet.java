package org.hospitalservl;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.HUtil.DatabaseConnection;


public class PatientRegistrationServlet extends HttpServlet {
    private static final long serialVersionUID = 31081999L;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String user_name = request.getParameter("patientName");
    	String email = request.getParameter("email");
    	String password = request.getParameter("password");
    	String role = "patient";
 
    	response.setContentType("text/html");
    	PrintWriter out = response.getWriter();
 
    	Connection conn = null;
    	PreparedStatement stmt = null;
    	PreparedStatement stmt1 = null;
    	PreparedStatement stmt2 = null;
    	ResultSet rs = null;
 
    	try {
    	   Class.forName("com.mysql.cj.jdbc.Driver");
    	   conn = DatabaseConnection.getConnection();
 
    	    String checkQuery = "SELECT * FROM user_register WHERE user_name = ? AND email = ? AND role = ?";
    	    stmt1 = conn.prepareStatement(checkQuery);
    	    stmt1.setString(1, user_name);
    	    stmt1.setString(2, email);
    	    stmt1.setString(3, role);
    	    rs = stmt1.executeQuery();
    	    if (rs.next()) {
    	        out.println("<html><head>");
    	        out.println("<script type='text/javascript'>");
    	        out.println("alert('User Name or Email already exists..');");
    	        out.println("window.location.href='patientui.jsp';");
    	        out.println("</script>");
    	        out.println("</head><body>");
    	        out.println("</body></html>");
    	        return;
    	    }
 
    	    String lastIdQuery = "SELECT MAX(user_id) AS max_id FROM user_register WHERE role = ?";
    	    stmt2 = conn.prepareStatement(lastIdQuery);
    	    stmt2.setString(1, role);
    	    rs = stmt2.executeQuery();
 
    	    int newUserId = 1; 
    	    if (rs.next()) {
    	        newUserId = rs.getInt("max_id") + 1;
    	    }
 
    	    String sql = "INSERT INTO user_register (user_id, user_name, email, password, role) VALUES (?, ?, ?, ?, ?)";
    	    stmt = conn.prepareStatement(sql);
 
    	    stmt.setInt(1, newUserId);
    	    stmt.setString(2, user_name);
    	    stmt.setString(3, email);
    	    stmt.setString(4, password);
    	    stmt.setString(5, role);
 
    	    int rowsInserted = stmt.executeUpdate();
    	    if (rowsInserted > 0) {
    	        out.println("<html><head>");
    	        out.println("<script type='text/javascript'>");
    	        out.println("alert('Registration Successful..');");
    	        out.println("window.location.href='login.jsp';");
    	        out.println("</script>");
    	        out.println("</head><body>");
    	        out.println("</body></html>");
    	    } else {
    	        out.println("<html><head>");
    	        out.println("<script type='text/javascript'>");
    	        out.println("alert('Registration failed. Please try again...');");
    	        out.println("window.location.href='patientui.jsp';");
    	        out.println("</script>");
    	        out.println("</head><body>");
    	        out.println("</body></html>");
    	    }
    	} catch (ClassNotFoundException | SQLException e) {
    	    e.printStackTrace();
    	    request.setAttribute("errorMessage", "Error occurred while registering. Please try again later.");
    	    request.getRequestDispatcher("patientui.jsp").forward(request, response);
    	} finally {
    	    try {
    	        if (rs != null) rs.close();
    	        if (stmt != null) stmt.close();
    	        if (stmt1 != null) stmt1.close();
    	        if (stmt2 != null) stmt2.close();
    	        if (conn != null) conn.close();
    	    } catch (SQLException ex) {
    	        ex.printStackTrace();
    	    }
    	}
    }
}