package org.hospitalservl;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;

import org.HUtil.DatabaseConnection;
import org.HUtil.EmailUtil;
import org.hospitalModel.User;
import org.hospitalserve.UserService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/send-username")
public class ForgotUsernameServlet extends HttpServlet {
    private static final long serialVersionUID = 16091997L;
    private UserService userService = new UserService();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = request.getParameter("email");

        Connection conn = null;
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            conn = DatabaseConnection.getConnection();
            User user = userService.findUserByEmail(conn, email);

            if (user != null) {
                String subject = "Forgot Your Username";
                String message = "Greetings User, "
                        + "As per your request, we've sent your username to your registered email. "
                        + "Your username is: " + user.getUsername() + ". "
                        + "If you didn't request this, please contact us for support.";

                if (EmailUtil.sendEmail(email, subject, message)) {
                    displayMessage(out, "Username sent to your email.", "login.jsp");
                } else {
                    response.getWriter().write("Failed to send email. Please try again.");
                }
            } else {
                displayMessage(out, "Email not found.", "login.jsp");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().write("Error in processing request.");
        } finally {
            if (conn != null) {
                try {
                    conn.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void displayMessage(PrintWriter out, String message, String redirectUrl) {
        out.println("<html><head>");
        out.println("<script type='text/javascript'>");
        out.println("alert('" + message + "');");
        out.println("window.location.href='" + redirectUrl + "';");
        out.println("</script>");
        out.println("</head><body>");
        out.println("</body></html>");
    }
}
