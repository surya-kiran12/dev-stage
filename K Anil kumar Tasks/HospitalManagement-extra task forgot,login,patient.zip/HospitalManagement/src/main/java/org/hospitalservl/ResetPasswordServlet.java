package org.hospitalservl;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.logging.Logger;

import org.HUtil.DatabaseConnection;
import org.hospitalserve.UserService;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/reset-password")
public class ResetPasswordServlet extends HttpServlet {
    private static final long serialVersionUID = 24022020L;

    private static final Logger logger = Logger.getLogger(ResetPasswordServlet.class.getName());
    private UserService userService = new UserService();

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        String email = request.getParameter("email");
        String enteredOtp = request.getParameter("otp");
        String newPassword = request.getParameter("new-password");
        String confirmPassword = request.getParameter("confirm-password");

        PrintWriter out = response.getWriter();
        Connection connection = null;

        try {
            connection = DatabaseConnection.getConnection();

            if (userService.validateOTP(email, enteredOtp)) {
                if (newPassword.equals(confirmPassword)) {
                    if (userService.updatePassword(email, newPassword)) {
                        displayAlert(out, "Password Changed Successfully...", "login.jsp");
                    } else {
                        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                        displayAlert(out, "Failed to update password...", "forgot-password.jsp");
                    }
                } else {
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    displayAlert(out, "Passwords do not match...", "forgot-password.jsp");
                }
            } else {
                response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                displayAlert(out, "Invalid OTP...", "forgot-password.jsp");
            }
        } catch (SQLException e) {
            logger.severe("Database error occurred: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("An error occurred while processing your request.");
        } catch (Exception e) {
            logger.severe("An error occurred: " + e.getMessage());
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("An error occurred while processing your request.");
        } finally {
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    logger.severe("Error closing connection: " + e.getMessage());
                }
            }
        }
    }

    private void displayAlert(PrintWriter out, String message, String redirectUrl) {
        out.println("<html><head>");
        out.println("<script type='text/javascript'>");
        out.println("alert('" + message + "');");
        out.println("window.location.href='" + redirectUrl + "';");
        out.println("</script>");
        out.println("</head><body>");
        out.println("</body></html>");
    }
}
