package org.hospitalserve;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Random;

import org.HUtil.EmailUtil;
import org.hospitalData.UserDAO;
import org.hospitalModel.User;

public class UserService {
    private UserDAO userDAO = new UserDAO(); 

    public String generateOTP() {
        Random SecureRandomrandom = new Random();
        return String.format("%06d", SecureRandomrandom.nextInt(1000000)); 
    }

    public boolean isEmailExists(Connection conn, String email) {
        try {
            User user = userDAO.getUserByEmail(email);
            return user != null;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean sendOTP(String email, String otp) {
        String subject = "Your OTP for Password Reset"; 
        String message = "Your OTP code is: " + otp;    
        return EmailUtil.sendEmail(email, subject, message);
    }

    public boolean updatePassword(String email, String newPassword) throws SQLException {
        return userDAO.updateUserPassword(email, newPassword);
    }

    public boolean saveOtp(Connection conn, String email, String otp) {
        try {
            return userDAO.saveOtp(email, otp);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    public boolean validateOTP(String email, String otp) {
        try {
            String storedOtp = userDAO.getOtpByEmail(email);
            return storedOtp != null && storedOtp.equals(otp);
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

	public User findUserByEmail(Connection conn, String email) {
		 try {
	            return userDAO.getUserByEmail(email);
	        } catch (SQLException e) {
	            e.printStackTrace();
	            return null; 
	        }
	}	
}
