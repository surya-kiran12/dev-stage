package org.HUtil;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {
    private static final String URL = "jdbc:mysql://192.168.1.157:3306/curetrack";
    private static final String USER = "vamshimvr";
    private static final String PASSWORD = "Vamshi@123";
    public static Connection getConnection() throws SQLException {
    	 try {
    	        Class.forName("com.mysql.cj.jdbc.Driver");
    	    } catch (ClassNotFoundException e) {
    	        throw new SQLException("MySQL JDBC Driver not found.", e);
    	    }
    	    return DriverManager.getConnection(URL, USER, PASSWORD);
    	}
}
