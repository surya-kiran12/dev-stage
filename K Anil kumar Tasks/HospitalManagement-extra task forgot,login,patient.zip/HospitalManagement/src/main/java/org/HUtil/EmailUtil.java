package org.HUtil;

import java.util.Properties;
import javax.mail.*;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class EmailUtil {

    public static boolean sendEmail(String to, String subject, String message) {
        // Email credentials
        String from = "postmaster@sandboxe104fb0d839544ffa16f183a4ba3bed6.mailgun.org";
        String password = "b3d765478a4ff7b2ea1cde6562c3cd76-72e4a3d5-58dbb6f6";

        if (from == null || password == null) {
            System.err.println("Email credentials are not set.");
            return false;
        }

        Transport transport = null; // Initialize transport for explicit connection handling

        // Set SMTP properties
        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.mailgun.org");
        props.put("mail.smtp.port", "587");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");

        // Create session with authentication
        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

        try {
            // Open connection
            transport = session.getTransport("smtp");
            transport.connect("smtp.mailgun.org", from, password);
            System.out.println("Connection opened successfully.");

            // Create email message
            MimeMessage msg = new MimeMessage(session);
            msg.setFrom(new InternetAddress(from));
            msg.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
            msg.setSubject(subject);
            msg.setText(message);

            // Send email using the open connection
            transport.sendMessage(msg, msg.getAllRecipients());
            System.out.println("Email sent successfully to " + to);

            return true;
        } catch (MessagingException e) {
            System.err.println("Failed to send email: " + e.getMessage());
            e.printStackTrace();
            return false;
        } finally {
            // Ensure connection is closed
            if (transport != null) {
                try {
                    transport.close();
                    System.out.println("Connection closed successfully.");
                } catch (MessagingException e) {
                    System.err.println("Error while closing the connection: " + e.getMessage());
                }
            }
        }
    }
}
