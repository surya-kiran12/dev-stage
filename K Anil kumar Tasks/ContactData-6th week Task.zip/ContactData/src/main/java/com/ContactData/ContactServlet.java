package com.ContactData;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/contact")
public class ContactServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Retrieve form data from the request
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String subject = request.getParameter("subject");
        String message = request.getParameter("message");

        // Save the form data to the database
        boolean isSuccess = saveContactFormData(name, email, subject, message);

        // Send response to the client
        if (isSuccess) {
            response.getWriter().write("Contact form submitted successfully!");
        } else {
            response.getWriter().write("Failed to submit the contact form. Please check server logs for more details.");
        }
    }

    // Method to save the contact form data to the database
    private boolean saveContactFormData(String name, String email, String subject, String message) {
        String jdbcURL = "jdbc:mysql://localhost:3306/anil";
        String dbUser = "root";
        String dbPassword = "Anil@123";

        String sql = "INSERT INTO contacts (name, email, subject, message) VALUES (?, ?, ?, ?)";

        try {
            // Load MySQL driver (optional, depending on your JDBC version)
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish the connection
            try (Connection connection = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
                 PreparedStatement statement = connection.prepareStatement(sql)) {

                // Set values for the SQL query
                statement.setString(1, name);
                statement.setString(2, email);
                statement.setString(3, subject);
                statement.setString(4, message);

                // Execute update and check if any rows were affected
                int rows = statement.executeUpdate();
                return rows > 0;
            }
        } catch (SQLException e) {
            System.err.println("SQL error: " + e.getMessage());
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.err.println("JDBC Driver not found: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Unexpected error: " + e.getMessage());
            e.printStackTrace();
        }

        return false;
    }
}
