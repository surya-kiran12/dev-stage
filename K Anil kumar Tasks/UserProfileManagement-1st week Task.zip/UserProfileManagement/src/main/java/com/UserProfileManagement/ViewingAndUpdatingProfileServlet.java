package com.UserProfileManagement;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@WebServlet("")
@MultipartConfig(maxFileSize = 16177215)
public class ViewingAndUpdatingProfileServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Retrieve form parameters
        int userId = Integer.parseInt(request.getParameter("userId"));
        String username = request.getParameter("username");
        String email = request.getParameter("email");
        String fullName = request.getParameter("full_name");
        String phone = request.getParameter("phone");
        String gender = request.getParameter("gender");

        // Retrieve profile photo part
        Part profilePhotoPart = request.getPart("profile_photo");
        InputStream profilePhotoStream = null;

        if (profilePhotoPart != null) {
            profilePhotoStream = profilePhotoPart.getInputStream();
        }

        // Database connection setup
        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DatabaseConnection.initializeDatabase();

            // SQL query to update user profile
            stmt = conn.prepareStatement(
                    "UPDATE users SET username=?, email=?, full_name=?, phone=?, gender=?, profile_photo=? WHERE userId=?");

            // Set parameters for the update statement
            stmt.setString(1, username);
            stmt.setString(2, email);
            stmt.setString(3, fullName);
            stmt.setString(4, phone);
            stmt.setString(5, gender);

            if (profilePhotoStream != null) {
                stmt.setBlob(6, profilePhotoStream);
            } else {
                stmt.setNull(6, java.sql.Types.BLOB);
            }

            stmt.setInt(7, userId);

            // Execute update and check for success
            int rowCount = stmt.executeUpdate();
            if (rowCount > 0) {
                response.getWriter().write("Profile updated successfully.");
            } else {
                response.getWriter().write("Profile update failed. Please try again.");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("An error occurred while updating the profile.");

        } finally {
            // Ensure resources are closed in the finally block
            try {
                if (stmt != null) {
                    stmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
