package com.UserProfileManagement;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {
    private Connection connection;  

    // Constructor
    public UserDAO(Connection connection) {
        this.connection = connection;
    }

    // Method to retrieve a user from the database by their userId
    public User getUserById(int userId) throws SQLException {
        String query = "SELECT * FROM users WHERE userId = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, userId);
            ResultSet resultSet = statement.executeQuery();
            if (resultSet.next()) {
                return mapResultSetToUser(resultSet);
            }
        }
        return null;  
    }

    // Helper method to map result set to User object
    private User mapResultSetToUser(ResultSet resultSet) throws SQLException {
        User user = new User();
        user.setUserId(resultSet.getInt("userId"));
        user.setUsername(resultSet.getString("username"));
        user.setEmail(resultSet.getString("email"));
        user.setFullName(resultSet.getString("fullName"));
        user.setPhone(resultSet.getString("phone"));
        user.setGender(resultSet.getString("gender"));
        user.setProfilePhoto(resultSet.getBytes("profilePhoto"));
        return user;
    }

    // Method to update a user in the database
    public String updateUser(User user) throws SQLException {
        if (isFieldAlreadyUsed("username", user.getUsername(), user.getUserId())) {
            return "Username already in use.";
        }
        if (isFieldAlreadyUsed("email", user.getEmail(), user.getUserId())) {
            return "Email already in use.";
        }
        if (isFieldAlreadyUsed("phone", user.getPhone(), user.getUserId())) {
            return "Phone number already in use.";
        }

        String query = "UPDATE users SET username = ?, email = ?, full_name = ?, phone = ?, gender = ?, profile_photo = ? WHERE userId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, user.getEmail());
            stmt.setString(3, user.getFullName());
            stmt.setString(4, user.getPhone());
            stmt.setString(5, user.getGender());
            stmt.setBytes(6, user.getProfilePhoto());
            stmt.setInt(7, user.getUserId());

            int rowsAffected = stmt.executeUpdate();  
            return rowsAffected > 0 ? "Profile updated successfully." : "Failed to update profile."; 
        } catch (SQLException e) {
            e.printStackTrace();
            return "Error updating profile: " + e.getMessage();
        }
    }

    // Helper method to check if a field value is already in use by another user
    private boolean isFieldAlreadyUsed(String fieldName, String value, int userId) throws SQLException {
        String query = "SELECT COUNT(*) FROM users WHERE " + fieldName + " = ? AND userId != ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, value);
            stmt.setInt(2, userId);
            try (ResultSet rs = stmt.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }

    // Method to update only the user's profile photo
    public boolean updateProfilePhoto(int userId, byte[] profilePhoto) throws SQLException {
        String sql = "UPDATE users SET profile_photo = ? WHERE userId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setBytes(1, profilePhoto);
            stmt.setInt(2, userId); 
            return stmt.executeUpdate() > 0;
        }
    }

    // Method to retrieve a user's profile photo
    public byte[] getProfilePhoto(int userId) throws SQLException {
        String query = "SELECT profile_photo FROM users WHERE userId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return rs.getBytes("profile_photo");
            }
        }
        return null;
    }

    // Method to delete a user by userId
    public boolean deleteUser(int userId) throws SQLException {
        String query = "DELETE FROM users WHERE userId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, userId);
            return stmt.executeUpdate() > 0; 
        }
    }

    // Method to clear profile photo
    public boolean clearProfilePhoto(int userId) {
        String query = "UPDATE users SET profile_photo = NULL WHERE userId = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, userId);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Optional: Retrieve all users (for administrative purposes)
    public List<User> getAllUsers() throws SQLException {
        List<User> users = new ArrayList<>();
        String query = "SELECT * FROM users";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                users.add(mapResultSetToUser(rs));
            }
        }
        return users;
    }
}
