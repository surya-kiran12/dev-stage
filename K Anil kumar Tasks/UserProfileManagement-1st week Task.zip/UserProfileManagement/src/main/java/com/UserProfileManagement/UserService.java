package com.UserProfileManagement;

import java.sql.Connection;
import java.sql.SQLException;

public class UserService {
    private UserDAO userDAO;

    // Constructor receives a database connection, removing connection handling from UserService
    public UserService(Connection connection) {
        this.userDAO = new UserDAO(connection);  
    }

    // Method to view a user's profile by ID
    public User viewProfile(int userId) throws SQLException {
        return userDAO.getUserById(userId); 
    }

    // Method to update a user's profile
    public String updateProfile(User user) throws SQLException {
        return userDAO.updateUser(user); 
    }

    // Method to update only the profile photo
    public boolean updateProfilePhoto(int userId, byte[] profilePhoto) throws SQLException {
        return userDAO.updateProfilePhoto(userId, profilePhoto);
    }

    // Method to retrieve a user's profile photo
    public byte[] getProfilePhoto(int userId) throws SQLException {
        return userDAO.getProfilePhoto(userId); 
    }
}
