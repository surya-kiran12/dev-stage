package com.inventory;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

import com.utils.DatabaseConnection;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/InventoryServlet")
public class InventoryServlet extends HttpServlet {

    // Handle Add Inventory Item
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String itemName = request.getParameter("itemName");
        String quantityParam = request.getParameter("quantity");
        String priceParam = request.getParameter("price");

        // Validate required parameters
        if (itemName == null || itemName.isEmpty() ||
            quantityParam == null || quantityParam.isEmpty() ||
            priceParam == null || priceParam.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "All parameters (itemName, quantity, price) are required.");
            return;
        }

        int quantity = 0;
        double price = 0;
        try {
            quantity = Integer.parseInt(quantityParam);
            price = Double.parseDouble(priceParam);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid format for quantity or price.");
            return;
        }

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            String query = "INSERT INTO inventory (item_name, quantity, price) VALUES (?, ?, ?)";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, itemName);
            stmt.setInt(2, quantity);
            stmt.setDouble(3, price);
            int rowsAffected = stmt.executeUpdate();

            response.setContentType("text/plain");
            PrintWriter out = response.getWriter();
            if (rowsAffected > 0) {
                out.println("Item added successfully.");
            } else {
                out.println("Error adding item.");
            }
        } catch (SQLException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error closing database resources: " + e.getMessage());
            }
        }
    }

    // Handle Update Inventory Item
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String itemIdParam = request.getParameter("itemId");
        String itemName = request.getParameter("itemName");
        String quantityParam = request.getParameter("quantity");
        String priceParam = request.getParameter("price");
        if (itemIdParam == null || itemIdParam.isEmpty() ||
            itemName == null || itemName.isEmpty() ||
            quantityParam == null || quantityParam.isEmpty() ||
            priceParam == null || priceParam.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "All parameters (itemId, itemName, quantity, price) are required.");
            return;
        }

        int itemId = 0;
        int quantity = 0;
        double price = 0;
        try {
            itemId = Integer.parseInt(itemIdParam);
            quantity = Integer.parseInt(quantityParam);
            price = Double.parseDouble(priceParam);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid format for itemId, quantity, or price.");
            return;
        }

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            String query = "UPDATE inventory SET item_name = ?, quantity = ?, price = ? WHERE item_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setString(1, itemName);
            stmt.setInt(2, quantity);
            stmt.setDouble(3, price);
            stmt.setInt(4, itemId);
            int rowsAffected = stmt.executeUpdate();

            response.setContentType("text/plain");
            PrintWriter out = response.getWriter();
            if (rowsAffected > 0) {
                out.println("Item updated successfully.");
            } else {
                out.println("Error updating item.");
            }
        } catch (SQLException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error closing database resources: " + e.getMessage());
            }
        }
    }

    // Handle Delete Inventory Item
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String itemIdParam = request.getParameter("itemId");

        if (itemIdParam == null || itemIdParam.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "itemId is required.");
            return;
        }

        int itemId = 0;
        try {
            itemId = Integer.parseInt(itemIdParam);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid format for itemId.");
            return;
        }

        Connection conn = null;
        PreparedStatement stmt = null;

        try {
            conn = DatabaseConnection.getConnection();
            String query = "DELETE FROM inventory WHERE item_id = ?";
            stmt = conn.prepareStatement(query);
            stmt.setInt(1, itemId);
            int rowsAffected = stmt.executeUpdate();

            response.setContentType("text/plain");
            PrintWriter out = response.getWriter();
            if (rowsAffected > 0) {
                out.println("Item deleted successfully.");
            } else {
                out.println("Error deleting item.");
            }
        } catch (SQLException e) {
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, e.getMessage());
        } finally {
            try {
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error closing database resources: " + e.getMessage());
            }
        }
    }
}
