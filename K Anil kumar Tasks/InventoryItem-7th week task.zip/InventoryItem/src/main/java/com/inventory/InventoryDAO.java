package com.inventory;

import java.sql.*;
import com.utils.DatabaseConnection;

public class InventoryDAO {

    public boolean addInventoryItem(InventoryItem item) throws SQLException {
        String sql = "INSERT INTO inventory (item_name, quantity, price) VALUES (?, ?, ?)";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, item.getItemName());
            pstmt.setInt(2, item.getQuantity());
            pstmt.setDouble(3, item.getPrice());
            System.out.println("Executing SQL: " + pstmt);

            int rowsAffected = pstmt.executeUpdate();
            return rowsAffected > 0;
        } catch (SQLException e) {
            System.out.println("Error executing insert: " + e.getMessage());
            throw e;
        } finally {
            // Ensure that resources are closed properly
            closeResources(conn, pstmt, null);
        }
    }

    public boolean updateInventoryItem(InventoryItem item) throws SQLException {
        String sql = "UPDATE inventory SET item_name=?, quantity=?, price=? WHERE item_id=?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, item.getItemName());
            pstmt.setInt(2, item.getQuantity());
            pstmt.setDouble(3, item.getPrice());
            pstmt.setInt(4, item.getItemId());
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error executing update: " + e.getMessage());
            throw e;
        } finally {
            // Ensure that resources are closed properly
            closeResources(conn, pstmt, null);
        }
    }

    public boolean deleteInventoryItem(int itemId) throws SQLException {
        String sql = "DELETE FROM inventory WHERE item_id=?";
        Connection conn = null;
        PreparedStatement pstmt = null;
        try {
            conn = DatabaseConnection.getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setInt(1, itemId);
            return pstmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.out.println("Error executing delete: " + e.getMessage());
            throw e;
        } finally {
            // Ensure that resources are closed properly
            closeResources(conn, pstmt, null);
        }
    }

    // Helper method to close resources
    private void closeResources(Connection conn, PreparedStatement pstmt, ResultSet rs) {
        try {
            if (rs != null) {
                rs.close();
            }
            if (pstmt != null) {
                pstmt.close();
            }
            if (conn != null) {
                conn.close();
            }
        } catch (SQLException e) {
            System.out.println("Error closing resources: " + e.getMessage());
        }
    }
}
