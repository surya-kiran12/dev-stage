package com.inventory;

import java.sql.SQLException;

public class InventoryService {
    private InventoryDAO inventoryDAO = new InventoryDAO();

    // Add a new inventory item
    public String addInventoryItem(InventoryItem item) throws SQLException {
        try {
            boolean isAdded = inventoryDAO.addInventoryItem(item);
            if (isAdded) {
                return "Item added successfully.";
            } else {
                return "Failed to add item. Please check the details and try again.";
            }
        } catch (SQLException e) {
            System.err.println("Error adding inventory item: " + e.getMessage());
            return "Database error occurred while adding the item. Please try again later.";
        } finally {
           
        }
    }

    // Update an existing inventory item
    public String updateInventoryItem(InventoryItem item) throws SQLException {
        try {
            boolean isUpdated = inventoryDAO.updateInventoryItem(item);
            if (isUpdated) {
                return "Item updated successfully.";
            } else {
                return "Failed to update item. Item not found or invalid data.";
            }
        } catch (SQLException e) {
            System.err.println("Error updating inventory item: " + e.getMessage());
            return "Database error occurred while updating the item. Please try again later.";
        } finally {
            
        }
    }

    // Delete an inventory item
    public String deleteInventoryItem(int itemId) throws SQLException {
        try {
            boolean isDeleted = inventoryDAO.deleteInventoryItem(itemId);
            if (isDeleted) {
                return "Item deleted successfully.";
            } else {
                return "Failed to delete item. Item not found or already deleted.";
            }
        } catch (SQLException e) {
            System.err.println("Error deleting inventory item: " + e.getMessage());
            return "Database error occurred while deleting the item. Please try again later.";
        } finally {
            
        }
    }
}
