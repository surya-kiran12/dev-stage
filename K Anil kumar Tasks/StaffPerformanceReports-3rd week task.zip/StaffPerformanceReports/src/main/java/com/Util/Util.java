package com.Util;

import com.Model.StaffPerformance;
import jakarta.servlet.ServletOutputStream;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFFont;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import com.itextpdf.text.*;
import com.itextpdf.text.Font;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

public class Util {
    private static final String URL = "jdbc:mysql://localhost:3306/staff_performance_db";
    private static final String USER = "root"; 
    private static final String PASSWORD = "Anil@123"; 

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); 
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    // Method to generate Excel
    public static void generateExcel(List<StaffPerformance> performanceData, HttpServletResponse response) throws IOException {
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            Sheet sheet = workbook.createSheet("Staff Performance");

            // Create header row
            Row headerRow = sheet.createRow(0);
            CellStyle headerStyle = workbook.createCellStyle();
            XSSFFont headerFont = workbook.createFont();
            headerFont.setBold(true);
            headerStyle.setFont(headerFont);

            String[] headers = {"Staff Name", "Attendance", "Tasks Completed", "Hours Worked", "Performance Score"};
            for (int i = 0; i < headers.length; i++) {
                Cell cell = headerRow.createCell(i);
                cell.setCellValue(headers[i]);
                cell.setCellStyle(headerStyle);
            }

            // Fill data
            int rowNum = 1;
            for (StaffPerformance performance : performanceData) {
                Row row = sheet.createRow(rowNum++);
                row.createCell(0).setCellValue(performance.getStaffName());
                row.createCell(1).setCellValue(performance.getAttendance());
                row.createCell(2).setCellValue(performance.getNumberOfCases());
                row.createCell(3).setCellValue(performance.getHoursWorked()); 
                row.createCell(4).setCellValue(performance.getPerformanceScore());
            }

            // Auto-size columns
            for (int i = 0; i < headers.length; i++) {
                sheet.autoSizeColumn(i);
            }

            // Write to the output stream
            ServletOutputStream outputStream = response.getOutputStream();
            workbook.write(outputStream);
            outputStream.flush();
        }
    }

    // Method to generate PDF
    public static void generatePDF(List<StaffPerformance> performanceData, HttpServletResponse response) throws IOException {
        try {
            Document document = new Document();
            PdfWriter.getInstance(document, response.getOutputStream());

            document.open();

            Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 16);
            Paragraph title = new Paragraph("Staff Performance Report", titleFont);
            title.setAlignment(Element.ALIGN_CENTER);
            document.add(title);

            document.add(Chunk.NEWLINE);

            PdfPTable table = new PdfPTable(5); 
            table.setWidthPercentage(100);
            table.setWidths(new int[]{3, 2, 2, 2, 2});

            Font headerFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD);

            // Add table headers
            addTableHeader(table, headerFont, "Staff Name");
            addTableHeader(table, headerFont, "Attendance");
            addTableHeader(table, headerFont, "Tasks Completed");
            addTableHeader(table, headerFont, "Hours Worked"); 
            addTableHeader(table, headerFont, "Performance Score");

            // Add table rows
            for (StaffPerformance performance : performanceData) {
                table.addCell(performance.getStaffName());
                table.addCell(String.valueOf(performance.getAttendance()));
                table.addCell(String.valueOf(performance.getNumberOfCases()));
                table.addCell(String.valueOf(performance.getHoursWorked())); 
                table.addCell(String.valueOf(performance.getPerformanceScore()));
            }

            document.add(table);
            document.close();
        } catch (DocumentException e) {
            e.printStackTrace();
            throw new IOException("Error generating PDF", e);
        }
    }

    private static void addTableHeader(PdfPTable table, Font font, String text) {
        PdfPCell header = new PdfPCell();
        header.setPhrase(new Phrase(text, font));
        header.setHorizontalAlignment(Element.ALIGN_CENTER);
        table.addCell(header);
    }
}
