package com.Model;

public class WorkingHours {
    private String staffName;
    private int hoursWorked;
    private int extraHours; 

    public WorkingHours(String staffName, int hoursWorked, int extraHours) {
        this.staffName = staffName;
        this.hoursWorked = hoursWorked;
        this.extraHours = extraHours;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public int getHoursWorked() {
        return hoursWorked;
    }

    public void setHoursWorked(int hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    public int getExtraHours() {
        return extraHours;
    }

    public void setExtraHours(int extraHours) {
        this.extraHours = extraHours;
    }
}
