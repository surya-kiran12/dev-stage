package com.Model;

public class CustomerReview {
    private String staffName;
    private int reviewScore;

    public CustomerReview(String staffName, int reviewScore) {
        this.staffName = staffName;
        this.reviewScore = reviewScore;
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public int getReviewScore() {
        return reviewScore;
    }

    public void setReviewScore(int reviewScore) {
        this.reviewScore = reviewScore;
    }
}
