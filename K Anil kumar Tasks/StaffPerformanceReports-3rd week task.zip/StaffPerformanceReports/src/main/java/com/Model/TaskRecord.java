package com.Model;

public class TaskRecord {
    private String staffName;
    private int numberOfCases;

    // Constructor
    public TaskRecord(String staffName, int numberOfCases) {
        this.staffName = staffName;
        this.numberOfCases = numberOfCases;
    }

    // Getters and setters
    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public int getNumberOfCases() {
        return numberOfCases;
    }

    public void setNumberOfCases(int numberOfCases) {
        this.numberOfCases = numberOfCases;
    }
}
