package com.Model;

public class AttendanceRecord {
    private String staffName;
    private int daysPresent;

    public AttendanceRecord(String staffName, int daysPresent) {
        this.staffName = staffName;
        setDaysPresent(daysPresent); 
    }

    public String getStaffName() {
        return staffName;
    }

    public void setStaffName(String staffName) {
        this.staffName = staffName;
    }

    public int getDaysPresent() {
        return daysPresent;
    }

    public void setDaysPresent(int daysPresent) {
        if (daysPresent < 0) {
            throw new IllegalArgumentException("Days present cannot be negative.");
        }
        this.daysPresent = daysPresent;
    }
}
