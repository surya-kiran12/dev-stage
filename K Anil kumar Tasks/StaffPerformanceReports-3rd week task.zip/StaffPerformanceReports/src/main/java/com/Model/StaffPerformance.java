package com.Model;

public class StaffPerformance {
    private String staffName;
    private int attendance;
    private int numberOfCases;
    private int hoursWorked;
    private int performanceScore;
    
    public String getStaffName() {
		return staffName;
	}
	public void setStaffName(String staffName) {
		this.staffName = staffName;
	}
	public int getAttendance() {
		return attendance;
	}
	public void setAttendance(int attendance) {
		this.attendance = attendance;
	}
	public int getNumberOfCases() {
		return numberOfCases;
	}
	public void setNumberOfCases(int numberOfCases) {
		this.numberOfCases = numberOfCases;
	}
	public int getHoursWorked() {
		return hoursWorked;
	}
	public void setHoursWorked(int hoursWorked) {
		this.hoursWorked = hoursWorked;
	}
	public int getPerformanceScore() {
		return performanceScore;
	}
	public void setPerformanceScore(int performanceScore) {
		this.performanceScore = performanceScore;
	}
	
}
   