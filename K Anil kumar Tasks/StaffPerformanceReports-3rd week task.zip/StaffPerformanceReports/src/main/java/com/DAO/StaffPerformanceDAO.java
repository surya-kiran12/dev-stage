package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.Model.AttendanceRecord;
import com.Model.CustomerReview;
import com.Model.TaskRecord;
import com.Model.WorkingHours;
import com.Util.Util;

public class StaffPerformanceDAO {

    // Fetches attendance records from the database
    public List<AttendanceRecord> getAttendanceRecords() {
        List<AttendanceRecord> attendanceRecords = new ArrayList<>();
        String query = "SELECT staff_name, days_present FROM attendance";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = Util.getConnection();
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String staffName = resultSet.getString("staff_name");
                int daysPresent = resultSet.getInt("days_present");
                attendanceRecords.add(new AttendanceRecord(staffName, daysPresent));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching attendance records: " + e.getMessage());
        } finally {
            // Ensure that the resources are closed properly
            closeResources(connection, statement, resultSet);
        }

        return attendanceRecords;
    }

    // Fetches customer reviews from the database
    public List<CustomerReview> getCustomerReviews() {
        List<CustomerReview> reviews = new ArrayList<>();
        String query = "SELECT staff_name, review_score FROM customer_reviews";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = Util.getConnection();
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String staffName = resultSet.getString("staff_name");
                int reviewScore = resultSet.getInt("review_score");
                reviews.add(new CustomerReview(staffName, reviewScore));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching customer reviews: " + e.getMessage());
        } finally {
            // Ensure that the resources are closed properly
            closeResources(connection, statement, resultSet);
        }

        return reviews;
    }

    // Fetches task records from the database
    public List<TaskRecord> getTaskRecords() {
        List<TaskRecord> taskRecords = new ArrayList<>();
        String query = "SELECT staff_name, number_of_cases FROM tasks";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = Util.getConnection();
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String staffName = resultSet.getString("staff_name");
                int numberOfCases = resultSet.getInt("number_of_cases");
                taskRecords.add(new TaskRecord(staffName, numberOfCases));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching task records: " + e.getMessage());
        } finally {
            // Ensure that the resources are closed properly
            closeResources(connection, statement, resultSet);
        }

        return taskRecords;
    }

    // Fetches working hours from the database
    public List<WorkingHours> getWorkingHours() {
        List<WorkingHours> workingHoursList = new ArrayList<>();
        String query = "SELECT staff_name, hours_worked, extra_hours FROM working_hours";
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = Util.getConnection();
            statement = connection.prepareStatement(query);
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                String staffName = resultSet.getString("staff_name");
                int hoursWorked = resultSet.getInt("hours_worked");
                int extraHours = resultSet.getInt("extra_hours");
                workingHoursList.add(new WorkingHours(staffName, hoursWorked, extraHours));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching working hours: " + e.getMessage());
        } finally {
            // Ensure that the resources are closed properly
            closeResources(connection, statement, resultSet);
        }

        return workingHoursList;
    }

    // Helper method to close the resources
    private void closeResources(Connection connection, PreparedStatement statement, ResultSet resultSet) {
        try {
            if (resultSet != null) {
                resultSet.close();
            }
            if (statement != null) {
                statement.close();
            }
            if (connection != null) {
                connection.close();
            }
        } catch (SQLException e) {
            System.err.println("Error closing resources: " + e.getMessage());
        }
    }
}
