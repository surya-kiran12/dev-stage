package com.Services;

import com.DAO.StaffPerformanceDAO; 
import com.Model.AttendanceRecord;
import com.Model.CustomerReview;
import com.Model.StaffPerformance;
import com.Model.TaskRecord;
import com.Model.WorkingHours;

import java.util.List;
import java.util.stream.Collectors;

public class StaffPerformanceService {
    private StaffPerformanceDAO staffPerformanceDAO;

    public StaffPerformanceService() {
        this.staffPerformanceDAO = new StaffPerformanceDAO(); 
    }

    // Method to get staff performance
    public List<StaffPerformance> getStaffPerformance() {
        List<AttendanceRecord> attendanceRecords = staffPerformanceDAO.getAttendanceRecords();
        List<TaskRecord> taskRecords = staffPerformanceDAO.getTaskRecords();
        List<CustomerReview> reviews = staffPerformanceDAO.getCustomerReviews();
        List<WorkingHours> workingHoursList = staffPerformanceDAO.getWorkingHours();

        return attendanceRecords.stream()
            .map(attendance -> {
                String staffName = attendance.getStaffName();
                int daysPresent = attendance.getDaysPresent();

                // Calculate number of cases for the staff member
                int numberOfCases = taskRecords.stream()
                    .filter(task -> task.getStaffName().equals(staffName))
                    .mapToInt(TaskRecord::getNumberOfCases)
                    .sum();

                // Calculate review score for the staff member
                int reviewScore = reviews.stream()
                    .filter(review -> review.getStaffName().equals(staffName))
                    .mapToInt(CustomerReview::getReviewScore)
                    .sum();

                // Get working hours for the staff member
                WorkingHours workingHours = workingHoursList.stream()
                    .filter(hours -> hours.getStaffName().equals(staffName))
                    .findFirst()
                    .orElse(new WorkingHours(staffName, 0, 0));

                int hoursWorked = workingHours.getHoursWorked();
                int extraHours = workingHours.getExtraHours();

                // Calculate performance score
                int performanceScore = calculatePerformanceScore(daysPresent, numberOfCases, reviewScore, hoursWorked, extraHours);

                // Create StaffPerformance object
                StaffPerformance staffPerformance = new StaffPerformance();
                staffPerformance.setStaffName(staffName);
                staffPerformance.setAttendance(daysPresent);
                staffPerformance.setNumberOfCases(numberOfCases);
                staffPerformance.setHoursWorked(hoursWorked);
                staffPerformance.setPerformanceScore(performanceScore);

                return staffPerformance;
            })
            .collect(Collectors.toList());
    }

    // Method to get staff performance by name
    public List<StaffPerformance> getStaffPerformanceByName(String staffName) {
        return getStaffPerformance().stream()
            .filter(sp -> sp.getStaffName().equalsIgnoreCase(staffName))
            .collect(Collectors.toList());
    }

    // Method to calculate performance score
    private int calculatePerformanceScore(int daysPresent, int numberOfCases, int reviewScore, int hoursWorked, int extraHours) {
        return (int) (0.2 * daysPresent + 0.1 * numberOfCases + 0.4 * reviewScore + 0.2 * hoursWorked + 0.1 * extraHours);
    }
}
 