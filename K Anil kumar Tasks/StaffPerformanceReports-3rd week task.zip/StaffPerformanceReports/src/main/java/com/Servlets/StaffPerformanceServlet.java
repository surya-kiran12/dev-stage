package com.Servlets;

import com.Model.StaffPerformance;
import com.Services.StaffPerformanceService; 
import com.Util.Util;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/api/staff-performance")
public class StaffPerformanceServlet extends HttpServlet {
    private final StaffPerformanceService service = new StaffPerformanceService();  

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            if ("export".equalsIgnoreCase(action)) {
                exportReport(request, response);
            } else if ("getPerformance".equalsIgnoreCase(action)) {
                getStaffPerformance(request, response);
            }
        } catch (Exception e) {
            handleError(response, e);
        } finally {
            
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            if ("getPerformanceData".equalsIgnoreCase(action)) {
                getPerformanceData(request, response);
            } else if ("search".equalsIgnoreCase(action)) {
                searchPerformance(request, response);
            }
        } catch (Exception e) {
            handleError(response, e);
        } finally {
            
        }
    }

    // Method to handle exporting the report in PDF or Excel format
    private void exportReport(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String format = request.getParameter("format");
        List<StaffPerformance> performanceData = service.getStaffPerformance();

        try {
            if ("pdf".equalsIgnoreCase(format)) {
                response.setContentType("application/pdf");
                response.setHeader("Content-Disposition", "attachment;filename=StaffPerformanceReport.pdf");
                Util.generatePDF(performanceData, response); 
            } else if ("excel".equalsIgnoreCase(format)) {
                response.setContentType("application/vnd.ms-excel");
                response.setHeader("Content-Disposition", "attachment;filename=StaffPerformanceReport.xlsx");
                Util.generateExcel(performanceData, response);
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid format. Please choose PDF or Excel.");
            }
        } catch (IOException e) {
            handleError(response, e);
        } finally {
            
        }
    }

    // Method to retrieve staff performance data based on the staff name provided
    private void getStaffPerformance(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String staffName = request.getParameter("staffName");
        List<StaffPerformance> performanceData = null;

        try {
            // If no staff name is provided, retrieve all performance data
            if (staffName == null || staffName.trim().isEmpty()) {
                performanceData = service.getStaffPerformance();
            } else {
                performanceData = service.getStaffPerformanceByName(staffName);
            }

            // Set the data in the request scope and forward it to the JSP
            request.setAttribute("performanceData", performanceData);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/staffPerformance.jsp");
            dispatcher.forward(request, response);
        } catch (Exception e) {
            handleError(response, e);
        } finally {
            
        }
    }

    // Method to retrieve all performance data
    private void getPerformanceData(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<StaffPerformance> performanceData = null;

        try {
            performanceData = service.getStaffPerformance();
            request.setAttribute("performanceData", performanceData);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/staffPerformance.jsp");
            dispatcher.forward(request, response);
        } catch (Exception e) {
            handleError(response, e);
        } finally {
         
        }
    }

    // Method to search for specific performance data based on staff name
    private void searchPerformance(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String staffName = request.getParameter("staffName");
        List<StaffPerformance> searchResults = null;

        try {
            searchResults = service.getStaffPerformanceByName(staffName);
            request.setAttribute("searchResults", searchResults);
            RequestDispatcher dispatcher = request.getRequestDispatcher("/searchResults.jsp");
            dispatcher.forward(request, response);
        } catch (Exception e) {
            handleError(response, e);
        } finally {
            
        }
    }

    // Method to handle errors and send a proper error response
    private void handleError(HttpServletResponse response, Exception e) throws IOException {
        response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        response.getWriter().write("An error occurred: " + e.getMessage());
        e.printStackTrace();
    }
}
