package org.system.activity;

import com.itextpdf.text.Document;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import jakarta.servlet.http.HttpServletResponse;

import java.util.List;

public class ReportGenerator {
    public static void generatePDF(List<SystemActivity> activities, double avgResponseTime, HttpServletResponse response) throws Exception {
        Document document = new Document();
        PdfWriter.getInstance(document, response.getOutputStream());
        document.open();

        document.add(new Paragraph("System Activity Report"));
        document.add(new Paragraph("Average Response Time: " + avgResponseTime + " ms\n"));

        PdfPTable table = new PdfPTable(6);
        table.addCell("ID");
        table.addCell("Activity Type");
        table.addCell("User Name");
        table.addCell("Timestamp");
        table.addCell("Status");
        table.addCell("Response Time");

        for (SystemActivity activity : activities) {
            table.addCell(String.valueOf(activity.getId()));
            table.addCell(activity.getActivityType());
            table.addCell(activity.getUserName());
            table.addCell(String.valueOf(activity.getTimestamp()));
            table.addCell(activity.getStatus());
            table.addCell(String.valueOf(activity.getResponseTime()));
        }
        document.add(table);
        document.close();
    }

    public static void generateExcel(List<SystemActivity> activities, double avgResponseTime, HttpServletResponse response) throws Exception {
        XSSFWorkbook workbook = new XSSFWorkbook();
        var sheet = workbook.createSheet("System Activity Report");

        Row header = sheet.createRow(0);
        header.createCell(0).setCellValue("ID");
        header.createCell(1).setCellValue("Activity Type");
        header.createCell(2).setCellValue("User Name");
        header.createCell(3).setCellValue("Timestamp");
        header.createCell(4).setCellValue("Status");
        header.createCell(5).setCellValue("Response Time");

        int rowNum = 1;
        for (SystemActivity activity : activities) {
            Row row = sheet.createRow(rowNum++);
            row.createCell(0).setCellValue(activity.getId());
            row.createCell(1).setCellValue(activity.getActivityType());
            row.createCell(2).setCellValue(activity.getUserName());
            row.createCell(3).setCellValue(activity.getTimestamp());
            row.createCell(4).setCellValue(activity.getStatus());
            row.createCell(5).setCellValue(activity.getResponseTime());
        }

        workbook.write(response.getOutputStream());
        workbook.close();
    }
}
