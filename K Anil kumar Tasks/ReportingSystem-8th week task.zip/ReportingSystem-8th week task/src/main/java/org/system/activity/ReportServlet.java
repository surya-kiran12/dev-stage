package org.system.activity;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet("/GenerateReport")
public class ReportServlet extends HttpServlet {
    private SystemActivityService service;

    @Override
    public void init() throws ServletException {
        try {
            SystemActivityDAO dao = new SystemActivityDAO();
            service = new SystemActivityService(dao);
        } catch (Exception e) {
            throw new ServletException("Error initializing service", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String filterType = request.getParameter("filterType");
        String filterValue = request.getParameter("filterValue");
        String format = request.getParameter("format");

        try {
            if (filterType == null || filterValue == null || format == null) {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing parameters");
                return;
            }

            List<SystemActivity> activities = service.getFilteredActivities(filterType, filterValue);
            double avgResponseTime = service.calculateAverageResponseTime(activities);

            if ("PDF".equalsIgnoreCase(format)) {
                ReportGenerator.generatePDF(activities, avgResponseTime, response);
            } else if ("Excel".equalsIgnoreCase(format)) {
                ReportGenerator.generateExcel(activities, avgResponseTime, response);
            } else {
                request.setAttribute("activities", activities);
                request.setAttribute("avgResponseTime", avgResponseTime);
                request.getRequestDispatcher("Report.jsp").forward(request, response);
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error generating report");
        }
    }
}
