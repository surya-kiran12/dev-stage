package org.system.activity;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SystemActivityDAO {
    private Connection connection;

    public SystemActivityDAO() throws SQLException {
        this.connection = DatabaseConnection.getConnection();
    }

    // Fetch filtered system activities
    public List<SystemActivity> getSystemActivities(String filterType, String filterValue) throws SQLException {
        List<SystemActivity> activities = new ArrayList<>();
        String query = "SELECT * FROM system_activity WHERE " + filterType + " = ?";
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            stmt = connection.prepareStatement(query);
            stmt.setString(1, filterValue);

            rs = stmt.executeQuery();

            while (rs.next()) {
                SystemActivity activity = new SystemActivity();
                activity.setId(rs.getInt("id"));
                activity.setActivityType(rs.getString("activity_type"));
                activity.setUserName(rs.getString("user_name"));
                activity.setTimestamp(rs.getLong("timestamp"));
                activity.setStatus(rs.getString("status"));
                activity.setResponseTime(rs.getDouble("response_time"));
                activities.add(activity);
            }
        } catch (SQLException e) {
            
            System.err.println("Error fetching system activities: " + e.getMessage());
            e.printStackTrace();
            throw new SQLException("Error fetching system activities", e);
        } finally {
           
            if (rs != null) {
                try {
                    rs.close();
                } catch (SQLException e) {
                    System.err.println("Error closing ResultSet: " + e.getMessage());
                    e.printStackTrace();
                }
            }
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    System.err.println("Error closing PreparedStatement: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }

        return activities;
    }

    // Insert a system activity record
    public void insertActivity(SystemActivity activity) throws SQLException {
        String query = "INSERT INTO system_activity (activity_type, user_name, timestamp, status, response_time) VALUES (?, ?, ?, ?, ?)";
        PreparedStatement stmt = null;

        try {
            stmt = connection.prepareStatement(query);
            stmt.setString(1, activity.getActivityType());
            stmt.setString(2, activity.getUserName());
            stmt.setLong(3, activity.getTimestamp());
            stmt.setString(4, activity.getStatus());
            stmt.setDouble(5, activity.getResponseTime());
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("Error inserting system activity: " + e.getMessage());
            e.printStackTrace();
            throw new SQLException("Error inserting system activity", e);
        } finally {
            if (stmt != null) {
                try {
                    stmt.close();
                } catch (SQLException e) {
                    System.err.println("Error closing PreparedStatement: " + e.getMessage());
                    e.printStackTrace();
                }
            }
        }
    }
}
