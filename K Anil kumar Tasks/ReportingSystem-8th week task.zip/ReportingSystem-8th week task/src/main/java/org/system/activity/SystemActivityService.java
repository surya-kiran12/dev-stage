package org.system.activity;

import java.util.List;

public class SystemActivityService {
    private SystemActivityDAO dao;

    public SystemActivityService(SystemActivityDAO dao) {
        this.dao = dao;
    }

    public List<SystemActivity> getFilteredActivities(String filterType, String filterValue) throws Exception {
        return dao.getSystemActivities(filterType, filterValue);
    }

    public double calculateAverageResponseTime(List<SystemActivity> activities) {
        return activities.stream()
                         .mapToDouble(SystemActivity::getResponseTime)
                         .average()
                         .orElse(0.0);
    }
}
