package com.AddingAndRemoving;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class CartDAO {
    private Connection connection;

    public CartDAO(Connection connection) {
        this.connection = connection;
    }

   
    public void addItemToCart(CartItem item) throws SQLException {
        String query = "INSERT INTO cart (productId, productName, price, quantity, seller, image) VALUES (?, ?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, item.getProductId());
            statement.setString(2, item.getProductName());
            statement.setDouble(3, item.getPrice());
            statement.setInt(4, item.getQuantity());
            statement.setString(5, item.getSeller());
            statement.setString(6, item.getImage());
            statement.executeUpdate();
        }
    }

    
    public void removeItemFromCart(int id) throws SQLException {
        String query = "DELETE FROM cart WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, id);
            statement.executeUpdate();
        }
    }

   
    public List<CartItem> getAllCartItems() throws SQLException {
        List<CartItem> items = new ArrayList<>();
        String query = "SELECT * FROM cart";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(query)) {
            while (resultSet.next()) {
                CartItem item = new CartItem();
                item.setId(resultSet.getInt("id"));
                item.setProductId(resultSet.getInt("productId"));
                item.setProductName(resultSet.getString("productName"));
                item.setPrice(resultSet.getDouble("price"));
                item.setQuantity(resultSet.getInt("quantity"));
                item.setSeller(resultSet.getString("seller"));
                item.setImage(resultSet.getString("image"));
                items.add(item);
            }
        }
        return items;
    }
}
