package com.AddingAndRemoving;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/Cart")
public class CartServlet extends HttpServlet {
    private CartService cartService;
    private Connection connection;

    @Override
    public void init() throws ServletException {
        try {
            
            String dbURL = "jdbc:mysql://localhost:3306/ShoppingCartDB";
            String dbUser = "root";
            String dbPassword = "password";
            
         
            connection = DriverManager.getConnection(dbURL, dbUser, dbPassword);
            this.cartService = new CartService(connection);
        } catch (SQLException e) {
            throw new ServletException("Database connection problem", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        List<CartItem> cartItems = null;
        try {
           
            cartItems = cartService.getAllCartItems();
            request.setAttribute("cartItems", cartItems);
            RequestDispatcher dispatcher = request.getRequestDispatcher("cart.jsp");
            dispatcher.forward(request, response);
        } catch (SQLException e) {
            throw new ServletException("Error retrieving cart items", e);
        } finally {
            
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        String action = request.getParameter("action");
        try {
            if ("add".equals(action)) {
               
                int productId = Integer.parseInt(request.getParameter("productId"));
                String productName = request.getParameter("productName");
                double price = Double.parseDouble(request.getParameter("price"));
                int quantity = Integer.parseInt(request.getParameter("quantity"));
                String seller = request.getParameter("seller");
                String image = request.getParameter("image");

                CartItem item = new CartItem();
                item.setProductId(productId);
                item.setProductName(productName);
                item.setPrice(price);
                item.setQuantity(quantity);
                item.setSeller(seller);
                item.setImage(image);

                cartService.addItemToCart(item);
            } else if ("remove".equals(action)) {
            
                int id = Integer.parseInt(request.getParameter("id"));
                cartService.removeItemFromCart(id);
            }
            response.sendRedirect("CartServlet");
        } catch (SQLException e) {
            throw new ServletException("Error processing cart action", e);
        } finally {
          
        }
    }

    @Override
    public void destroy() {
      
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
