package com.AddingAndRemoving;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public class CartService {
    private CartDAO cartDAO;

    public CartService(Connection connection) {
        this.cartDAO = new CartDAO(connection);
    }

    public void addItemToCart(CartItem item) throws SQLException {
        cartDAO.addItemToCart(item);
    }

    public void removeItemFromCart(int id) throws SQLException {
        cartDAO.removeItemFromCart(id);
    }

    public List<CartItem> getAllCartItems() throws SQLException {
        return cartDAO.getAllCartItems();
    }
}
