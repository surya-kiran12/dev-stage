package com.model;

public class Report {
    private String patientName;
    private String reportType;
    private String startDate;
    private String endDate;

    
    public Report(String patientName, String reportType, String startDate, String endDate) {
        this.patientName = sanitizeInput(patientName);
        this.reportType = sanitizeInput(reportType);
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public Report() {
		
	}

	public String getPatientName() {
        return patientName;
    }

    public String getReportType() {
        return reportType;
    }

    public String getStartDate() {
        return startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    private String sanitizeInput(String input) {
        return input.replaceAll("[^a-zA-Z0-9\\s]", "");
    }

	public void setPatientName(String string) {
	
		
	}

	public void setReportType(String string) {
		
		
	}

	public void setReportDate(String string) {

		
	}

	public static Report getReport(String patientName2, String reportType2, String startDate2, String endDate2) {
		
		return null;
	}
}
