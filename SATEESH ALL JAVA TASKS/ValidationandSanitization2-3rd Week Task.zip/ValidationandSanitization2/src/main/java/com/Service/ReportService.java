package com.Service;
import java.sql.SQLException;


import com.Servlet.ReportServlet;
import com.model.Report;

public class ReportService {
    private ReportServlet reportServlet = new ReportServlet();

    public Report generateReport(String patientName, String reportType, String startDate, String endDate) throws SQLException {
        if (validateInput(patientName, reportType, startDate, endDate)) {
            return Report.getReport(patientName, reportType, startDate, endDate);
        } else {
            throw new IllegalArgumentException("Invalid input data.");
        }
    }

    private boolean validateInput(String patientName, String reportType, String startDate, String endDate) {
        if (patientName == null || patientName.isEmpty() || !patientName.matches("[a-zA-Z\\s]+")) {
            return false;
        }
        if (!reportType.equals("Patient Test Report") && !reportType.equals("Medical Report")) {
            return false;
        }
        if (startDate == null || endDate == null || startDate.compareTo(endDate) > 0) {
            return false;
        }
        return true;
    }
}
