package com.Servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.model.Report;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/DataValidation2")
public class ReportServlet extends HttpServlet {

    private static final String URL = "jdbc:mysql://localhost:3306/your_database";
    private static final String USER = "root";
    private static final String PASSWORD = "password";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String patientName = sanitizeInput(request.getParameter("patientName"));
        String reportType = sanitizeInput(request.getParameter("reportType"));
        String startDate = request.getParameter("startDate");
        String endDate = request.getParameter("endDate");

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            
            connection = DriverManager.getConnection(URL, USER, PASSWORD);

        
            String sql = "SELECT * FROM reports WHERE patientName = ? AND reportType = ? AND reportDate BETWEEN ? AND ?";
            preparedStatement = connection.prepareStatement(sql);
            preparedStatement.setString(1, patientName);
            preparedStatement.setString(2, reportType);
            preparedStatement.setString(3, startDate);
            preparedStatement.setString(4, endDate);
            resultSet = preparedStatement.executeQuery();

            Report report = null;
            if (resultSet.next()) {
                report = new Report();
           
                report.setPatientName(resultSet.getString("patientName"));
                report.setReportType(resultSet.getString("reportType"));
                report.setReportDate(resultSet.getString("reportDate"));
          
            }

            if (report != null) {
                request.setAttribute("report", report);
                request.getRequestDispatcher("/reportDisplay.jsp").forward(request, response);
            } else {
                response.getWriter().write("No report found for the given criteria.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("Database error: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            response.getWriter().write("Invalid input: " + e.getMessage());
        } finally {
       
            if (resultSet != null) {
                try {
                    resultSet.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (preparedStatement != null) {
                try {
                    preparedStatement.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            if (connection != null) {
                try {
                    connection.close();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private String sanitizeInput(String input) {
        return input.replaceAll("[^a-zA-Z0-9\\s]", ""); 
    }
}
