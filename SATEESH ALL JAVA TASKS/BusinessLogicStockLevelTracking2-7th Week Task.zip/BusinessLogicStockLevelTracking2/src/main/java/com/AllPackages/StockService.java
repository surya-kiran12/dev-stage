package com.AllPackages;

import java.util.List;
import java.util.stream.Collectors;

public class StockService {
    private StockDAO stockDAO = new StockDAO();

   
    public List<StockItem> getLowStockItems() {
        List<StockItem> allStockItems = stockDAO.getAllStockItems();
        return allStockItems.stream()
                .filter(item -> item.getQuantity() < item.getAlertThreshold())
                .collect(Collectors.toList());
    }
}
