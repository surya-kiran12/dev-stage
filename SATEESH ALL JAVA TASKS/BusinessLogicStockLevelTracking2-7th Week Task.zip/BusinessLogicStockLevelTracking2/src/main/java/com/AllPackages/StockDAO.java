package com.AllPackages;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StockDAO {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/sateeshdb";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "sateesh@123";

  
    private Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("com.mysql.cj.jdbc.Driver");
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    
    public List<StockItem> getAllStockItems() {
        List<StockItem> stockItems = new ArrayList<>();
        Connection conn = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        try {
            conn = getConnection();
            String query = "SELECT * FROM stock_table";
            stmt = conn.prepareStatement(query);
            rs = stmt.executeQuery();

            while (rs.next()) {
                StockItem item = new StockItem();
                item.setItemId(rs.getInt("item_id"));
                item.setItemName(rs.getString("item_name"));
                item.setQuantity(rs.getInt("quantity"));
                item.setAlertThreshold(rs.getInt("alert_threshold"));
                stockItems.add(item);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
           
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return stockItems;
    }
}
