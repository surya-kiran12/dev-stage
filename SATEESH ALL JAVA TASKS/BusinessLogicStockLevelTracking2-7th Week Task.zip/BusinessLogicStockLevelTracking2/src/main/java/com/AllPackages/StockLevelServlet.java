package com.AllPackages;

import jakarta.servlet.ServletException;

import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;


public class StockLevelServlet extends HttpServlet {
    
	private static final long serialVersionUID = 1L;
	private StockService stockService = new StockService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        List<StockItem> lowStockItems = stockService.getLowStockItems();
    
        request.setAttribute("lowStockItems", lowStockItems);
        request.getRequestDispatcher("/stockNotifications.jsp").forward(request, response);
    }
}
