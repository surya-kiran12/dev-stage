package com.Servlet;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.Service.ReportService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

@MultipartConfig
public class FileUploadServlet extends HttpServlet {

    private static final Logger LOGGER = Logger.getLogger(FileUploadServlet.class.getName());
    private final ReportService reportService = new ReportService();
    private static final String URL = "jdbc:mysql://localhost:3306/your_database_name";
    private static final String USER = "root";
    private static final String PASSWORD = "password";

    private static Connection connection;

    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            LOGGER.log(Level.SEVERE, "Database connection initialization failed!", e);
        }
    }

    public static Connection getConnection() {
        return connection;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        Part filePart = request.getPart("file");
        String fileName = filePart.getSubmittedFileName();
        InputStream fileContent = null;

        try {
            fileContent = filePart.getInputStream();

            
            boolean success = reportService.uploadReport(fileName, fileContent, getServletContext().getRealPath(""));

            if (success) {
                request.setAttribute("message", "File uploaded and saved successfully: " + fileName);
            } else {
                request.setAttribute("message", "Error occurred while saving the file.");
            }
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "File upload failed!", e);
            request.setAttribute("message", "Error occurred: " + e.getMessage());
        } finally {
           
            if (fileContent != null) {
                try {
                    fileContent.close();
                } catch (IOException e) {
                    LOGGER.log(Level.WARNING, "Failed to close file input stream", e);
                }
            }
           
        }

        getServletContext().getRequestDispatcher("/uploadResult.jsp").forward(request, response);
    }

    @Override
    public void destroy() {
       
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException e) {
                LOGGER.log(Level.SEVERE, "Failed to close database connection", e);
            }
        }
    }
}
