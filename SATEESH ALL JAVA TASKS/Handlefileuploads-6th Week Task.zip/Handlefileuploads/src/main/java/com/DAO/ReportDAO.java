package com.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.Model.Report;
import com.Servlet.FileUploadServlet;

public class ReportDAO {

   
    private static final String INSERT_REPORT_SQL = "INSERT INTO reports (file_name, file_path, upload_date) VALUES (?, ?, ?)";

    public boolean saveReport(Report report) {
        try (Connection connection = FileUploadServlet.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_REPORT_SQL)) {

        
            preparedStatement.setString(1, report.getFileName());
            preparedStatement.setString(2, report.getFilePath());
            preparedStatement.setDate(3, new java.sql.Date(report.getUploadDate().getTime()));

      
            return preparedStatement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
