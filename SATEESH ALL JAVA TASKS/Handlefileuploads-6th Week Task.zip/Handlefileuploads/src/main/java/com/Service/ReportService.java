package com.Service;

import java.io.File;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Date;

import com.DAO.ReportDAO;
import com.Model.Report;

public class ReportService {

    private static final String UPLOAD_DIRECTORY = "uploads";
    private final ReportDAO reportDAO;

    public ReportService() {
        this.reportDAO = new ReportDAO();
    }

    public boolean uploadReport(String fileName, InputStream fileContent, String contextPath) throws Exception {
       
        File uploadDir = new File(contextPath + File.separator + UPLOAD_DIRECTORY);
        if (!uploadDir.exists()) {
            uploadDir.mkdir();
        }

       
        String filePath = uploadDir.getAbsolutePath() + File.separator + fileName;

       
        File fileToSave = new File(filePath);
        try (InputStream input = fileContent) {
            Files.copy(input, fileToSave.toPath(), StandardCopyOption.REPLACE_EXISTING);
        }

        
        Report report = new Report(0, fileName, filePath, new Date());
        return reportDAO.saveReport(report);
    }
}
