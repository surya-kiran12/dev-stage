package AllPackages;
 
import org.apache.catalina.User;
 
public class UserService {
	    private UserDAO userDAO;
 
	    public UserService() {
	        this.userDAO = new UserDAO();
	    }
 
	    public AllPackages.User authenticate(String username, String password) {
	        return userDAO.getUserByUsernameAndPassword(username, password);
	    }
	}