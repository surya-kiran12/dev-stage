package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.google.gson.Gson;
import com.modal.Items;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/item")
public class ItemServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database connection details
    private static final String URL = "jdbc:mysql://localhost:3306/your_database";
    private static final String USER = "your_db_user";
    private static final String PASSWORD = "your_db_password";

    // Load MySQL driver
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String itemIdParam = request.getParameter("item_id");
        String type = request.getParameter("type");

        if (itemIdParam == null || itemIdParam.isEmpty() || type == null || type.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing item_id or type parameter");
            return;
        }

        int itemId = Integer.parseInt(itemIdParam);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Gson gson = new Gson();

        switch (type.toLowerCase()) {
            case "details":
                Items itemDetails = getItemDetails(itemId);
                out.print(gson.toJson(itemDetails));
                break;
            case "price":
                Double price = getItemPrice(itemId);
                out.print(gson.toJson(price));
                break;
            case "availability":
                Integer stock = getItemAvailability(itemId);
                out.print(gson.toJson(stock));
                break;
            default:
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid type parameter");
                return;
        }
        out.flush();
    }

    private Items getItemDetails(int itemId) {
        Items item = null;
        String query = "SELECT id, name, description FROM items WHERE id = ?";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, itemId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                item = new Items();
                item.setId(resultSet.getInt("id"));
                item.setName(resultSet.getString("name"));
                item.setDescription(resultSet.getString("description"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return item;
    }

    private Double getItemPrice(int itemId) {
        Double price = null;
        String query = "SELECT price FROM items WHERE id = ?";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, itemId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                price = resultSet.getDouble("price");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return price;
    }

    private Integer getItemAvailability(int itemId) {
        Integer stock = null;
        String query = "SELECT stock FROM items WHERE id = ?";

        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {

            preparedStatement.setInt(1, itemId);
            ResultSet resultSet = preparedStatement.executeQuery();

            if (resultSet.next()) {
                stock = resultSet.getInt("stock");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return stock;
    }
}
