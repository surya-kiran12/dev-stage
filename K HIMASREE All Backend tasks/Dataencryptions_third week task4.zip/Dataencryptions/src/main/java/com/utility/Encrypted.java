package com.utility;

import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

public class Encrypted {
	private static final String ALGORITHM = "AES" ;
	
	// Genarate a new secrete key
	public static SecretKey generateSecretKey()throws Exception {
		KeyGenerator keyGen = KeyGenerator.getInstance(ALGORITHM);
		keyGen.init(128); 
		return keyGen.generateKey();
		
	}
	
	//Encrypt data useing AES
	
	public static String encrypt(String data, SecretKey SecretKey) throws Exception {
		Cipher cipher = Cipher.getInstance(ALGORITHM);
		cipher.init(Cipher.ENCRYPT_MODE, SecretKey);
		byte[] encryptedBytes = cipher.doFinal(data.getBytes());
		return Base64.getEncoder().encodeToString(encryptedBytes);
		
	}
	
	//Decrypt data use AES
	
	public static String decrypt(String encryptedData, SecretKey secretkey) throws Exception {
		Cipher cipher = Cipher.getInstance(ALGORITHM);
		cipher.init(Cipher.DECRYPT_MODE, secretkey);
		byte[] decryptedBytes = cipher.doFinal(Base64.getDecoder().decode(encryptedData));
		return new String(decryptedBytes);
		
	}

}
