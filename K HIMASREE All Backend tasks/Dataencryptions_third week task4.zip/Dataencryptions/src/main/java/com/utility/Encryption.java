package com.utility;

import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class Encryption {
	private static final String ALGORITHM = "AES";
	private static final byte[] KEY = "SecretKey".getBytes(); //Example key, ensure to manage keys securely in production
	
	public static String encrypt(String data) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(KEY,ALGORITHM);
		Cipher cipher = Cipher.getInstance(ALGORITHM);
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		byte[] encryptedDate = cipher.doFinal(data.getBytes());
		return Base64.getEncoder().encodeToString(encryptedDate);
		
	}
	
	public static String decrypt(String encryptedData) throws Exception {
		SecretKeySpec secretKey = new SecretKeySpec(KEY,ALGORITHM);
		Cipher cipher = Cipher.getInstance(ALGORITHM);
		cipher.init(Cipher.DECRYPT_MODE,secretKey);
		byte[] decryptedDate = cipher.doFinal(Base64.getDecoder().decode(encryptedData));
		return new String(decryptedDate);
		
	}

}
