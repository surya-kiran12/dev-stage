package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

import com.utility.Encryption;

@WebServlet("/SumbitData")
public class Encryptservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		// Retrieve form data 
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String sensitiveData = request.getParameter("sensitiveData");
		
		try {
			// Encrypt the sensitive data
			String encryptedData = Encryption.encrypt(sensitiveData);
			
			// Set attributes for forwarding (e.g., to a Html or another processing step)
			
			request.setAttribute("name", name);
			request.setAttribute("email", email);
			request.setAttribute("encryptedData", encryptedData);
			request.setAttribute("decryptedData", Encryption.decrypt(encryptedData));
			
			 // In a real application, you might store encryptedData in a database here.

			
		} catch (Exception e) {
			e.printStackTrace();
		}
		

        // Forward to the next step (e.g., a html for display or another servlet for further processing)
		
		request.getRequestDispatcher("result.html").forward(request, response);
	}

}
