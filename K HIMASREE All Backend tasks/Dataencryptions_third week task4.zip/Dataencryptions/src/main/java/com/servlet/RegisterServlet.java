package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.crypto.SecretKey;

import com.utility.Encrypted;


@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final String DB_URL = "jdbc:mysql://localhost:3306/your_database";
	private static final String DB_USER = "root";
	private static final String DB_PASSWORD = "password";
       
    
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
        String password = request.getParameter("password");

        try {
            // Generate a secret key
            SecretKey secretKey = Encrypted.generateSecretKey();

            // Encrypt the password
            String encryptedPassword = Encrypted.encrypt(password, secretKey);

            // Store encrypted password and secret key (convert to string if needed for storage)
            storeUser(username, encryptedPassword);

            response.getWriter().println("User registered successfully with encrypted data!");

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        }
    }

    private void storeUser(String username, String encryptedPassword) throws Exception {
        // Store user details in the database
        Class.forName("com.mysql.cj.jdbc.Driver");
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement ps = conn.prepareStatement("INSERT INTO users (username, encrypted_password) VALUES (?, ?)")) {
            ps.setString(1, username);
            ps.setString(2, encryptedPassword);
            ps.executeUpdate();
        }
    }
}