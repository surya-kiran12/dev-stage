package com.servlet;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/inventory/search")
public class SearchInventoryFilteringServlet extends HttpServlet {
	
	private static final String DB_URL = "jdbc:mysql://localhost:3306/yourdatabase"; // Replace with your database name
    private static final String DB_USER = "yourusername"; // Replace with your database username
    private static final String DB_PASSWORD = "yourpassword"; // Replace with your database password

    // InventoryItem model class
    public static class InventoryItem {
        private int id;
        private String name;
        private String category;
        private BigDecimal price;
        private int quantity;
        private String description;

        public InventoryItem(int id, String name, String category, BigDecimal price, int quantity, String description) {
            this.id = id;
            this.name = name;
            this.category = category;
            this.price = price;
            this.quantity = quantity;
            this.description = description;
        }

        // Getters
        public int getId() { return id; }
        public String getName() { return name; }
        public String getCategory() { return category; }
        public BigDecimal getPrice() { return price; }
        public int getQuantity() { return quantity; }
        public String getDescription() { return description; }
    }

    // Establishing a database connection
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }

    
    // handling Get request to serach inventory
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String name = request.getParameter("name");
	        String category = request.getParameter("category");
	        String minPrice = request.getParameter("minPrice");
	        String maxPrice = request.getParameter("maxPrice");

	        List<InventoryItem> results = searchInventory(name, category, minPrice, maxPrice);

	        request.setAttribute("results", results);
	        RequestDispatcher dispatcher = request.getRequestDispatcher("/inventoryResults.jsp");
	        dispatcher.forward(request, response);
	    }

	    // Method to search inventory with dynamic filtering
	    private List<InventoryItem> searchInventory(String name, String category, String minPrice, String maxPrice) {
	        List<InventoryItem> items = new ArrayList<>();
	        StringBuilder query = new StringBuilder("SELECT * FROM inventory WHERE 1=1");

	        if (name != null && !name.isEmpty()) query.append(" AND name LIKE ?");
	        if (category != null && !category.isEmpty()) query.append(" AND category = ?");
	        if (minPrice != null && !minPrice.isEmpty()) query.append(" AND price >= ?");
	        if (maxPrice != null && !maxPrice.isEmpty()) query.append(" AND price <= ?");

	        Connection conn = null;
	        PreparedStatement stmt = null;
	        ResultSet rs = null;

	        try {
	            conn = getConnection();
	            stmt = conn.prepareStatement(query.toString());

	            int paramIndex = 1;
	            if (name != null && !name.isEmpty()) stmt.setString(paramIndex++, "%" + name + "%");
	            if (category != null && !category.isEmpty()) stmt.setString(paramIndex++, category);
	            if (minPrice != null && !minPrice.isEmpty()) stmt.setBigDecimal(paramIndex++, new BigDecimal(minPrice));
	            if (maxPrice != null && !maxPrice.isEmpty()) stmt.setBigDecimal(paramIndex++, new BigDecimal(maxPrice));

	            rs = stmt.executeQuery();
	            while (rs.next()) {
	                InventoryItem item = new InventoryItem(
	                        rs.getInt("id"),
	                        rs.getString("name"),
	                        rs.getString("category"),
	                        rs.getBigDecimal("price"),
	                        rs.getInt("quantity"),
	                        rs.getString("description")
	                );
	                items.add(item);
	            }
	        } catch (SQLException e) {
	            e.printStackTrace();
	        } finally {
	            // Ensure resources are closed
	            try {
	                if (rs != null) rs.close();
	                if (stmt != null) stmt.close();
	                if (conn != null) conn.close();
	            } catch (SQLException e) {
	                e.printStackTrace();
	            }
	        }

	        return items;
	    }
	
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
