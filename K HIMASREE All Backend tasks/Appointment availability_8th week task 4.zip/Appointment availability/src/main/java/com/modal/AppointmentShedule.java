package com.modal;
import java.util.Objects;

public class AppointmentShedule {
	
	    private String startTime;
	    private String endTime;

	    public AppointmentShedule (String startTime, String endTime) {
	        this.startTime = startTime;
	        this.endTime = endTime;
	    }

	    public String getStartTime() {
	        return startTime;
	    }

	    public void setStartTime(String startTime) {
	        this.startTime = startTime;
	    }

	    public String getEndTime() {
	        return endTime;
	    }

	    public void setEndTime(String endTime) {
	        this.endTime = endTime;
	    }

	    // Conflict checking logic (simple string comparison for this example)
	    public boolean conflictsWith(AppointmentShedule  other) {
	        return !(this.endTime.compareTo(other.startTime) <= 0 || this.startTime.compareTo(other.endTime) >= 0);
	    }

	    @Override
	    public boolean equals(Object obj) {
	        if (this == obj) return true;
	        if (obj == null || getClass() != obj.getClass()) return false;
	        AppointmentShedule  that = (AppointmentShedule ) obj;
	        return Objects.equals(startTime, that.startTime) && Objects.equals(endTime, that.endTime);
	    }

	    @Override
	    public int hashCode() {
	        return Objects.hash(startTime, endTime);
	    }
	}



