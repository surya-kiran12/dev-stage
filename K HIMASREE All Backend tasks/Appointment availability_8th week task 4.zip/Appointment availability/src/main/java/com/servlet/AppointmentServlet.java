package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.modal.AppointmentShedule;

@WebServlet("/schedule")
public class AppointmentServlet extends HttpServlet {
	 // JDBC parameters
    private static final String JDBC_URL = "jdbc:mysql://localhost:3306/schedulingDB";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "password";

    // Database connection method
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
    }

    // Method to check for conflicting appointments in the database
    private boolean checkForConflicts(AppointmentShedule newAppointment) throws SQLException {
        String query = "SELECT * FROM appointments WHERE (start_time < ? AND end_time > ?) OR (start_time < ? AND end_time > ?)";
        try (Connection conn = getConnection(); 
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, newAppointment.getEndTime());
            ps.setString(2, newAppointment.getStartTime());
            ps.setString(3, newAppointment.getStartTime());
            ps.setString(4, newAppointment.getEndTime());

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next(); // If there's any result, a conflict exists
            }
        }
    }

    // Method to add a new appointment to the database
    private void addAppointmentToDatabase(AppointmentShedule newAppointment) throws SQLException {
        String query = "INSERT INTO appointments (start_time, end_time) VALUES (?, ?)";
        try (Connection conn = getConnection(); 
             PreparedStatement ps = conn.prepareStatement(query)) {
            ps.setString(1, newAppointment.getStartTime());
            ps.setString(2, newAppointment.getEndTime());
            ps.executeUpdate();
        }
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String startTime = request.getParameter("startTime");
        String endTime = request.getParameter("endTime");

        AppointmentShedule newAppointment = new AppointmentShedule(startTime, endTime);

        // Check for conflicts in the database
        try {
            if (checkForConflicts(newAppointment)) {
                request.setAttribute("message", "Conflict detected! This time slot is already taken.");
                request.getRequestDispatcher("index.jsp").forward(request, response);
                return;
            }

            // If no conflict, add to the database
            addAppointmentToDatabase(newAppointment);
            request.setAttribute("message", "Appointment successfully scheduled!");
            request.getRequestDispatcher("index.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("message", "Database error: " + e.getMessage());
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// Retrieve all appointments from the database
        List<AppointmentShedule> appointmentList = new ArrayList<>();
        String query = "SELECT * FROM appointments ORDER BY start_time";
        
        try (Connection conn = getConnection(); 
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {
            
            while (rs.next()) {
                String startTime = rs.getString("start_time");
                String endTime = rs.getString("end_time");
                appointmentList.add(new AppointmentShedule(startTime, endTime));
            }
            
            request.setAttribute("appointments", appointmentList);
            request.getRequestDispatcher("index.jsp").forward(request, response);
        } catch (SQLException e) {
            e.printStackTrace();
            request.setAttribute("message", "Database error: " + e.getMessage());
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }
}


