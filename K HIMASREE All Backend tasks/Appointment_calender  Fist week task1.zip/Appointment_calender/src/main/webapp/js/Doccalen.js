document.addEventListener('DOMContentLoaded', () => {
    const calendarBody = document.getElementById('calendarBody');
    const monthDropdown = document.getElementById('monthDropdown');
    const yearDropdown = document.getElementById('yearDropdown');
    const prevMonthButton = document.getElementById('prevMonth');
    const nextMonthButton = document.getElementById('nextMonth');
    const appointmentTableBody = document.querySelector('#appointmentsTable tbody');
    const noAppointmentsMessage = document.getElementById('noAppointmentsMessage');
    const addAppointmentButton = document.getElementById('addAppointment');
    const searchButton = document.getElementById('searchButton');
    const searchSection = document.getElementById('searchSection');
    const appointmentsSection = document.getElementById('appointmentsSection');

    let currentDate = new Date();
    let selectedDate = null;
    let appointments = [];

	function fetchAppointments() {
	    fetch('dctrapicalen?action=fetch')
	        .then(response => {
	            if (!response.ok) {
	                throw new Error(`HTTP error! Status: ${response.status}`);
	            }
	            return response.text(); 
	        })
	        .then(rawData => {

	            if (!rawData || rawData.trim() === '') {
	                console.error('Empty or invalid JSON response');
	                appointments = []; 
	                renderCalendar(currentDate);
	                return;
	            }
	            try {
	                appointments = JSON.parse(rawData); // Parse JSON safely
	            } catch (e) {
	                console.error('Error parsing JSON:', e);
	                appointments = [];
	            }
	            renderCalendar(currentDate); // Proceed with rendering
	        })
	        .catch(error => console.error('Error fetching appointments:', error));
	}
	
    function renderCalendar(date) {
        const year = date.getFullYear();
        const month = date.getMonth();
        monthDropdown.value = month;
        yearDropdown.value = year;

        calendarBody.innerHTML = '';

        const firstDay = new Date(year, month, 1);
        const lastDay = new Date(year, month + 1, 0);
        const startDay = firstDay.getDay();
        const totalDays = lastDay.getDate();

        let row = document.createElement('tr');
        for (let i = 0; i < startDay; i++) {
            row.appendChild(document.createElement('td'));
        }
        for (let day = 1; day <= totalDays; day++) {
            if (row.children.length === 7) {
                calendarBody.appendChild(row);
                row = document.createElement('tr');
            }
            const cell = document.createElement('td');
            cell.textContent = day;

            const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
            cell.dataset.date = dateStr;
            cell.classList.add('calendar-day');

            const dayAppointments = appointments.filter(appt => appt.date === dateStr);
            if (dayAppointments.length > 0) {
                if (dayAppointments.some(appt => appt.status === 'booked')) {
                    cell.classList.add('booked');
                } else if (dayAppointments.every(appt => appt.status === 'cancelled')) {
                    cell.classList.add('cancelled');
                }
            }

            cell.addEventListener('click', () => {
                selectDate(dateStr);
                displayAppointments(dateStr);
                searchSection.classList.remove('hidden');
                appointmentsSection.classList.remove('hidden');
            });

            if (selectedDate === dateStr) {
                cell.classList.add('selected-date');
            }

            row.appendChild(cell);
        }
        calendarBody.appendChild(row);
    }

	function selectDate(dateStr) {
	    // Remove 'selected-date' class from the previously selected date, if any
	    if (selectedDate) {
	        const prevSelectedCell = document.querySelector(`td[data-date="${selectedDate}"]`);
	        if (prevSelectedCell) {
	            prevSelectedCell.classList.remove('selected-date');
	        }
	    }

	    // Update selectedDate and add 'selected-date' class to the new selected date
	    selectedDate = dateStr;
	    const selectedCell = document.querySelector(`td[data-date="${selectedDate}"]`);
	    if (selectedCell) {
	        selectedCell.classList.add('selected-date');
	    } else {
	        // If the selectedDate is no longer valid (i.e., not part of the current month),
	        // set the selectedDate to the first day of the current month or handle appropriately.
	        const firstDayOfMonth = `${currentDate.getFullYear()}-${String(currentDate.getMonth() + 1).padStart(2, '0')}-01`;
	        selectedDate = firstDayOfMonth;
	        renderCalendar(currentDate);  // Re-render the calendar after changing the selected date
	    }
	}
	
    function displayAppointments(dateStr) {
        appointmentTableBody.innerHTML = '';

        const results = appointments.filter(appointment => appointment.date === dateStr);

        if (results.length > 0) {
            noAppointmentsMessage.style.display = 'none';
            results.forEach(appointment => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${appointment.id}</td>
                    <td>${appointment.patientName}</td>
                    <td>${appointment.timeslot}</td>
                    <td class="${appointment.status}">${appointment.status}</td>
                    <td>
					${(appointment.status === 'Confirmed' || appointment.status === 'Re-Scheduled') ? `
                            <button class="rescheduleButton" data-id="${appointment.id}">Re-Schedule</button>
                            <button class="cancelButton" data-id="${appointment.id}">Cancel</button>
							` : ''}
	                  </td>
	           `;
             
				const statusCell = row.querySelector(`.status-${appointment.status}`);
				               if (statusCell) {
				                   if (appointment.status === 'Cancelled') {
				                       statusCell.style.color = 'red';
				                   } else if (appointment.status === 'Confirmed') {
				                       statusCell.style.color = 'green';
				                   } else if (appointment.status === 'Re-Scheduled') {
				                       statusCell.style.color = 'orange';
				                   }
				               }
							   appointmentTableBody.appendChild(row);
            });

            
            document.querySelectorAll('.rescheduleButton').forEach(button => {
                button.addEventListener('click', (event) => {
                    const appointmentId = event.target.dataset.id;
                    window.location.href = `appointment.html?id=${appointmentId}`; 
                });
            });

            document.querySelectorAll('.cancelButton').forEach(button => {
                button.addEventListener('click', (event) => {
                    const appointmentId = event.target.dataset.id;
                    cancelAppointment(appointmentId);
                });
            });
        } else {
            noAppointmentsMessage.style.display = 'block';
        }
    }

	function cancelAppointment(appointmentId) {
	    if (window.confirm(`Are you sure you want to cancel appointment ID: ${appointmentId}?`)) {
	        fetch(`dctrapicalen?action=cancel&id=${appointmentId}`, { method: 'POST' })
	            .then(response => {
	                if (!response.ok) {
	                    throw new Error(`HTTP error! Status: ${response.status}`);
	                }
	                return response.json();
	            })
	            .then(() => {
	                appointments = appointments.map(appt =>
	                    appt.id == appointmentId ? { ...appt, status: 'cancelled' } : appt
	                );
	                displayAppointments(selectedDate);
	                renderCalendar(currentDate);
	            })
	            .catch(error => console.error('Error canceling appointment:', error));
	    }
	}

    function searchAppointments() {
        const patientId = document.getElementById('patientId').value.trim();
        const patientName = document.getElementById('patientName').value.trim().toLowerCase();

        if (!selectedDate) {
            alert('Please select a date.');
            return;
        }

        // Clear previous results
        appointmentTableBody.innerHTML = '';

        // Filter appointments for the selected date
        const results = appointments.filter(appointment => {
            return appointment.date === selectedDate &&
                (!patientId || appointment.id == patientId) &&
                (!patientName || appointment.patientName.toLowerCase().includes(patientName));
        });

        // Populate the appointments table with results
        if (results.length > 0) {
            noAppointmentsMessage.style.display = 'none';
            results.forEach(appointment => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${appointment.id}</td>
                    <td>${appointment.patientName}</td>
                    <td>${appointment.timeslot}</td>
                    <td>${appointment.status}</td>
                    <td>
                        ${appointment.status === 'Confirmed' ? `
                            <button class="rescheduleButton" data-id="${appointment.id}">Re-Schedule</button>
                            <button class="cancelButton" data-id="${appointment.id}">Cancel</button>
                        ` : ''}
                    </td>
                `;
                appointmentTableBody.appendChild(row);
            });

            // Add event listeners for Reschedule and Cancel buttons
            document.querySelectorAll('.rescheduleButton').forEach(button => {
                button.addEventListener('click', (event) => {
                    const appointmentId = event.target.dataset.id;
                    window.location.href = `appointment.html?id=${appointmentId}`; // Redirect to appointment page for rescheduling
                });
            });

            document.querySelectorAll('.cancelButton').forEach(button => {
                button.addEventListener('click', (event) => {
                    const appointmentId = event.target.dataset.id;
                    cancelAppointment(appointmentId);
                });
            });
        } else {
            noAppointmentsMessage.style.display = 'block';
        }
    }

    function updateMonthYearDropdowns() {
        const currentYear = new Date().getFullYear();
        const startYear = currentYear - 10;
        const endYear = currentYear + 50;

        for (let i = 0; i < 12; i++) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = new Date(0, i).toLocaleString('default', { month: 'long' });
            monthDropdown.appendChild(option);
        }

        for (let i = startYear; i <= endYear; i++) {
            const option = document.createElement('option');
            option.value = i;
            option.textContent = i;
            yearDropdown.appendChild(option);
        }
    }

    prevMonthButton.addEventListener('click', () => {
        currentDate.setMonth(currentDate.getMonth() - 1);
        renderCalendar(currentDate);
    });

    nextMonthButton.addEventListener('click', () => {
        currentDate.setMonth(currentDate.getMonth() + 1);
        renderCalendar(currentDate);
    });

    monthDropdown.addEventListener('change', () => {
        currentDate.setMonth(monthDropdown.value);
        renderCalendar(currentDate);
    });

    yearDropdown.addEventListener('change', () => {
        currentDate.setFullYear(yearDropdown.value);
        renderCalendar(currentDate);
    });

    addAppointmentButton.addEventListener('click', () => {
        if (!selectedDate) {
            alert('Please select a date.');
            return;
        }

        const currentDateTime = new Date();
        const selectedDateTime = new Date(selectedDate);

        // Check if the selected date is today or in the future
        if (selectedDateTime < currentDateTime.setHours(0, 0, 0, 0)) {
            alert('You cannot add an appointment for a past date.');
            return;
        }

        // Redirect to appointment creation page
        window.location.href = 'appointment.html';
    });

    searchButton.addEventListener('click', searchAppointments);

    // Initialize the calendar and dropdowns
    updateMonthYearDropdowns();
    fetchAppointments();
    renderCalendar(currentDate); // Ensure calendar is rendered on page load
});
