document.addEventListener('DOMContentLoaded', () => {
    const calendarBody = document.getElementById('calendarBody');
    const monthDropdown = document.getElementById('monthDropdown');
    const yearDropdown = document.getElementById('yearDropdown');
    const addAppointmentButton = document.getElementById('addAppointment');
    const appointmentsTableBody = document.querySelector('#appointmentsTable tbody');
    const noAppointmentsMessage = document.getElementById('noAppointmentsMessage');
    const appointmentsSection = document.querySelector('.appointments');
    const searchButton = document.getElementById('searchButton');
    const searchSection = document.getElementById('searchSection');

    const currentDate = new Date();
    let selectedMonth = currentDate.getMonth();
    let selectedYear = currentDate.getFullYear();
    let selectedDate = null;
    let appointments = [];

    const months = [
        'JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE',
        'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'
    ];

    function populateMonthDropdown() {
        months.forEach((month, index) => {
            const option = document.createElement('option');
            option.value = index;
            option.text = month;
            monthDropdown.appendChild(option);
        });
        monthDropdown.value = selectedMonth;
    }

    function populateYearDropdown() {
        const currentYear = new Date().getFullYear();
        for (let i = currentYear - 10; i <= currentYear + 50; i++) {
            const option = document.createElement('option');
            option.value = i;
            option.text = i;
            yearDropdown.appendChild(option);
        }
        yearDropdown.value = selectedYear;
    }

    async function fetchAppointments() {
        try {
            const response = await fetch('stfapicalen/fth');
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            const responseText = await response.text();
            const data = responseText ? JSON.parse(responseText) : [];
            appointments = data;
            updateCalendar();
            noAppointmentsMessage.style.display = appointments.length === 0 ? 'block' : 'none';
        } catch (error) {
            console.error('Error fetching appointments:', error);
            alert('Failed to load appointments. Please try again later.');
        }
    }

    function updateCalendar() {
        calendarBody.innerHTML = '';
        const firstDay = new Date(selectedYear, selectedMonth, 1).getDay();
        const daysInMonth = new Date(selectedYear, selectedMonth + 1, 0).getDate();

        let row = document.createElement('tr');

        for (let i = 0; i < firstDay; i++) {
            const cell = document.createElement('td');
            row.appendChild(cell);
        }

        for (let i = 1; i <= daysInMonth; i++) {
            const cell = document.createElement('td');
            cell.textContent = i;
            cell.classList.add('calendar-day');

            const dateStr = `${selectedYear}-${String(selectedMonth + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
            if (selectedDate === dateStr) {
                cell.classList.add('selected-date');
            }

            cell.addEventListener('click', () => {
                selectDate(dateStr);
                showAppointments(selectedYear, selectedMonth, i);
            });

            const appointmentForDay = appointments.filter(appointment => appointment.date === dateStr);
            if (appointmentForDay.length > 0) {
                cell.classList.add(appointmentForDay.some(a => a.status === 'cancelled') ? 'cancelled' : 'booked');
            }

            row.appendChild(cell);

            if ((i + firstDay) % 7 === 0) {
                calendarBody.appendChild(row);
                row = document.createElement('tr');
            }
        }

        calendarBody.appendChild(row);
    }

    function selectDate(dateStr) {
        document.querySelectorAll('.calendar-day.selected-date').forEach(cell => cell.classList.remove('selected-date'));
        selectedDate = dateStr;
        updateCalendar();
        searchSection.classList.remove('hidden');
        appointmentsSection.classList.remove('hidden');
    }

    function showAppointments(year, month, day) {
        const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
        const appointmentsForDay = appointments.filter(appointment => appointment.date === dateStr);

        appointmentsTableBody.innerHTML = '';

        if (appointmentsForDay.length > 0) {
            noAppointmentsMessage.style.display = 'none';
            appointmentsForDay.forEach(appointment => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${appointment.id}</td>
                    <td>${appointment.patientName}</td>
                    <td>${appointment.doctorName}</td>
                    <td>${appointment.timeslot}</td>
                    <td class="${appointment.status}">${appointment.status}</td>
                    <td>
					${(appointment.status === 'Confirmed' || appointment.status === 'Re-Scheduled') ? `
					  <button class="rescheduleButton" data-id="${appointment.id}">Re-Schedule</button>
					    <button class="cancelButton" data-id="${appointment.id}">Cancel</button>
					                        ` : ''}
					                    </td>
					                `;

                const statusCell = row.querySelector(`.status-${appointment.status}`);
                if (statusCell) {
                    statusCell.style.color = appointment.status === 'cancelled' ? 'red' : appointment.status === 'confirmed' ? 'green' : 'orange';
                }

                appointmentsTableBody.appendChild(row);

                row.querySelector('.editButton')?.addEventListener('click', () => {
                    window.location.href = `appointment.html?id=${appointment.id}`;
                });

                row.querySelector('.cancelButton')?.addEventListener('click', async (event) => {
					const appointmentId = event.target.dataset.id;
					console.log('Appointment ID:', appointmentId);
					const appointment = appointments.find(a => String(a.id) === String(appointmentId));

					if (!appointment) {
					    alert('Appointment not found.');
					    return;
					}

					if (appointment.status === 'Cancelled') {
					    alert('This appointment is already canceled.');
					    return;
					}

					if (window.confirm(`Are you sure you want to cancel appointment ID: ${appointmentId}?`)) {
					    try {
					        const response = await fetch(`stfapicalen/${appointmentId}`, {
					            method: 'DELETE'
					        });

					        if (response.ok) {
					            appointment.status = 'cancelled';
					            updateCalendar();
					            showAppointments(year, month, day);
					            alert('Appointment successfully canceled.');
					        } else {
					            alert('Failed to cancel the appointment.');
					        }
					    } catch (error) {
					        console.error('Error canceling appointment:', error);
					        alert('Failed to cancel the appointment. Please try again later.');
					    }
					}
                });
            });
            appointmentsSection.style.display = 'block';
        } else {
            noAppointmentsMessage.style.display = 'block';
            appointmentsSection.style.display = 'block';
        }
    }

    function searchAppointments() {
        const patientId = document.getElementById('patientId').value.trim();
        const patientName = document.getElementById('patientName').value.trim().toLowerCase();
        const doctorName = document.getElementById('doctorName').value.trim().toLowerCase();

        if (!selectedDate) {
            alert('Please select a date.');
            return;
        }

        appointmentsTableBody.innerHTML = '';

        const results = appointments.filter(appointment => {
            return appointment.date === selectedDate &&
                (!patientId || appointment.id == patientId) &&
                (!patientName || appointment.patientName.toLowerCase().includes(patientName)) &&
                (!doctorName || appointment.doctorName.toLowerCase().includes(doctorName));
        });

        if (results.length > 0) {
            noAppointmentsMessage.style.display = 'none';
            results.forEach(appointment => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${appointment.id}</td>
                    <td>${appointment.patientName}</td>
					<td>${appointment.doctorName}</td>
                    <td>${appointment.timeslot}</td>
                    <td class="${appointment.status}">${appointment.status}</td>
                    <td>
                        ${(appointment.status === 'Confirmed' || appointment.status === 'Updated') ? `
                            <button class="rescheduleButton" data-id="${appointment.id}">Re-Schedule</button>
                            <button class="cancelButton" data-id="${appointment.id}">Cancel</button>
                        ` : ''}
                    </td>
                `;
				const statusCell = row.querySelector(`.status-${appointment.status}`);
				               if (statusCell) {
				                   statusCell.style.color = appointment.status === 'cancelled' ? 'red' : appointment.status === 'confirmed' ? 'green' : 'orange';
				               }
                appointmentsTableBody.appendChild(row);
            });

            document.querySelectorAll('.rescheduleButton').forEach(button => {
                button.addEventListener('click', (event) => {
                    const appointmentId = event.target.dataset.id;
                    window.location.href = `appointment.html?id=${appointmentId}`; // Redirect to appointment page for rescheduling
                });
            });

            document.querySelectorAll('.cancelButton').forEach(button => {
                button.addEventListener('click', async (event) => {
                    const appointmentId = event.target.dataset.id;
                    const appointment = appointments.find(a => a.id === appointmentId);

                    if (appointment.status === 'cancelled') {
                        alert('This appointment is already canceled.');
                        return;
                    }

                    if (confirm(`Are you sure you want to cancel appointment ID: ${appointmentId}?`)) {
                        try {
                            const response = await fetch(`stfapicalen/${appointmentId}`, {
                                method: 'DELETE'
                            });

                            if (response.ok) {
                                appointment.status = 'cancelled';
                                updateCalendar();
                                alert('Appointment successfully canceled.');
                                showAppointments(selectedYear, selectedMonth, selectedDate.split('-')[2]);
                            } else {
                                alert('Failed to cancel the appointment.');
                            }
                        } catch (error) {
                            console.error('Error canceling appointment:', error);
                            alert('Failed to cancel the appointment. Please try again later.');
                        }
                    }
                });
            });
        } else {
            noAppointmentsMessage.style.display = 'block';
        }
    }

    document.getElementById('prevMonth').addEventListener('click', () => {
        selectedMonth--;
        if (selectedMonth < 0) {
            selectedMonth = 11;
            selectedYear--;
        }
        updateCalendar();
        monthDropdown.value = selectedMonth;
        yearDropdown.value = selectedYear;
    });

    document.getElementById('nextMonth').addEventListener('click', () => {
        selectedMonth++;
        if (selectedMonth > 11) {
            selectedMonth = 0;
            selectedYear++;
        }
        updateCalendar();
        monthDropdown.value = selectedMonth;
        yearDropdown.value = selectedYear;
    });

    monthDropdown.addEventListener('change', () => {
        selectedMonth = parseInt(monthDropdown.value);
        updateCalendar();
    });

    yearDropdown.addEventListener('change', () => {
        selectedYear = parseInt(yearDropdown.value);
        updateCalendar();
    });

    addAppointmentButton.addEventListener('click', () => {
        const currentDateTime = new Date();
        const selectedDateObj = new Date(selectedDate);

        currentDateTime.setHours(0, 0, 0, 0);

        if (!selectedDate || selectedDateObj < currentDateTime) {
            alert('Please select the current date or a future date.');
            return;
        }

        window.location.href = `addAppointment.jsp?date=${selectedDate}`;
    });

    searchButton.addEventListener('click', searchAppointments);

    populateMonthDropdown();
    populateYearDropdown();
    fetchAppointments().then(updateCalendar);
});
