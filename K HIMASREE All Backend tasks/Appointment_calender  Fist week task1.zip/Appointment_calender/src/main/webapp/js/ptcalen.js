document.addEventListener('DOMContentLoaded', () => {
  const calendarBody = document.getElementById('calendarBody');
  const monthDropdown = document.getElementById('monthDropdown');
  const yearDropdown = document.getElementById('yearDropdown');
  const appointmentsTableBody = document.querySelector('#appointmentsTable tbody');
  const noAppointmentsMessage = document.getElementById('noAppointmentsMessage');
  const appointmentsSection = document.querySelector('.appointments');

  const currentDate = new Date();
  let selectedMonth = currentDate.getMonth();
  let selectedYear = currentDate.getFullYear();
  let selectedDate = null;
  let appointments = [];

  const months = [
    'JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE',
    'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'
  ];

  // Populate the month dropdown
  function populateMonthDropdown() {
    months.forEach((month, index) => {
      const option = document.createElement('option');
      option.value = index;
      option.text = month;
      monthDropdown.appendChild(option);
    });
    monthDropdown.value = selectedMonth;
  }

  // Populate the year dropdown
  function populateYearDropdown() {
    const currentYear = new Date().getFullYear();
    for (let i = currentYear - 10; i <= currentYear + 50; i++) {
      const option = document.createElement('option');
      option.value = i;
      option.text = i;
      yearDropdown.appendChild(option);
    }
    yearDropdown.value = selectedYear;
  }

  // Fetch appointments from the backend
  async function fetchAppointments() {
    try {
      const response = await fetch('ptcatlen/fetch');
      const data = await response.json();
      appointments = data;
      updateCalendar();
    } catch (error) {
      console.error('Error fetching appointments:', error);
    }
  }

  // Update the calendar
  function updateCalendar() {
    calendarBody.innerHTML = '';
    const firstDay = new Date(selectedYear, selectedMonth, 1).getDay();
    const daysInMonth = new Date(selectedYear, selectedMonth + 1, 0).getDate();

    let row = document.createElement('tr');
    for (let i = 0; i < firstDay; i++) {
      const cell = document.createElement('td');
      row.appendChild(cell);
    }

    for (let i = 1; i <= daysInMonth; i++) {
      const cell = document.createElement('td');
      cell.textContent = i;
      cell.classList.add('calendar-day');
      const dateStr = `${selectedYear}-${String(selectedMonth + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;

      if (selectedDate === dateStr) {
        cell.classList.add('selected-date');
      }

      const appointment = appointments.find(app => app.date === dateStr);
      if (appointment) {
        if (appointment.status === 'Confirmed') {
          cell.classList.add('confirmed');
        } else if (appointment.status === 'Cancelled') {
          cell.classList.add('cancelled');
        } else if (appointment.status === 'Re-Scheduled') {
          cell.classList.add('Re-Scheduled');
        }
      }

      cell.addEventListener('click', () => handleDateClick(dateStr));
      row.appendChild(cell);

      if (row.children.length === 7) {
        calendarBody.appendChild(row);
        row = document.createElement('tr');
      }
    }

    if (row.children.length > 0) {
      calendarBody.appendChild(row);
    }

    updateDropdowns();
  }

  // Update the dropdowns to match the current month and year
  function updateDropdowns() {
    monthDropdown.value = selectedMonth;
    yearDropdown.value = selectedYear;
  }

  // Handle date click
  function handleDateClick(dateStr) {
    selectedDate = dateStr;
    updateCalendar();
    updateAppointmentsTable();
  }

  // Update the appointments table
  function updateAppointmentsTable() {
    const filteredAppointments = appointments.filter(app => app.date === selectedDate);
    appointmentsTableBody.innerHTML = '';

    if (noAppointmentsMessage && appointmentsSection) {
      if (filteredAppointments.length === 0) {
        noAppointmentsMessage.style.display = 'block';
        appointmentsSection.style.display = 'block';
      } else {
        noAppointmentsMessage.style.display = 'none';
        appointmentsSection.style.display = 'block';

        filteredAppointments.forEach(app => {
          const row = document.createElement('tr');
          row.innerHTML = `
            <td>${app.id}</td>
            <td>${app.patientName}</td>
            <td>${app.doctorName}</td>
            <td>${app.timeslot}</td>
            <td>${app.date}</td>
            <td class="status-${app.status}">${app.status}</td>
            <td>
              ${(app.status === 'Confirmed' || app.status === 'Re-Scheduled') ? `
                <button class="editButton" data-id="${app.id}">Re-Schedule</button>
                <button class="cancelButton" data-id="${app.id}">Cancel</button>
              ` : ''}
            </td>
          `;
          appointmentsTableBody.appendChild(row);

          const statusCell = row.querySelector(`.status-${app.status}`);
          if (statusCell) {
            if (app.status === 'Cancelled') {
              statusCell.style.color = 'red';
            } else if (app.status === 'Confirmed') {
              statusCell.style.color = 'green';
            } else if (app.status === 'Re-Scheduled') {
              statusCell.style.color = 'orange';
            }
          }
        });
      }
    }

    // Edit button click event
    document.querySelectorAll('.editButton').forEach(button => {
      button.addEventListener('click', (event) => {
        const appointmentId = event.target.getAttribute('data-id');
        window.location.href = `editAppointment.html?id=${appointmentId}`;
      });
    });

    // Cancel button click event
    document.querySelectorAll('.cancelButton').forEach(button => {
      button.addEventListener('click', async (event) => {
        const appointmentId = event.target.getAttribute('data-id');
        const appointment = appointments.find(app => app.id === parseInt(appointmentId));

        if (appointment.status === 'Cancelled') {
          alert('Cannot Cancel An Already Canceled Appointment.');
          return;
        }

        if (window.confirm(`Are you sure you want to cancel appointment ID: ${appointmentId}?`)) {
          try {
            const response = await fetch(`ptcatlen/${appointmentId}`, {
              method: 'DELETE'
            });

            if (response.ok) {
              // Update the appointment status and refresh UI
              appointment.status = 'Cancelled';
              updateCalendar();
              updateAppointmentsTable();
              alert('Appointment successfully canceled.');

              // Re-fetch the appointments to reflect the changes
              fetchAppointments();
            } else {
              alert('Failed to cancel the appointment. Please try again.');
            }
          } catch (error) {
            console.error('Error canceling appointment:', error);
            alert('An error occurred. Please try again later.');
          }
        }
      });
    });
  }

  // Month navigation event listeners
  document.getElementById('prevMonth').addEventListener('click', () => {
    if (selectedMonth === 0) {
      selectedMonth = 11;
      selectedYear--;
    } else {
      selectedMonth--;
    }
    updateCalendar();
  });

  document.getElementById('nextMonth').addEventListener('click', () => {
    if (selectedMonth === 11) {
      selectedMonth = 0;
      selectedYear++;
    } else {
      selectedMonth++;
    }
    updateCalendar();
  });

  monthDropdown.addEventListener('change', () => {
    selectedMonth = parseInt(monthDropdown.value);
    updateCalendar();
  });

  yearDropdown.addEventListener('change', () => {
    selectedYear = parseInt(yearDropdown.value);
    updateCalendar();
  });

  // Add appointment event listener
  document.getElementById('addAppointment').addEventListener('click', () => {
    const currentDateTime = new Date();
    const selectedDateObj = new Date(selectedDate); 

    currentDateTime.setHours(0, 0, 0, 0);

    if (!selectedDate || selectedDateObj < currentDateTime) {
      alert('Please select the current date or a future date.');
      return;
    }

    window.location.href = `addAppointment.jsp?date=${selectedDate}`;
  });

  // Initialize
  populateMonthDropdown();
  populateYearDropdown();
  fetchAppointments().then(() => updateCalendar());
});
