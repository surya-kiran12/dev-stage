package com.servlet;

import com.google.gson.Gson;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.modal.AppointmentCalender;

@WebServlet("/ptcatlen/*")
public class Appointmentservlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final String jdbcURL = "jdbc:mysql://192.168.1.152:3306/curetrack_test"; 
    private final String jdbcUsername = "himasree"; 
    private final String jdbcPassword = "Hima@123"; 

    public void init() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<AppointmentCalender> appointments = new ArrayList<>();

        try {
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            statement = connection.prepareStatement("SELECT * FROM appointment WHERE patient_id = ?");
           
			statement.setInt(1, 1015);
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("appointment_id");
                String patientName = resultSet.getString("patient_name");
                String doctorName = resultSet.getString("doctor_name");
                String timeslot = resultSet.getString("appointment_time");
                String date = resultSet.getString("appointment_date");
                String status = resultSet.getString("status");

                appointments.add(new AppointmentCalender(id, patientName, doctorName, timeslot, date, status));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try { if (resultSet != null) resultSet.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (statement != null) statement.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (connection != null) connection.close(); } catch (SQLException e) { e.printStackTrace(); }
        }

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        Gson gson = new Gson();
        out.print(gson.toJson(appointments));
        out.flush();
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        String patientName = request.getParameter("patientName");
        String doctorName = request.getParameter("doctorName");
        String timeSlot = request.getParameter("timeSlot");
        String date = request.getParameter("date");
        String status = "confirmed";  

        try {
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            preparedStatement = connection.prepareStatement("INSERT INTO appointment (patient_name, doctor_name, appointment_time, appointment_date, status) VALUES (?, ?, ?, ?, ?)");
            preparedStatement.setString(1, patientName);
            preparedStatement.setString(2, doctorName);
            preparedStatement.setString(3, timeSlot);
            preparedStatement.setString(4, date);
            preparedStatement.setString(5, status);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try { if (preparedStatement != null) preparedStatement.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (connection != null) connection.close(); } catch (SQLException e) { e.printStackTrace(); }
        }

        response.sendRedirect("appointment.jsp");
    }

    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Connection connection = null;
        PreparedStatement statement = null;

        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Appointment ID is missing.");
            return;
        }

        try {
            int appointmentId = Integer.parseInt(pathInfo.substring(1));
            connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
            statement = connection.prepareStatement("UPDATE appointment SET status='Cancelled' WHERE appointment_id = ?");
            statement.setInt(1, appointmentId);
            statement.executeUpdate();

            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().write("Appointment successfully cancelled.");
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Invalid appointment ID.");
        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        } finally {
            try { if (statement != null) statement.close(); } catch (SQLException e) { e.printStackTrace(); }
            try { if (connection != null) connection.close(); } catch (SQLException e) { e.printStackTrace(); }
        }
    }
}
