package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;

@WebServlet("/dctrapicalen")
public class Doctorscalander extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // JDBC connection details
	    private static final String JDBC_URL = "jdbc:mysql://192.168.1.152:3306/curetrack_test";
	    private static final String JDBC_USER = "himasree";
	    private static final String JDBC_PASSWORD = "Hima@123";
	
	    // Method to establish a database connection
	    private Connection getConnection() throws SQLException {
        try {
            // Load MySQL JDBC Driver (if needed for older versions)
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            throw new SQLException("JDBC Driver not found", e);
        }
        return DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
    }

    // Fetch all appointments or search based on parameters
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        Connection conn = null;

        try {
            conn = getConnection();
            if ("fetch".equalsIgnoreCase(action)) {
                fetchAppointments(out, conn);
            } else if ("search".equalsIgnoreCase(action)) {
                searchAppointments(request, out, conn);
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        } finally {
            closeConnection(conn);
        }
    }

    private void fetchAppointments(PrintWriter out, Connection conn) throws SQLException {
        String sql = "SELECT * FROM Appointment";
        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            List<String> appointments = new ArrayList<>();
            while (rs.next()) {
                String appointment = String.format(
                    "{\"id\": %d, \"patientName\": \"%s\", \"doctorName\": \"%s\", \"timeslot\": \"%s\", \"date\": \"%s\", \"status\": \"%s\"}",
                    rs.getInt("appointment_id"), rs.getString("patient_name"), rs.getString("doctor_name"),
                    rs.getString("appointment_time"), rs.getDate("appointment_date"), rs.getString("status")
                );
                appointments.add(appointment);
            }

            if (appointments.isEmpty()) {
                out.print("[]");
            } else {
                out.print("[" + String.join(",", appointments) + "]");
            }
        }
    }

    private void searchAppointments(HttpServletRequest request, PrintWriter out, Connection conn) throws SQLException {
        String patientId = request.getParameter("id");
        String patientName = request.getParameter("patientName");

        String sql = "SELECT * FROM Appointment WHERE (appointment_id = ? OR ? IS NULL) AND (LOWER(patient_name) LIKE ? OR ? IS NULL)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, patientId);
            stmt.setString(2, patientId);
            stmt.setString(3, "%" + (patientName != null ? patientName.toLowerCase() : "") + "%");
            stmt.setString(4, patientName);

            try (ResultSet rs = stmt.executeQuery()) {
                List<String> appointments = new ArrayList<>();
                while (rs.next()) {
                    String appointment = String.format(
                        "{\"id\": %d, \"patientName\": \"%s\", \"doctorName\": \"%s\", \"timeslot\": \"%s\", \"date\": \"%s\", \"status\": \"%s\"}",
                        rs.getInt("appointment_id"), rs.getString("patient_name"), rs.getString("doctor_name"),
                        rs.getString("appointment_time"), rs.getDate("appointment_date"), rs.getString("status")
                    );
                    appointments.add(appointment);
                }

                if (appointments.isEmpty()) {
                    out.print("[]");
                } else {
                    out.print("[" + String.join(",", appointments) + "]");
                }
            }
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");
        Connection conn = null;
        response.setContentType("application/json");
        response.getWriter().write("{\"status\":\"success\"}");


        try {
            conn = getConnection();
            if ("add".equalsIgnoreCase(action)) {
                addAppointment(request, conn);
            } else
            if ("update".equalsIgnoreCase(action)) {
                updateAppointment(request, conn);
            }else
            	if ("cancel".equalsIgnoreCase(action)) {
            	    deleteAppointment(request, conn);
            	}
        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        } finally {
            closeConnection(conn);
        }
    }

    private void addAppointment(HttpServletRequest request, Connection conn) throws SQLException {
        String patientName = request.getParameter("patientName");
        String doctorName = request.getParameter("doctorName");
        String timeslot = request.getParameter("timeslot");
        String date = request.getParameter("date");

        String sql = "INSERT INTO Appointment (patientName, doctorName, timeslot, date) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, patientName);
            stmt.setString(2, doctorName);
            stmt.setString(3, timeslot);
            stmt.setDate(4, Date.valueOf(date));
            stmt.executeUpdate();
        }
    }

    private void updateAppointment(HttpServletRequest request, Connection conn) throws SQLException {
        int id = Integer.parseInt(request.getParameter("id"));
        String patientName = request.getParameter("patientName");
        String doctorName = request.getParameter("doctorName");
        String timeslot = request.getParameter("timeslot");
        String date = request.getParameter("date");
        String status = request.getParameter("status");

        String sql = "UPDATE Appointment SET patientName = ?, doctorName = ?, timeslot = ?, date = ?, status = ? WHERE id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, patientName);
            stmt.setString(2, doctorName);
            stmt.setString(3, timeslot);
            stmt.setDate(4, Date.valueOf(date));
            stmt.setString(5, status);
            stmt.setInt(6, id);
            stmt.executeUpdate();
        }
    }

    private void deleteAppointment(HttpServletRequest request, Connection conn) throws SQLException {
        int id = Integer.parseInt(request.getParameter("id"));

        String sql = "UPDATE appointment SET status = 'Cancelled' WHERE appointment_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        }
    }

    // Close database connection
    private void closeConnection(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
