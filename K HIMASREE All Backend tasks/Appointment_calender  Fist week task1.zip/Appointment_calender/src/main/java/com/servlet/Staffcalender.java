package com.servlet;

import com.google.gson.Gson;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import com.modal.AppointmentCalender;

@WebServlet("/stfapicalen/*")
public class Staffcalender extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private final String jdbcURL = "jdbc:mysql://192.168.1.152:3306/curetrack_test";
    private final String jdbcUsername = "himasree";
    private final String jdbcPassword = "Hima@123";

    public void init() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        List<AppointmentCalender> appointments = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement statement = connection.prepareStatement("SELECT * FROM appointment")) {

            ResultSet resultSet = statement.executeQuery();

            while (resultSet.next()) {
                int id = resultSet.getInt("appointment_id");
                String patientName = resultSet.getString("patient_name");
                String doctorName = resultSet.getString("doctor_name");
                String timeSlot = resultSet.getString("appointment_time");
                String date = resultSet.getString("appointment_date");
                String status = resultSet.getString("status");

                appointments.add(new AppointmentCalender(id, patientName, doctorName, timeSlot, date, status));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();
        Gson gson = new Gson();
        out.print(gson.toJson(appointments));
        out.flush();
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String patientName = request.getParameter("patientName");
        String doctorName = request.getParameter("doctorName");
        String timeSlot = request.getParameter("timeslot");
        String date = request.getParameter("date");
        String status = request.getParameter("status");

        try (Connection connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "INSERT INTO appointment (patient_name, doctor_name, appointment_time, appointment_date, status) VALUES (?, ?, ?, ?, ?)")) {

            preparedStatement.setString(1, patientName);
            preparedStatement.setString(2, doctorName);
            preparedStatement.setString(3, timeSlot);
            preparedStatement.setString(4, date);
            preparedStatement.setString(5, status);

            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        response.setStatus(HttpServletResponse.SC_CREATED);
    }

    private void addOrUpdateAppointment(HttpServletRequest request, Connection conn) throws SQLException {
        String id = request.getParameter("id"); // Optional for new appointments
        String patientName = request.getParameter("patientName");
        String doctorName = request.getParameter("doctorName");
        String timeslot = request.getParameter("timeslot");
        String date = request.getParameter("date");
        String status = request.getParameter("status");

        String sql = (id == null || id.isEmpty()) ?
                "INSERT INTO appointment (patient_name, doctor_name, appointment_time, appointment_date, status) VALUES (?, ?, ?, ?, ?)" :
                "UPDATE appointment SET patient_name = ?, doctor_name = ?, appointment_time = ?, appointment_date = ?, status = ? WHERE appointment_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, patientName);
            stmt.setString(2, doctorName);
            stmt.setString(3, timeslot);
            stmt.setDate(4, Date.valueOf(date));
            stmt.setString(5, status);
            if (id != null && !id.isEmpty()) {
                stmt.setInt(6, Integer.parseInt(id));
            }
            stmt.executeUpdate();
        }
    }

    private void deleteAppointment(String id, Connection conn) throws SQLException {
        String sql = "UPDATE appointment set status = 'Cancelled' WHERE appointment_id = ?";
        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, Integer.parseInt(id));
            stmt.executeUpdate();
        }
    }

    @Override
    protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String pathInfo = request.getPathInfo();
        if (pathInfo == null || pathInfo.equals("/")) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().print("{\"error\":\"Missing appointment ID\"}");
            return;
        }

        String[] pathParts = pathInfo.split("/");
        if (pathParts.length != 2) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().print("{\"error\":\"Invalid URL format\"}");
            return;
        }

        String id = pathParts[1];
        try (Connection conn = getConnection()) {
            deleteAppointment(id, conn);
            response.setStatus(HttpServletResponse.SC_NO_CONTENT);
        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().print("{\"error\":\"Failed to delete appointment\"}");
        }
    }

    // Helper method to get the database connection
    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
    }
}
