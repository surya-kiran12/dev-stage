	package com.modal;

public class AppointmentCalender {

	    private int id;
	    private String patientName;
	    private String doctorName;
	    private String timeslot;
	    private String date;
	    private String status;

	    // Constructor
	    public AppointmentCalender(int id, String patientName, String doctorName, String timeslot, String date, String status) {
	        this.id = id;
	        this.patientName = patientName;
	        this.doctorName = doctorName;
	        this.timeslot = timeslot;
	        this.date = date;
	        this.status = status;
	    }

	    // Getters and Setters
	    public int getId() { return id; }
	    public void setId(int id) { this.id = id; }
 
	    public String getPatientName() { return patientName; }
	    public void setPatientName(String patientName) { this.patientName = patientName; }

	    public String getDoctorName() { return doctorName; }
	    public void setDoctorName(String doctorName) { this.doctorName = doctorName; }

	    public String getTimeSlot() { return timeslot; }
	    public void setTimeSlot(String timeslot) { this.timeslot = timeslot; }

	    public String getDate() { return date; }
	    public void setDate(String date) { this.date = date; }

	    public String getStatus() { return status; }
	    public void setStatus(String status) { this.status = status; }
	


}
