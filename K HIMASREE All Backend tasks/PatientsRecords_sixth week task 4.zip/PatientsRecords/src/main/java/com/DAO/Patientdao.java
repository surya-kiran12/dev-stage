package com.DAO;

	
		import java.sql.*;
		import java.util.ArrayList;
		import java.util.List;

import com.modal.Patient;

		public class Patientdao {
		    private Connection connection;

		    public Patientdao(Connection connection) {
		        this.connection = connection;
		    }

		    // Method to add a new patient record to the database
		    public boolean addPatient(Patient patient) throws SQLException {
		        String sql = "INSERT INTO patients (name, age, diagnosis, treatment, status) VALUES (?, ?, ?, ?, ?)";
		        try (PreparedStatement statement = connection.prepareStatement(sql)) {
		            statement.setString(1, patient.getName());
		            statement.setInt(2, patient.getAge());
		            statement.setString(3, patient.getDiagnosis());
		            statement.setString(4, patient.getTreatment());
		            statement.setString(5, patient.getStatus());
		            return statement.executeUpdate() > 0;
		        }
		    }

		    // Method to update an existing patient record in the database
		    public boolean updatePatient(Patient patient) throws SQLException {
		        String sql = "UPDATE patients SET name = ?, age = ?, diagnosis = ?, treatment = ?, status = ? WHERE id = ?";
		        try (PreparedStatement statement = connection.prepareStatement(sql)) {
		            statement.setString(1, patient.getName());
		            statement.setInt(2, patient.getAge());
		            statement.setString(3, patient.getDiagnosis());
		            statement.setString(4, patient.getTreatment());
		            statement.setString(5, patient.getStatus());
		            statement.setInt(6, patient.getId());
		            return statement.executeUpdate() > 0;
		        }
		    }

		    // Method to retrieve all patients from the database
		    public List<Patient> getAllPatients() throws SQLException {
		        List<Patient> patients = new ArrayList<>();
		        String sql = "SELECT * FROM patients";
		        try (Statement statement = connection.createStatement();
		             ResultSet resultSet = statement.executeQuery(sql)) {
		            while (resultSet.next()) {
		                Patient patient = new Patient();
		                patient.setId(resultSet.getInt("id"));
		                patient.setName(resultSet.getString("name"));
		                patient.setAge(resultSet.getInt("age"));
		                patient.setDiagnosis(resultSet.getString("diagnosis"));
		                patient.setTreatment(resultSet.getString("treatment"));
		                patient.setStatus(resultSet.getString("status"));
		                patients.add(patient);
		            }
		        }
		        return patients;
		    }

		    // Method to retrieve a patient by ID from the database
		    public Patient getPatientById(int id) throws SQLException {
		        String sql = "SELECT * FROM patients WHERE id = ?";
		        try (PreparedStatement statement = connection.prepareStatement(sql)) {
		            statement.setInt(1, id);
		            try (ResultSet resultSet = statement.executeQuery()) {
		                if (resultSet.next()) {
		                    Patient patient = new Patient();
		                    patient.setId(resultSet.getInt("id"));
		                    patient.setName(resultSet.getString("name"));
		                    patient.setAge(resultSet.getInt("age"));
		                    patient.setDiagnosis(resultSet.getString("diagnosis"));
		                    patient.setTreatment(resultSet.getString("treatment"));
		                    patient.setStatus(resultSet.getString("status"));
		                    return patient;
		                }
		            }
		        }
		        return null; // Return null if no patient with the specified ID is found
		    }
		}

	
	    