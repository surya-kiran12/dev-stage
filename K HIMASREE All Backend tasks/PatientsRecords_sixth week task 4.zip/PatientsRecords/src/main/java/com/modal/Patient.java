package com.modal;


	public class Patient {
	    private int id;
	    private String name;
	    private int age;
	    private String diagnosis;
	    private String treatment;
	    private String status;

	    // Constructor
	    public Patient() {
	    }

	    public Patient(int id, String name, int age, String diagnosis, String treatment, String status) {
	        this.id = id;
	        this.name = name;
	        this.age = age;
	        this.diagnosis = diagnosis;
	        this.treatment = treatment;
	        this.status = status;
	    }

	    // Getters and setters
	    public int getId() {
	        return id;
	    }

	    public void setId(int id) {
	        this.id = id;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public int getAge() {
	        return age;
	    }

	    public void setAge(int age) {
	        this.age = age;
	    }

	    public String getDiagnosis() {
	        return diagnosis;
	    }

	    public void setDiagnosis(String diagnosis) {
	        this.diagnosis = diagnosis;
	    }

	    public String getTreatment() {
	        return treatment;
	    }

	    public void setTreatment(String treatment) {
	        this.treatment = treatment;
	    }

	    public String getStatus() {
	        return status;
	    }

	    public void setStatus(String status) {
	        this.status = status;
	    }

	    // toString method for plain text output
	    @Override
	    public String toString() {
	        return "Patient ID: " + id +
	               ", Name: " + name +
	               ", Age: " + age +
	               ", Diagnosis: " + diagnosis +
	               ", Treatment: " + treatment +
	               ", Status: " + status;
	    }
	}



