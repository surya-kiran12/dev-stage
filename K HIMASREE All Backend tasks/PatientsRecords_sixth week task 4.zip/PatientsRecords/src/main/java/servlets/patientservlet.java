package servlets;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;

import com.DAO.Patientdao;
import com.modal.Patient;

@WebServlet("/patients")
public class patientservlet extends HttpServlet {
    private Patientdao patientDAO;
    private Connection connection;

    @Override
    public void init() throws ServletException {
        try {
            // Database connection setup
            String jdbcUrl = "jdbc:mysql://localhost:3306/your_database";
            String jdbcUsername = "your_username";
            String jdbcPassword = "your_password";

            // Initialize the database connection
            connection = DriverManager.getConnection(jdbcUrl, jdbcUsername, jdbcPassword);
            patientDAO = new Patientdao(connection); // Pass the connection to DAO
        } catch (SQLException e) {
            throw new ServletException("Unable to connect to the database", e);
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String action = request.getParameter("action");
        response.setContentType("text/plain");
        PrintWriter out = response.getWriter();

        try {
            if ("all".equals(action)) {
                List<Patient> patients = patientDAO.getAllPatients();
                for (Patient patient : patients) {
                    out.println(patient.toString()); // Plain text response
                }
            } else {
                int id = Integer.parseInt(request.getParameter("id"));
                Patient patient = patientDAO.getPatientById(id);
                out.write(patient != null ? patient.toString() : "No patient found with this ID.");
            }
        } catch (SQLException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.write("Error: Unable to retrieve patient records.");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String action = request.getParameter("action");
        PrintWriter out = response.getWriter();
        
        if ("submit".equals(action)) {
            // Handle submission of a new patient
            try {
                Patient patient = new Patient();
                patient.setName(request.getParameter("name"));
                patient.setAge(Integer.parseInt(request.getParameter("age")));
                patient.setDiagnosis(request.getParameter("diagnosis"));
                patient.setTreatment(request.getParameter("treatment"));
                patient.setStatus(request.getParameter("status"));

                boolean success = patientDAO.addPatient(patient);
                out.write(success ? "Patient submitted successfully." : "Failed to submit patient.");
            } catch (SQLException e) {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                out.write("Error: Unable to submit patient.");
            }
        } else {
            // Handle other POST requests (if any)
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.write("Invalid action.");
        }
    }

    @Override
    protected void doPut(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            Patient patient = new Patient();
            patient.setId(Integer.parseInt(request.getParameter("id")));
            patient.setName(request.getParameter("name"));
            patient.setAge(Integer.parseInt(request.getParameter("age")));
            patient.setDiagnosis(request.getParameter("diagnosis"));
            patient.setTreatment(request.getParameter("treatment"));
            patient.setStatus(request.getParameter("status"));

            boolean success = patientDAO.updatePatient(patient);
            response.getWriter().write(success ? "Patient updated successfully." : "Failed to update patient.");
        } catch (SQLException e) {
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("Error: Unable to update patient.");
        }
    }

    @Override
    public void destroy() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close(); // Close the database connection when the servlet is destroyed
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
