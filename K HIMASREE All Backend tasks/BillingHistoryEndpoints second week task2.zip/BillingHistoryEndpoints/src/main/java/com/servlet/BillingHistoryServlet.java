package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.modal.BillingHistory;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/billing/history")
public class BillingHistoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database connection details
    private static final String URL = "jdbc:mysql://localhost:3306/your_database";
    private static final String USER = "your_db_user";
    private static final String PASSWORD = "your_db_password";

    // Load the MySQL driver
    static {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String userIdParam = request.getParameter("user_id");
        String role = request.getParameter("role");

        if (role == null || role.isEmpty()) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing role parameter");
            return;
        }

        List<BillingHistory> billingHistoryList;

        if ("admin".equalsIgnoreCase(role)) {
            billingHistoryList = getAllBillingHistory();
        } else if ("patient".equalsIgnoreCase(role) && userIdParam != null && !userIdParam.isEmpty()) {
            int userId = Integer.parseInt(userIdParam);
            billingHistoryList = getBillingHistoryByUserId(userId);
        } else {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid parameters for role or user_id");
            return;
        }

        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        Gson gson = new Gson();
        String jsonResponse = gson.toJson(billingHistoryList);
        out.print(jsonResponse);
        out.flush();
    }

    // Method to fetch billing history for all users (for admin role)
    private List<BillingHistory> getAllBillingHistory() {
        List<BillingHistory> billingHistoryList = new ArrayList<>();
        String query = "SELECT id, billing_id, date_range, age, gender, contact, particulars, charges, amount_paid, due_amount, mode_of_payment, payment_status FROM billing_history";

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            preparedStatement = connection.prepareStatement(query);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                BillingHistory billingHistory = new BillingHistory();
                billingHistory.setId(resultSet.getInt("id"));
                billingHistory.setBillingId(resultSet.getInt("billing_id"));
                billingHistory.setDateRange(resultSet.getString("date_range"));
                billingHistory.setAge(resultSet.getInt("age"));
                billingHistory.setGender(resultSet.getString("gender"));
                billingHistory.setContact(resultSet.getString("contact"));
                billingHistory.setParticulars(resultSet.getString("particulars"));
                billingHistory.setCharges(resultSet.getDouble("charges"));
                billingHistory.setAmountPaid(resultSet.getDouble("amount_paid"));
                billingHistory.setDueAmount(resultSet.getDouble("due_amount"));
                billingHistory.setModeOfPayment(resultSet.getString("mode_of_payment"));
                billingHistory.setPaymentStatus(resultSet.getString("payment_status"));

                billingHistoryList.add(billingHistory);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return billingHistoryList;
    }

    // Method to fetch billing history for a specific user (for patient role)
    private List<BillingHistory> getBillingHistoryByUserId(int userId) {
        List<BillingHistory> billingHistoryList = new ArrayList<>();
        String query = "SELECT id, billing_id, date_range, particulars, charges, amount_paid, due_amount, mode_of_payment, payment_status FROM billing_history WHERE user_id = ?";

        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;

        try {
            connection = DriverManager.getConnection(URL, USER, PASSWORD);
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, userId);
            resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                BillingHistory billingHistory = new BillingHistory();
                billingHistory.setId(resultSet.getInt("id"));
                billingHistory.setBillingId(resultSet.getInt("billing_id"));
                billingHistory.setDateRange(resultSet.getString("date_range"));
                billingHistory.setParticulars(resultSet.getString("particulars"));
                billingHistory.setCharges(resultSet.getDouble("charges"));
                billingHistory.setAmountPaid(resultSet.getDouble("amount_paid"));
                billingHistory.setDueAmount(resultSet.getDouble("due_amount"));
                billingHistory.setModeOfPayment(resultSet.getString("mode_of_payment"));
                billingHistory.setPaymentStatus(resultSet.getString("payment_status"));

                billingHistoryList.add(billingHistory);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (resultSet != null) resultSet.close();
                if (preparedStatement != null) preparedStatement.close();
                if (connection != null) connection.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
        return billingHistoryList;
    }
}
