package com.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.Database.Inventarydatabaseconnection;
import com.modal.Orderitems;
import com.modal.Orders;





public class Billingservice {
	
	    public void processOrder(Orders order) throws SQLException {
	        Connection conn = Inventarydatabaseconnection.getConnection();
	        try {
	            conn.setAutoCommit(false);

	            String insertOrder = "INSERT INTO orders (customer_name, total_amount) VALUES (?, ?)";
	            try (PreparedStatement pstmtOrder = conn.prepareStatement(insertOrder, Statement.RETURN_GENERATED_KEYS)) {
	                pstmtOrder.setString(1, order.getCustomerName());
	                pstmtOrder.setBigDecimal(2, order.getTotalAmount());
	                pstmtOrder.executeUpdate();

	                ResultSet generatedKeys = pstmtOrder.getGeneratedKeys();
	                if (generatedKeys.next()) {
	                    int orderId = generatedKeys.getInt(1);

	                    for (Orderitems item : order.getItems()) {
	                        Inventaryservice inventoryService = new Inventaryservice();
	                        if (!inventoryService.checkInventory(item.getProductId(), item.getQuantity())) {
	                            conn.rollback();
	                            throw new SQLException("Insufficient stock for product ID: " + item.getProductId());
	                        }

	                        String insertOrderItem = "INSERT INTO order_items (order_id, product_id, quantity) VALUES (?, ?, ?)";
	                        try (PreparedStatement pstmtItem = conn.prepareStatement(insertOrderItem)) {
	                            pstmtItem.setInt(1, orderId);
	                            pstmtItem.setInt(2, item.getProductId());
	                            pstmtItem.setInt(3, item.getQuantity());
	                            pstmtItem.executeUpdate();
	                        }

	                        inventoryService.updateInventory(item.getProductId(), item.getQuantity());
	                    }
	                }
	            }

	            conn.commit();
	        } catch (SQLException e) {
	            conn.rollback();
	            throw e;
	        } finally {
	            conn.setAutoCommit(true);
	        }
	    }
	


}
