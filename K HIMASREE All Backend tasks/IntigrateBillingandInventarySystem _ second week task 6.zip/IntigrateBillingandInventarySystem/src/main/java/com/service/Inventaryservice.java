package com.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.Database.Inventarydatabaseconnection;



public class Inventaryservice {
	
	    public void updateInventory(int productId, int quantity) throws SQLException {
	        Connection conn = Inventarydatabaseconnection.getConnection();
	        String query = "UPDATE products SET stock = stock - ? WHERE id = ?";

	        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
	            pstmt.setInt(1, quantity);
	            pstmt.setInt(2, productId);
	            pstmt.executeUpdate();
	        }
	    }

	    public boolean checkInventory(int productId, int quantity) throws SQLException {
	        Connection conn = Inventarydatabaseconnection.getConnection();
	        String query = "SELECT stock FROM products WHERE id = ?";

	        try (PreparedStatement pstmt = conn.prepareStatement(query)) {
	            pstmt.setInt(1, productId);
	            ResultSet rs = pstmt.executeQuery();

	            if (rs.next()) {
	                return rs.getInt("stock") >= quantity;
	            }
	        }
	        return false;
	    }
	


}
