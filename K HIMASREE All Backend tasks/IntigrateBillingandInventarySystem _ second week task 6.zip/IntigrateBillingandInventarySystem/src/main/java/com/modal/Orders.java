package com.modal;

import java.math.BigDecimal;
import java.util.List;

public class Orders {
	
	    private String customerName;
	    private BigDecimal totalAmount;
	    private List<Orderitems> items;

	    public Orders(String customerName, BigDecimal totalAmount, List<Orderitems> items) {
	        this.customerName = customerName;
	        this.totalAmount = totalAmount;
	        this.items = items;
	    }

	    public String getCustomerName() {
	        return customerName;
	    }

	    public BigDecimal getTotalAmount() {
	        return totalAmount;
	    }

	    public List<Orderitems> getItems() {
	        return items;
	    }
	


}
