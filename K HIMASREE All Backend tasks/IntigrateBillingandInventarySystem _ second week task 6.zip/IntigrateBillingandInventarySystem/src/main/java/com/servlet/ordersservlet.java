package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import com.modal.Orderitems;
import com.modal.Orders;
import com.service.Billingservice;

@WebServlet("/processBilling")
public class ordersservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
		
	        try {
	            String customerName = request.getParameter("customerName");
	            BigDecimal totalAmount = new BigDecimal(request.getParameter("totalAmount"));
	            String[] productIds = request.getParameterValues("productIds");
	            String[] quantities = request.getParameterValues("quantities");

	            List<Orderitems> items = new ArrayList<>();
	            for (int i = 0; i < productIds.length; i++) {
	                int productId = Integer.parseInt(productIds[i]);
	                int quantity = Integer.parseInt(quantities[i]);
	                items.add(new Orderitems(productId, quantity));
	            }

	            Orders order = new Orders(customerName, totalAmount, items);
	            Billingservice billingService = new Billingservice();
	            billingService.processOrder(order);

	            response.getWriter().write("Order processed successfully.");
	        } catch (Exception e) {
	            response.getWriter().write("Error processing order: " + e.getMessage());
	        }
	    }
	
	

}
