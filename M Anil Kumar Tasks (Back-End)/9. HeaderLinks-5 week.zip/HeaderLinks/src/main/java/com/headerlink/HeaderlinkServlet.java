package com.headerlink;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/api/header-links")
public class HeaderlinkServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "SELECT * FROM header_links";
            PreparedStatement ps = conn.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            List<HeaderLink> headerLinks = new ArrayList<>();

            while (rs.next()) {
                HeaderLink link = new HeaderLink(
                    rs.getInt("id"),
                    rs.getString("title"),
                    rs.getString("url")
                );
                headerLinks.add(link);
            }

            // Convert the list to JSON format
            StringBuilder json = new StringBuilder("[");
            for (int i = 0; i < headerLinks.size(); i++) {
                HeaderLink link = headerLinks.get(i);
                if (i > 0) {
                    json.append(",");
                }
                json.append("{")
                    .append("\"id\":").append(link.getId()).append(",")
                    .append("\"title\":\"").append(link.getTitle()).append("\",")
                    .append("\"url\":\"").append(link.getUrl()).append("\"")
                    .append("}");
            }
            json.append("]");
            out.write(json.toString());
        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.write("{\"error\": \"Failed to fetch header links.\"}");
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String title = request.getParameter("title");
        String url = request.getParameter("url");

        response.setContentType("application/json");
        PrintWriter out = response.getWriter();

        if (title == null || url == null) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            out.write("{\"error\": \"Title and URL are required.\"}");
            return;
        }

        try (Connection conn = DBConnection.getConnection()) {
            String sql = "INSERT INTO header_links (title, url) VALUES (?, ?)";
            PreparedStatement ps = conn.prepareStatement(sql);
            ps.setString(1, title);
            ps.setString(2, url);

            int rows = ps.executeUpdate();
            if (rows > 0) {
                out.write("{\"message\": \"Header link added successfully.\"}");
            } else {
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                out.write("{\"error\": \"Failed to add header link.\"}");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            out.write("{\"error\": \"Database error.\"}");
        }
    }
}
