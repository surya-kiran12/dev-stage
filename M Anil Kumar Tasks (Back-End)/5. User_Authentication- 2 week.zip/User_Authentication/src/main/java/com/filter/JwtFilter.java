package com.filter;

import com.util.JWTUtil;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.FilterConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebFilter("/secured/*")
public class JwtFilter implements Filter {
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        String authorizationHeader = req.getHeader("Authorization");

        if (authorizationHeader == null || !authorizationHeader.startsWith("Bearer ")) {
            res.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Missing or invalid Authorization header.");
            return;
        }

        String token = authorizationHeader.substring(7);
        try {
            // Check if the token is expired
            if (JWTUtil.isTokenExpired(token)) {
                res.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Token expired.");
                return;
            }

            // Extract username from token
            String username = JWTUtil.extractUsername(token);

            // Verify token matches the latest_token in the database
            Class.forName("com.mysql.cj.jdbc.Driver");
            try (Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/anil_schema", "root", "Anilkumar@1432#")) {
                PreparedStatement stmt = conn.prepareStatement("SELECT latest_token FROM user_register WHERE user_name = ?");
                stmt.setString(1, username);
                ResultSet rs = stmt.executeQuery();

                if (rs.next()) {
                    String latestToken = rs.getString("latest_token");
                    if (!token.equals(latestToken)) {
                        res.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Token is no longer valid.");
                        return;
                    }
                } else {
                    res.sendError(HttpServletResponse.SC_UNAUTHORIZED, "User not found.");
                    return;
                }
            }

            // Token is valid, proceed to the requested resource
            chain.doFilter(request, response);

        } catch (Exception e) {
            e.printStackTrace();
            res.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Error validating token.");
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}

    @Override
    public void destroy() {}
}
