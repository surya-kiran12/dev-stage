package com.servlet;

import com.model.User;
import com.util.JWTUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String user_name = request.getParameter("user_name");
        String password = request.getParameter("password");

        try {
            // Load MySQL JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection to anil_schema database
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/anil_schema", "root", "Anilkumar@1432#");

            // Authenticate user
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM user_register WHERE user_name=? AND password=?");
            stmt.setString(1, user_name);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                User user = new User(rs.getInt("user_id"), rs.getString("user_name"), rs.getString("password"), rs.getString("role"));
                
                // Generate JWT token
                String token = JWTUtil.generateToken(user.getuser_name(), user.getRole());
                
                // Update latest_token in user_register table
                PreparedStatement updateStmt = conn.prepareStatement("UPDATE user_register SET latest_token=? WHERE user_id=?");
                updateStmt.setString(1, token);
                updateStmt.setInt(2, user.getuser_id());
                updateStmt.executeUpdate();
                
                // Insert token into jwt_tokens table
                PreparedStatement insertTokenStmt = conn.prepareStatement("INSERT INTO jwt_tokens (user_id, token) VALUES (?, ?)");
                insertTokenStmt.setInt(1, user.getuser_id());
                insertTokenStmt.setString(2, token);
                insertTokenStmt.executeUpdate();

                // Respond to user
                response.setContentType("text/html");
                response.getWriter().write("<html><body><h1>Login successful</h1><p>Token: " + token + "</p></body></html>");
            } else {
                response.setContentType("text/html");
                response.getWriter().write("<html><body><h1>Invalid credentials</h1></body></html>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.setContentType("text/html");
            response.getWriter().write("<html><body><h1>Error occurred: " + e.getMessage() + "</h1></body></html>");
        }
    }
}
