package com.service;

import com.model.Patient;
import com.util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PatientService {

    public static Patient getPatientById(int patientId) {
        Patient patient = null;
        String query = "SELECT patient_name, mobile, email FROM patients WHERE patient_id = ?";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, patientId);

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    String patientName = rs.getString("patient_name");
                    String mobile = rs.getString("mobile");
                    String email = rs.getString("email");
                    patient = new Patient(patientId, patientName, email, mobile);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return patient;
    }
}
