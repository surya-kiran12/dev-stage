package com.model;

public class Patient {
    private int patientId;
    private String patientName;
    private String email;
    private String mobile;

    // Constructor, getters, and setters
    public Patient(int patientId, String patientName, String email, String mobile) {
        this.patientId = patientId;
        this.patientName = patientName;
        this.email = email;
        this.mobile = mobile;
    }

    public int getPatientId() {
        return patientId;
    }

    public void setPatientId(int patientId) {
        this.patientId = patientId;
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
}
