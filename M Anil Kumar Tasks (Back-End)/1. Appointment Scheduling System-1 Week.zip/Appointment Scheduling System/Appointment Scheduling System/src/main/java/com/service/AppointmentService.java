package com.service;

import com.model.Appointment;
import com.model.Patient;
import com.util.DatabaseUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalTime;

public class AppointmentService {

    public static boolean isSlotAvailable(String doctorName, LocalDate appointmentDate, LocalTime appointmentTime) {
        String query = " MYSQL QUERY ";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setString(1, doctorName);
            stmt.setDate(2, java.sql.Date.valueOf(appointmentDate));
            stmt.setTime(3, java.sql.Time.valueOf(appointmentTime));

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) == 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
    
    private static boolean isPatientAppointmentExists(int patientId, String patientName, String doctorName, LocalDate appointmentDate, LocalTime appointmentTime) {
        String query = "SELECT * FROM appointments WHERE patient_id = ? AND patient_name = ? AND doctor_name = ? AND appointment_date = ? ";
        
        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, patientId);
            stmt.setString(2, patientName);
            stmt.setString(3, doctorName);
            stmt.setDate(4, java.sql.Date.valueOf(appointmentDate));
            stmt.setTime(5, java.sql.Time.valueOf(appointmentTime));

            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) == 0;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }
    
    public static boolean bookAppointment(Appointment appointment) {
        if (isSlotAvailable(appointment.getDoctorName(), appointment.getAppointmentDate(), appointment.getAppointmentTime())) {
            if (isPatientAppointmentExists(appointment.getPatientId(), appointment.getPatientName(), appointment.getDoctorName(), appointment.getAppointmentDate(), appointment.getAppointmentTime())) {
                String query = "INSERT INTO appointments (patient_id, patient_name, doctor_name, appointment_date, appointment_time, additional_notes) " +
                               "VALUES (?, ?, ?, ?, ?, ?)";

                try (Connection conn = DatabaseUtil.getConnection();
                     PreparedStatement stmt = conn.prepareStatement(query)) {

                    stmt.setInt(1, appointment.getPatientId());
                    stmt.setString(2, appointment.getPatientName());
                    stmt.setString(3, appointment.getDoctorName());
                    stmt.setDate(4, java.sql.Date.valueOf(appointment.getAppointmentDate()));
                    stmt.setTime(5, java.sql.Time.valueOf(appointment.getAppointmentTime()));
                    stmt.setString(6, appointment.getAdditionalNotes());

                    int rowsAffected = stmt.executeUpdate();
                    if (rowsAffected > 0) {
                        sendNotification(appointment, "Booked");
                        return true;
                    }

                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
        }

        return false;
    }

    public static boolean updateAppointment(Appointment updatedAppointment) {
        // Check if the new slot is available
        if (isSlotAvailable(updatedAppointment.getDoctorName(), updatedAppointment.getAppointmentDate(), updatedAppointment.getAppointmentTime())) {
            String query = "UPDATE appointments SET doctor_name = ?, appointment_date = ?, appointment_time = ?, additional_notes = ? " +
                           "WHERE id = ?";

            try (Connection conn = DatabaseUtil.getConnection();
                 PreparedStatement stmt = conn.prepareStatement(query)) {

                stmt.setString(1, updatedAppointment.getDoctorName());
                stmt.setDate(2, java.sql.Date.valueOf(updatedAppointment.getAppointmentDate()));
                stmt.setTime(3, java.sql.Time.valueOf(updatedAppointment.getAppointmentTime()));
                stmt.setString(4, updatedAppointment.getAdditionalNotes());
                stmt.setInt(5, updatedAppointment.getId());

                int rowsAffected = stmt.executeUpdate();
                if (rowsAffected > 0) {
                    sendNotification(updatedAppointment, "Updated");
                    return true;
                }

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        return false;
    }


    public static boolean cancelAppointment(int id) {
        String query = " MYSQL QUERY ";

        try (Connection conn = DatabaseUtil.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, id);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                sendNotification(new Appointment(id, 0, "", "", null, null, ""), "Canceled");
                return true;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

    private static void sendNotification(Appointment appointment, String status) {
        Patient patient = PatientService.getPatientById(appointment.getPatientId());

        if (patient != null) {
            String email = patient.getEmail();
            String mobile = patient.getMobile();

            String message = "Dear " + patient.getPatientName() + ", your appointment is " + status + ".";
            message += "\nDoctor: " + appointment.getDoctorName();
            message += "\nDate: " + appointment.getAppointmentDate();
            message += "\nTime: " + appointment.getAppointmentTime();

            sendEmail(email, "Appointment " + status, message);
            sendSMS(mobile, message);

            System.out.println("Notification sent: " + message);
        } else {
            System.out.println("Patient not found for ID: " + appointment.getPatientId());
        }
    }

    private static void sendEmail(String to, String subject, String message) {
        System.out.println("Sending Email to " + to);
        System.out.println("Subject: " + subject);
        System.out.println("Message: " + message);
    }

    private static void sendSMS(String to, String message) {
        System.out.println("Sending SMS to " + to);
        System.out.println("Message: " + message);
    }
}
