package com.servlet;

import com.model.Appointment;
import com.service.AppointmentService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;

@WebServlet("/appointment")
public class AppointmentServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("book".equals(action)) {
            bookAppointment(request, response);
        } else if ("update".equals(action)) {
            updateAppointment(request, response);
        } else if ("cancel".equals(action)) {
            cancelAppointment(request, response);
        }
    }

    private void bookAppointment(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int patientId = Integer.parseInt(request.getParameter("patientId")); // New field
        String patientName = request.getParameter("patientName");
        String doctorName = request.getParameter("doctorName");
        LocalDate appointmentDate = LocalDate.parse(request.getParameter("appointmentDate"));
        LocalTime appointmentTime = LocalTime.parse(request.getParameter("appointmentTime"));
        String additionalNotes = request.getParameter("additionalNotes");

        Appointment appointment = new Appointment(0, patientId, patientName, doctorName, appointmentDate, appointmentTime, additionalNotes);

        boolean success = AppointmentService.bookAppointment(appointment);

        if (success) {
            response.getWriter().println("Appointment Booked Successfully");
        } else {
            response.getWriter().println("Failed to book appointment. Please try again.");
        }
    }

    private void updateAppointment(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        int patientId = Integer.parseInt(request.getParameter("patientId")); // New field
        String patientName = request.getParameter("patientName");
        String doctorName = request.getParameter("doctorName");
        LocalDate appointmentDate = LocalDate.parse(request.getParameter("appointmentDate"));
        LocalTime appointmentTime = LocalTime.parse(request.getParameter("appointmentTime"));
        String additionalNotes = request.getParameter("additionalNotes");

        Appointment appointment = new Appointment(id, patientId, patientName, doctorName, appointmentDate, appointmentTime, additionalNotes);

        boolean success = AppointmentService.updateAppointment(appointment);

        if (success) {
            response.getWriter().println("Appointment Updated Successfully");
        } else {
            response.getWriter().println("Failed to update appointment. Please try again.");
        }
    }

    private void cancelAppointment(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));

        boolean success = AppointmentService.cancelAppointment(id);

        if (success) {
            response.getWriter().println("Appointment Canceled Successfully");
        } else {
            response.getWriter().println("Failed to cancel appointment. Please try again.");
        }
    }
}
