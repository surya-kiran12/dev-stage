package com.Service;

import java.math.BigDecimal;
import java.sql.Date;
import com.DAO.FinancialReportDAO;
import com.Model.FinancialReport;

public class FinancialReportService {
    private FinancialReportDAO reportDAO;

    public FinancialReportService() {
        this.reportDAO = new FinancialReportDAO();
    }

    public BigDecimal getTotalByType(String type, Date startDate, Date endDate) {
        return reportDAO.getTotalByType(type, startDate, endDate);
    }
    
    public FinancialReport generateReport(Date startDate, Date endDate) {
        BigDecimal totalRevenue = reportDAO.getTotalByType("REVENUE", startDate, endDate);
        BigDecimal totalExpenses = reportDAO.getTotalByType("EXPENSE", startDate, endDate);
        BigDecimal profit = totalRevenue.subtract(totalExpenses);

        FinancialReport report = new FinancialReport();
        report.setStartDate(startDate);
        report.setEndDate(endDate);
        report.setTotalRevenue(totalRevenue);
        report.setTotalExpenses(totalExpenses);
        report.setProfit(profit);

        return report;
    }
}
