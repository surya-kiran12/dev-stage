package com.DAO;

import java.math.BigDecimal;
import java.sql.*;
import com.Utility.DBUtil;

public class FinancialReportDAO {
    private Connection connection;

    public FinancialReportDAO() {
        try {
            connection = DBUtil.getConnection();
            if (connection == null) {
                throw new SQLException("Failed to establish a database connection.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            throw new RuntimeException("Error initializing database connection", e);
        }
    }

    public BigDecimal getTotalByType(String type, Date startDate, Date endDate) {
        BigDecimal total = BigDecimal.ZERO;
        String query = "SELECT SUM(amount) FROM financial_report WHERE type = ? AND date BETWEEN ? AND ?";
        System.out.println("Executing query: " + query);
        try (PreparedStatement ps = connection.prepareStatement(query)) {
            ps.setString(1, type);
            ps.setDate(2, startDate);
            ps.setDate(3, endDate);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    total = rs.getBigDecimal(1);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            DBUtil.closeConnection(connection);
        }
        System.out.println("Total for type " + type + ": " + total);
        return total;
    }
}
