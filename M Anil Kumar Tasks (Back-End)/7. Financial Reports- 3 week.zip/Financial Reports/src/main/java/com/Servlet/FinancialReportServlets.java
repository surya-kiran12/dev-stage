package com.Servlet;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import com.Model.FinancialReport;
import com.Service.FinancialReportService;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/financialreport")
public class FinancialReportServlets extends HttpServlet {
    private FinancialReportService reportService;

    @Override
    public void init() {
        reportService = new FinancialReportService();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String startDateParam = request.getParameter("startDate");
        String endDateParam = request.getParameter("endDate");
        String typeParam = request.getParameter("type");

        if (startDateParam == null || endDateParam == null || typeParam == null) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Missing required parameters");
            return;
        }

        try {
            Date startDate = parseDate(startDateParam);
            Date endDate = parseDate(endDateParam);

            // Log parameters
            System.out.println("Received parameters: Start Date: " + startDate + ", End Date: " + endDate + ", Type: " + typeParam);

            // Generate the report based on the parameters
            BigDecimal totalRevenue = reportService.getTotalByType("REVENUE", startDate, endDate);
            BigDecimal totalExpenses = reportService.getTotalByType("EXPENSE", startDate, endDate);
            BigDecimal profit = totalRevenue.subtract(totalExpenses);

            // Create and set report object
            FinancialReport report = new FinancialReport();
            report.setStartDate(startDate);
            report.setEndDate(endDate);
            report.setTotalRevenue(totalRevenue);
            report.setTotalExpenses(totalExpenses);
            report.setProfit(profit);
            request.setAttribute("report", report);

            // Forward to JSP page
            RequestDispatcher dispatcher = request.getRequestDispatcher("report.jsp");
            dispatcher.forward(request, response);

        } catch (ParseException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid date format");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Server error");
        }
    }

    private Date parseDate(String dateStr) throws ParseException {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        java.util.Date dateUtil = sdf.parse(dateStr);
        return new Date(dateUtil.getTime());
    }
}
