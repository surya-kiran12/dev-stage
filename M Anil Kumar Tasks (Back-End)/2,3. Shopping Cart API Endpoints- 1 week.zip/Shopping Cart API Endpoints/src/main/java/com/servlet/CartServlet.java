package com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.util.Database;

@WebServlet("/cart/manage")
public class CartServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String action = request.getParameter("action");

        if ("add".equalsIgnoreCase(action)) {
            addToCart(request, response);
        } else if ("update".equalsIgnoreCase(action)) {
            updateCart(request, response);
        } else if ("remove".equalsIgnoreCase(action)) {
            removeFromCart(request, response);
        } else {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Invalid action");
        }
    }

    private void addToCart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String itemName = request.getParameter("itemName");
        double price;
        int quantity;

        // Validate parameters
        try {
            price = Double.parseDouble(request.getParameter("price"));
            quantity = Integer.parseInt(request.getParameter("quantity"));
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Invalid price or quantity");
            return;
        }

        if (itemName == null || itemName.isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Item name is required");
            return;
        }

        try (Connection conn = Database.getConnection()) {
            // Check if item already exists in the cart
            if (itemExistsInCart(conn, itemName)) {
                response.setStatus(HttpServletResponse.SC_CONFLICT);
                response.getWriter().write("Item already exists in cart");
                return;
            }

            String sql = "INSERT INTO cart_items (item_name, price, quantity) VALUES (?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, itemName);
            stmt.setDouble(2, price);
            stmt.setInt(3, quantity);
            stmt.executeUpdate();

            response.setStatus(HttpServletResponse.SC_OK);
            response.getWriter().write("Item added to cart");

        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("Error adding item to cart");
        }
    }

    private void updateCart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String itemName = request.getParameter("itemName");
        double price;
        int quantity;

        // Validate parameters
        try {
            price = Double.parseDouble(request.getParameter("price"));
            quantity = Integer.parseInt(request.getParameter("quantity"));
        } catch (NumberFormatException e) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Invalid price or quantity");
            return;
        }

        if (itemName == null || itemName.isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Item name is required");
            return;
        }

        try (Connection conn = Database.getConnection()) {
            String sql = "UPDATE cart_items SET price = ?, quantity = ? WHERE item_name = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setDouble(1, price);
            stmt.setInt(2, quantity);
            stmt.setString(3, itemName);
            int rowsUpdated = stmt.executeUpdate();

            if (rowsUpdated > 0) {
                response.setStatus(HttpServletResponse.SC_OK);
                response.getWriter().write("Item quantity updated");
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                response.getWriter().write("Item not found in cart");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("Error updating item quantity");
        }
    }

    private void removeFromCart(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String itemName = request.getParameter("itemName");

        if (itemName == null || itemName.isEmpty()) {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            response.getWriter().write("Item name is required");
            return;
        }

        try (Connection conn = Database.getConnection()) {
            String sql = "DELETE FROM cart_items WHERE item_name = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, itemName);
            int rowsDeleted = stmt.executeUpdate();

            if (rowsDeleted > 0) {
                response.setStatus(HttpServletResponse.SC_OK);
                response.getWriter().write("Item removed from cart");
            } else {
                response.setStatus(HttpServletResponse.SC_NOT_FOUND);
                response.getWriter().write("Item not found in cart");
            }

        } catch (SQLException e) {
            e.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write("Error removing item from cart");
        }
    }

    private boolean itemExistsInCart(Connection conn, String itemName) throws SQLException {
        String sql = "SELECT COUNT(*) FROM cart_items WHERE item_name = ?";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, itemName);
        ResultSet rs = stmt.executeQuery();

        if (rs.next()) {
            return rs.getInt(1) > 0;
        }
        return false;
    }
}
