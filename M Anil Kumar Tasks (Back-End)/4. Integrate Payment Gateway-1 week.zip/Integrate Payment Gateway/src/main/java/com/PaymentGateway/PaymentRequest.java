package com.PaymentGateway;

public class PaymentRequest {
	private String amount;
    private String currency;
    private String paymentMethod; // Paypal or stripe
    private String gateway;
    private String orderId;
    
	public PaymentRequest() {
		super();
	}

	public PaymentRequest(String amount, String currency, String paymentMethod, String gateway, String orderId) {
		super();
		this.amount = amount;
		this.currency = currency;
		this.paymentMethod = paymentMethod;
		this.gateway = gateway;
		this.orderId = orderId;
	}

	public String getAmount() {
		return amount;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getPaymentMethod() {
		return paymentMethod;
	}

	public void setPaymentMethod(String paymentMethod) {
		this.paymentMethod = paymentMethod;
	}

	public String getGateway() {
		return gateway;
	}

	public void setGateway(String gateway) {
		this.gateway = gateway;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
    
    
}
	   
