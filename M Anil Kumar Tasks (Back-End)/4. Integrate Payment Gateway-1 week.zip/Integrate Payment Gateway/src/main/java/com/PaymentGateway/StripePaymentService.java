package com.PaymentGateway;

import java.util.HashMap;
import java.util.Map;

import com.stripe.Stripe;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;

public class StripePaymentService {

	public StripePaymentService() {
        // Set your Stripe secret key here
        Stripe.apiKey = "your_stripe_secret_key";
    }

    public PaymentResponse processPayment(PaymentRequest paymentRequest) throws StripeException {
        // Convert amount to smallest currency unit (e.g., cents for USD)
        int amountInCents = (int) (Double.parseDouble(paymentRequest.getAmount()) * 100);

        Map<String, Object> params = new HashMap<>();
        params.put("amount", amountInCents);
        params.put("currency", paymentRequest.getCurrency());
        params.put("payment_method", paymentRequest.getPaymentMethod());
        params.put("confirmation_method", "automatic");
        params.put("confirm", true);

        PaymentIntent intent = PaymentIntent.create(params);

        String status = intent.getStatus();
        switch (status) {
            case "succeeded":
                return new PaymentResponse("Paid", intent.getId(), paymentRequest.getOrderId());
            case "requires_payment_method":
            case "requires_action":
            case "requires_capture":
                return new PaymentResponse("Pending", intent.getId(), paymentRequest.getOrderId());
            case "canceled":
                return new PaymentResponse("Cancelled", intent.getId(), paymentRequest.getOrderId());
            default:
                return new PaymentResponse("Failed", intent.getId(), paymentRequest.getOrderId());
        }
    }
}
