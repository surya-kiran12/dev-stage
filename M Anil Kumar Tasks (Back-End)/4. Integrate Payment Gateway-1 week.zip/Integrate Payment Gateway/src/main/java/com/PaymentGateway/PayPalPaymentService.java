package com.PaymentGateway;

import java.util.ArrayList;
import java.util.List;

import com.paypal.api.payments.Amount;
import com.paypal.api.payments.Payer;
import com.paypal.api.payments.Payment;
import com.paypal.api.payments.RedirectUrls;
import com.paypal.api.payments.Transaction;
import com.paypal.base.rest.APIContext;
import com.paypal.base.rest.PayPalRESTException;

public class PayPalPaymentService {

	private static final String CLIENT_ID = "your_paypal_client_id";
    private static final String CLIENT_SECRET = "your_paypal_client_secret";
    private static final String MODE = "sandbox"; // Use "live" for production

    public PaymentResponse processPayment(PaymentRequest paymentRequest) throws PayPalRESTException {
        APIContext apiContext = new APIContext(CLIENT_ID, CLIENT_SECRET, MODE);

        Amount amount = new Amount();
        amount.setCurrency(paymentRequest.getCurrency());
        amount.setTotal(paymentRequest.getAmount());

        Transaction transaction = new Transaction();
        transaction.setAmount(amount);
        transaction.setDescription("Order ID: " + paymentRequest.getOrderId());

        List<Transaction> transactions = new ArrayList<>();
        transactions.add(transaction);

        Payer payer = new Payer();
        payer.setPaymentMethod("paypal");

        Payment payment = new Payment();
        payment.setIntent("sale");
        payment.setPayer(payer);
        payment.setTransactions(transactions);

        RedirectUrls redirectUrls = new RedirectUrls();
        redirectUrls.setCancelUrl("http://localhost:8080/yourapp/cancel");
        redirectUrls.setReturnUrl("http://localhost:8080/yourapp/return");
        payment.setRedirectUrls(redirectUrls);

        Payment createdPayment = payment.create(apiContext);

        // Handle different payment states returned by PayPal
        String status = createdPayment.getState();
        switch (status) {
            case "approved":
                return new PaymentResponse("Paid", createdPayment.getId(), paymentRequest.getOrderId());
            case "created":
                return new PaymentResponse("Pending", createdPayment.getId(), paymentRequest.getOrderId());
            case "canceled":
                return new PaymentResponse("Cancelled", createdPayment.getId(), paymentRequest.getOrderId());
            default:
                return new PaymentResponse("Failed", createdPayment.getId(), paymentRequest.getOrderId());
        }
    }
}