package com.PaymentGateway;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet("payment/process")
public class PaymentServlet extends HttpServlet {
	
	@Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String gateway = request.getParameter("gateway");
        String amount = request.getParameter("amount");
        String currency = request.getParameter("currency");
        String paymentMethod = request.getParameter("paymentMethod");
        String orderId = request.getParameter("orderId"); // Assuming orderId is passed in the request
           
        PaymentRequest paymentRequest = new PaymentRequest(amount, currency, paymentMethod, gateway, orderId);
        PaymentResponse paymentResponse = null;

        try {
            if ("stripe".equalsIgnoreCase(gateway)) {
                StripePaymentService stripeService = new StripePaymentService();
                paymentResponse = stripeService.processPayment(paymentRequest);
            } else if ("paypal".equalsIgnoreCase(gateway)) {
                PayPalPaymentService paypalService = new PayPalPaymentService();
                paymentResponse = paypalService.processPayment(paymentRequest);
            }

            if (paymentResponse != null) {
                // Update order status
                updateOrderStatus(paymentResponse);

                // Send notifications
                sendNotification(paymentResponse);

                response.setContentType("application/json");
                response.setCharacterEncoding("UTF-8");
                response.getWriter().write(paymentResponse.toJson().toString());
            } else {
                response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid payment gateway");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, e.getMessage());
        }
    }

    private void updateOrderStatus(PaymentResponse paymentResponse) {
      
        String status = paymentResponse.getStatus();
        String orderId = paymentResponse.getOrderId();

        // Update the order status
        // e.g., "Paid", "Failed", "Cancelled"
        System.out.println("Updating order " + orderId + " status to " + status);
    }

    private void sendNotification(PaymentResponse paymentResponse) {
      
        String status = paymentResponse.getStatus();
        String transactionId = paymentResponse.getTransactionId();

        // Notify the user about the payment status
        System.out.println("Sending notification: Payment " + status + " with transaction ID " + transactionId);
    }
}
