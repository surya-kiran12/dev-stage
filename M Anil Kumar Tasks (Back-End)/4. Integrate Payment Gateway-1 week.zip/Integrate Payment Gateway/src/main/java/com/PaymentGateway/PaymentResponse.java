package com.PaymentGateway;

import org.json.JSONObject;

public class PaymentResponse {

	private String status;
    private String transactionId;
    private String orderId;

    public PaymentResponse(String status, String transactionId, String orderId) {
        this.status = status;
        this.transactionId = transactionId;
        this.orderId = orderId;
    }

    // Getters and setters

    public String getStatus() { return status; }
    public String getTransactionId() { return transactionId; }
    public String getOrderId() { return orderId; }

    public JSONObject toJson() {
        JSONObject json = new JSONObject();
        json.put("status", status);
        json.put("transactionId", transactionId);
        json.put("orderId", orderId);
        return json;
    }
}
