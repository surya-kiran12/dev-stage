package com.stockAlert;

import java.sql.Timestamp;

public class Alert {

	private int alertId;
    private String inventoryId;
    private String alertType;
    private Timestamp alertDate;
    
	public Alert() {
		super();
	}

	public Alert(int alertId, String inventoryId, String alertType, Timestamp alertDate) {
		super();
		this.alertId = alertId;
		this.inventoryId = inventoryId;
		this.alertType = alertType;
		this.alertDate = alertDate;
	}

	public int getAlertId() {
		return alertId;
	}

	public void setAlertId(int alertId) {
		this.alertId = alertId;
	}

	public String getInventoryId() {
		return inventoryId;
	}

	public void setInventoryId(String inventoryId) {
		this.inventoryId = inventoryId;
	}

	public String getAlertType() {
		return alertType;
	}

	public void setAlertType(String alertType) {
		this.alertType = alertType;
	}

	public Timestamp getAlertDate() {
		return alertDate;
	}

	public void setAlertDate(Timestamp alertDate) {
		this.alertDate = alertDate;
	}

	@Override
	public String toString() {
		return "Alert [alertId=" + alertId + ", inventoryId=" + inventoryId + ", alertType=" + alertType + "]";
	}
    
    
}
