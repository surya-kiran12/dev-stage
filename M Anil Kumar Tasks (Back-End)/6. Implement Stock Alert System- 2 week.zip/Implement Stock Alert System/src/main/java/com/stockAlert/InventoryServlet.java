package com.stockAlert;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;


@WebServlet("/inventory/alerts")
public class InventoryServlet extends HttpServlet {

    private final Gson gson = new Gson();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        try (Connection conn = DBConnection.getConnection()) {
            List<Inventory> inventoryList = new ArrayList<>();
            List<Alert> alertsList = new ArrayList<>();

            // Fetch inventory
            String sqlInventory = "SELECT * FROM Inventory";
            try (PreparedStatement psInventory = conn.prepareStatement(sqlInventory);
                 ResultSet rsInventory = psInventory.executeQuery()) {

                while (rsInventory.next()) {
                    Inventory inventory = new Inventory(
                        rsInventory.getString("productId"),
                        rsInventory.getString("productName"),
                        rsInventory.getInt("quantity"),
                        rsInventory.getString("stockStatus")
                    );
                    inventoryList.add(inventory);
                }
            }

            // Fetch alerts
            String sqlAlerts = "SELECT * FROM Alerts";
            try (PreparedStatement psAlerts = conn.prepareStatement(sqlAlerts);
                 ResultSet rsAlerts = psAlerts.executeQuery()) {

                while (rsAlerts.next()) {
                    Alert alert = new Alert(
                        rsAlerts.getInt("alertId"),
                        rsAlerts.getString("inventoryId"),
                        rsAlerts.getString("alertType"),
                        rsAlerts.getTimestamp("alertDate")
                    );
                    alertsList.add(alert);
                }
            }

            // Create JSON response
            String jsonResponse = gson.toJson(new ResponseData(inventoryList, alertsList));
            response.getWriter().write(jsonResponse);

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        String productId = request.getParameter("productId");
        String productName = request.getParameter("productName");
        int quantity = Integer.parseInt(request.getParameter("quantity"));
        String stockStatus = request.getParameter("stockStatus");

        try (Connection conn = DBConnection.getConnection()) {
         
            // Check and insert alert if necessary
            if (quantity < 10) { // Example threshold for low stock alert
                String insertAlertSQL = "INSERT INTO Alerts (inventoryId, alertType) VALUES (?, ?)";
                try (PreparedStatement psInsertAlert = conn.prepareStatement(insertAlertSQL)) {
                    psInsertAlert.setString(1, productId);
                    psInsertAlert.setString(2, "Low Stock");
                    psInsertAlert.executeUpdate();
                }
            }

            response.getWriter().write("{\"success\": true, \"message\": \"Inventory updated\"}");

        } catch (SQLException e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error");
        }
    }

    // Helper class to wrap response data
    private static class ResponseData {
        private final List<Inventory> inventory;
        private final List<Alert> alerts;

        public ResponseData(List<Inventory> inventory, List<Alert> alerts) {
            this.inventory = inventory;
            this.alerts = alerts;
        }

        public List<Inventory> getInventory() {
            return inventory;
        }

        public List<Alert> getAlerts() {
            return alerts;
        }
    }
    
    // Database Connection Class
    public class DBConnection {
    	
    	private static final String url = "jdbc:mysql://localhost:3306/HospitalDB";
    	private static final String username = "root";
    	private static final String password = "password";
    	
    	public static Connection getConnection() {
    	Connection connection = null;
    	try {
    		connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/HospitalDB","root", "password");
    		try {
    			Class.forName("com.mysql.cj.jbdc.Driver");
    		} catch (ClassNotFoundException e) {
    			// TODO: handle exception
    			e.printStackTrace();
    		}
    	} catch (SQLException e) {
    		// TODO: handle exception
    		e.printStackTrace();
    	}
    	return connection;
    	}
    }
}